# Unfinished Work

The don't-know list. When the owner cannot answer something, in the interview or in any session, it does not get skipped and forgotten. It lands here, with one of two states:

- **NOT KNOWN**: the owner does not know the answer yet. They need to find it, check it, or decide it.
- **NEED TO CREATE**: the thing does not exist yet. A story not written down, a link not set up, a process not documented. It has to be made, not found.

This is different from a `[skipped]` tag. Skipped means the owner chose not to. Unfinished means the owner wants it answered and cannot answer it yet.

## The rules

1. Tag the gap where the answer belongs (in the wiki file, memory, or wherever it came up) as `[UNFINISHEDWORK: NOT KNOWN]` or `[UNFINISHEDWORK: NEED TO CREATE]`, and add the item to the list below with the date and where the answer belongs.
2. The assistant resurfaces ONE item per day, oldest first, inside the morning brief. No separate messages, no extra nudges.
3. The owner can say "more" (or "ok") to get up to 2 more that day. Never more than 3 in a day. The default is 1.
4. The owner can also defer an item. It goes to the back of the list and comes around again. Deferring is always allowed and never argued with. Or the owner can say "haven't done it." That settles the item as NEED TO CREATE, and rule 6 applies.
5. When an item is answered: write the real answer where it belongs, tag it `[confirmed YYYY-MM-DD]`, and move the item to Done below with the date.
6. For a NEED TO CREATE item, the surfacing line in the brief carries a standing offer: the assistant can draft the thing for the owner. Three routes, the owner picks:
   - **Questions:** the assistant asks a short series of questions, one at a time, and drafts from the answers.
   - **Scan your work:** the assistant searches `/raw`, `/wiki`, `/projects`, and any files the owner points to, and drafts from what it finds.
   - **Scan a source:** the assistant reads a website or other source the owner names and drafts from that.
   Drafts are never filed as fact on their own. The owner reviews and approves first; then the answer is filed, tagged `[confirmed]`, and the item moves to Done. Anything a scan could not support stays a gap in the draft, marked, never invented. If the owner declines the offer, the item just cycles like any other.

## Waiting (oldest first)

_Nothing waiting. Items land here as `YYYY-MM-DD | state | the question | answer belongs in: file`._

## Done

_Finished items move here with the date they were answered._
