# Projects

Active work lives here, one folder per project.

Create a folder for each project and give that folder its own README describing the project. When a raw note relates to a project, the translate prompt also surfaces it in that project's notes.
