# Approvals queue

Every outbound draft lands here to wait for the owner. Nothing sends from anywhere else.

- One file per draft, named `YYYY-MM-DD-<what-it-is>.md` (for example, `2026-10-21-follow-up-note.md`).
- The owner reviews the queue each morning, alongside the brief.
- Approved and sent: the assistant moves the file to `archive/` with the same name.
- Rejected: the owner says "kill it" in the review and the assistant moves it to `trash/` with a date prefix.
- If a draft is not in this queue, it does not go out.
