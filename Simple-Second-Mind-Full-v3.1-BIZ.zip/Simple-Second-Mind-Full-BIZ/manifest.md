# Manifest

Every moving part of this system, one line each. This file describes; it does not instruct. The rules live in `AGENTS.md` and nowhere else.

When a new system file or folder is created, add one line here. That is what keeps this list complete.

## Root files

- `README.md` the owner's guide to the system.
- `AGENTS.md` the canonical instructions. Every rule lives here.
- `CLAUDE.md`, `GEMINI.md` two-line pointer stubs to `AGENTS.md`.
- `memory.md` the cheat sheet: who the owner is, system settings, interview and schedule status.
- `today.md` the daily page: today's ranked task list, on-my-mind notes, agent log. Archived each morning to `archive/daily/`.
- `tasks.md` the Master Task List: this week's top priorities, the unscheduled master list, items parked by month, the closed log.
- `unfinished-work.md` the don't-know register (NOT KNOWN / NEED TO CREATE), resurfaced one per day in the morning brief.
- `schedule.md` the timetable: the two jobs, the morning brief routine, the 30-minute floor, the cadence matrix.
- `manifest.md` this file.

## Folders

- `raw/` incoming, unprocessed. Local only.
- `wiki/` managed knowledge: general notes, plus `people/`, `brand/`, `business/`. Ships with two files already filled: `brand/banned-words.md` (starter list) and `guardrails.md` (general starters; industry rules added by the interview). The interview creates the rest, including `ai-context.md` at its Finish.
- `sops/` approved practices by area (clients, operations, agent, prospecting, social-media).
- `projects/` active work.
- `prompts/` reusable instructions: `translate.md`, `learn.md`, `first-run-interview.md`, `master-starter-prompt.md`.
- `skills/` reusable skills for the one assistant, one file per skill.
- `money/` income, expenses, property records.
- `assets/` large files a finished note points at. Local only.
- `archive/` processed originals, daily pages, monthly logs. Local only.
- `queue/` outbound drafts waiting for the owner's approval.
- `CONFIDENTIAL/` restricted material. Local only.
- `trash/` the bucket: anything removed lands here, date-prefixed. Local only. Only the owner empties it.
- `learning/` daily learning loop: proposals by date, its state file, and the applied-changes log.
- `examples/` one worked example in two halves (a complete mini guide in markdown, plus the same guide processed into seven one-topic files in `examples/processed`) plus a five-minute exercise. Teaching material only; safe to delete after reading.

## Methods worth naming

- The raw-to-wiki loop: `prompts/translate.md`
- The daily learning loop: `prompts/learn.md`
- Task forwarding and the Master Task List: `sops/agent/task-forwarding.md`
- The morning brief and the schedule: `schedule.md`
- The first-run interview: `prompts/first-run-interview.md`
