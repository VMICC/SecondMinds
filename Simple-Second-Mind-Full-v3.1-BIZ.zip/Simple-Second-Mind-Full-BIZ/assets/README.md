# Assets (local only)

Big files live here: images, documents, audio, video, and originals that a finished note still points at.

The test is reference, not file type: if a finished note links to the file, it is an asset and lives here. A processed original that nothing references goes to `/archive` instead.

Finished notes reference assets by relative path (for example, `assets/inspection-report.pdf`). The reference travels with the folder; the file opens locally. Contents are local only under the root `.gitignore`; only this README uploads, so the folder explains itself. Sort into subfolders by type only when the folder gets big enough to need it.
