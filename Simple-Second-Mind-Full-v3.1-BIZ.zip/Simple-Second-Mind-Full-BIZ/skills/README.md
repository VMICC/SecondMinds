# Skills

Reusable skills for the one assistant in this system. A skill is a capability packaged so it runs the same way every time: a clear trigger, a set of steps, and a defined output.

In this Full version, skills live here, in one flat folder, because there is one assistant. If a skill ever needs an owner other than the assistant, this system has outgrown its design.

Rules:

- One skill per file, named for what it produces (for example, `weekly-summary.md`).
- Start a new skill from `skill-template.md` in this folder.
- A skill is not an SOP. An SOP is how the business does something ("do it this way"). A skill is how the assistant performs a repeatable task inside that. When in doubt: if a human would follow it, it is an SOP in `/sops`; if only the assistant runs it, it is a skill here.
- Never keep two files that do the same job. When two skills overlap, merge them into one and move the old file to `/trash` with a date prefix.
