# Skill: <name>

**Use when:** The trigger, in one line (a request, a schedule, a file landing in `/raw`).
**Input:** What the assistant needs before starting, and where it lives in this folder.
**Output:** What gets produced, and where it is filed.

## Steps

1.
2.
3.

## Rules for this skill

- Read before writing: merge into the existing output file, never overwrite blindly.
- Drafts for anyone else go in `/queue` for approval.
- Log the run in `today.md` under Agent log.
- When something needed is missing, note it in the output and register it in `unfinished-work.md` if the owner needs to supply it. Never invent it.
