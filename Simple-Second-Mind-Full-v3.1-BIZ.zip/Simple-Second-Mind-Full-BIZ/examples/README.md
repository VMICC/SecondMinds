# Examples

One worked example, in two halves: a document as it arrived, and the same document after processing. This is the raw-to-wiki loop with a real before and after, so you can see what "processed" actually looks like before you run it on your own material. Read it once, try the exercise at the bottom, then delete this whole folder if you want. Nothing else in the system depends on it.

## Before: one document

`hyper-local-seller-content.md` is a complete mini guide (Hyper Local Seller Content, a conference mini guide by Janine Sasso, converted here from its PDF edition) as a single file: good content, all in one place, hard to reuse in pieces. Guides, PDFs, and long notes usually arrive like this.

It was picked because it demonstrates the exact habit this system teaches, inside its own pages: one source asset filed once, repurposed instead of rewritten (its worked example adapts one topic for Facebook, Instagram, Google Business Profile, email, video, and a 24-month postcard plan), and a reusable AI prompt worth filing on its own.

## After: the same guide, processed

`processed/` holds the same guide after processing, built by Claude and then checked and completed: seven small files, one topic each, typed and cross-linked the way this system files things.

- `LC_hyper-local-seller-content.md`: the overview and index, the system's thesis and map.
- `LC_seller-question-library.md`: the 12 questions, in the sellers' own words, mapped to postcard months. A reference.
- `LC_seller-blog-writing.md`: how the source article gets written, with the copy-paste prompt. A process.
- `LC_content-repurposing.md`: one article across every platform, with the worked example. A process.
- `LC_postcard-plan-24-month.md`: the two-year mail plan. A plan.
- `LC_content-distribution-system.md`: setup steps and quarterly review. An SOP.
- `LC_first-content-cycle.md`: the closing worksheet, restored as its own file.

Compare the two halves and the filing rules stop being abstract: one topic per file, a type on everything, links instead of copies, an index that points instead of repeating.

## Why this is markdown and not the PDF

The PDF edition of this guide cannot live in this system. The root `.gitignore` ignores PDF files everywhere, on purpose, so a PDF dropped in here would never upload and anyone who got this folder from version history would never see it. Text travels; PDFs stay local. That rule is the lesson, not a limitation.

## Try it: the five-minute exercise

1. Copy `hyper-local-seller-content.md` into your `/raw` folder.
2. Run `prompts/translate.md`.
3. Compare what your assistant filed against the `processed/` set. A good run lands in the same neighborhood: a library entry for the questions, the blog method and its prompt filed as a process or skill, the repurposing method as an SOP, the postcard cadence as a plan, the original moved to `/archive` with the run logged in `today.md`.
4. Where your assistant's version differs from `processed/`, neither is automatically wrong. That difference is the conversation worth having with it. The conversation, not the file, is the training.
