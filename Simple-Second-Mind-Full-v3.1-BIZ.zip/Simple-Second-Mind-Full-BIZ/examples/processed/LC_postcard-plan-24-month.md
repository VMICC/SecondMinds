---
type: plan
tags: [direct-mail, postcards, nurture]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# 24-Month Postcard Plan

12 educational postcards, one every other month, matching the 12 seller articles. Two years of seller follow-up.

## Each postcard
- One question
- One useful takeaway
- QR code or short link to the matching article
- Quick read. The article holds the deeper explanation.

## Schedule
| Send | Month | Topic |
|------|-------|-------|
| 01 | 1 | Sell As-Is or Make Repairs First |
| 02 | 3 | How Much Is My Home Worth |
| 03 | 5 | Ready to Sell? Do This First |
| 04 | 7 | How Should I Price My Home |
| 05 | 9 | How Long Will It Take to Sell |
| 06 | 11 | How Do I Sell My Home |
| 07 | 13 | How Much Will I Walk Away With |
| 08 | 15 | What Are the Costs of Selling |
| 09 | 17 | When Is the Best Time to Sell |
| 10 | 19 | Sell Before Buying My Next Home |
| 11 | 21 | Biggest Mistakes Sellers Make |
| 12 | 23 | What Happens After an Offer |

Last postcard lands month 23; nurture window runs through month 24. Planned cadence, not a prediction of when anyone sells.

## Related
- [Hyper Local Seller Content (overview)](LC_hyper-local-seller-content.md) | [Seller Question Library](LC_seller-question-library.md) | [Content Distribution System](LC_content-distribution-system.md)
- Companion set (separate guide, not part of this set): the Motivated Movers 8 postcards over 6 weeks plan covers the life-change side of the same farm.
