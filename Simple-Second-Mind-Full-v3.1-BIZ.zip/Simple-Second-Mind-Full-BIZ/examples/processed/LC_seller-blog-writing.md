---
type: process
tags: [blog, ai-prompt, seller-content]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# Seller Blog Writing

The blog on your website is the source asset. Answer one seller question clearly enough that a homeowner knows what to consider next.

## Structure
1. **Answer the decision.** Seller question is the headline. Open with a clear answer and explain what depends on the homeowner.
2. **Bring your expertise forward.** Add a real experience, a local observation and the advice you would give in a seller conversation.
3. **Make the next step easy.** Practical takeaway, pair with its thumbnail, end with an invitation to talk.

## AI prompt (copy/paste)
```text
Help me write a seller article answering [QUESTION] for homeowners in [FARM]. Before drafting, ask me these three specific questions, tailored to the topic, and wait for my answers:

1. Personal experience
Tell me about a real seller situation involving this decision. What was happening, what did you advise, and what happened or what did you learn?

2. Local market insight
What are you seeing in this neighborhood that changes your advice on this topic? Share a specific buyer reaction, competing listing or market pattern you can explain.

3. Expert judgment
What do sellers often misunderstand about this decision, and what would make you recommend a different approach? Share the first step you would have them take.

Then use my answers to draft a clear, helpful article in my voice. Preserve my nuance. Do not invent outcomes, statistics or local details. Flag facts to verify, omit identifying client details and end with an invitation to discuss the reader's home.
```

## Related
- [Hyper Local Seller Content (overview)](LC_hyper-local-seller-content.md) | [Seller Question Library](LC_seller-question-library.md) | [Content Repurposing](LC_content-repurposing.md) | [First Content Cycle (worksheet)](LC_first-content-cycle.md)
