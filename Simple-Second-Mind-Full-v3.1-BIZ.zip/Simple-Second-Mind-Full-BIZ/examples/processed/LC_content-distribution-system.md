---
type: sop
tags: [distribution, automation, geosential]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# Content Distribution System

Turn the content library into a documented publishing and follow-up plan.

## Steps
1. **Organize the assets.** Per topic keep together: blog URL, thumbnail, platform captions, email, postcard copy, optional video link. Name files so matching pieces are easy to find.
2. **Build the recurring social rotation.** Load evergreen Facebook, Instagram and GBP versions into GEOsential's recurring post plan (where supported for connected accounts). Set spacing, preview each placement.
3. **Create the seller email sequence.** One topic per month to the intended seller audience. Confirm sender, links, reply destination. Review the next cycle before repeating.
4. **Connect the direct mail follow-up.** Map the 12 postcards to months 1 through 23. Confirm recipients, address quality, print cost and schedule before activating.
5. **Give the system an owner.** Someone checks scheduled posts, delivery issues and replies. Update a seller's follow-up when they respond or their situation changes.

## Quarterly review
Check broken links, old market references, upcoming posts and seller responses. Reuse evergreen education; refresh time-sensitive advice before it returns to the schedule.

## Related
- [Hyper Local Seller Content](LC_hyper-local-seller-content.md) | [Postcard Plan](LC_postcard-plan-24-month.md) | [Content Repurposing](LC_content-repurposing.md)
