---
type: reference
tags: [seller-content, topics]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# Seller Question Library

Janine's 12 Hoffman Estates seller questions. Use as a starting point; write answers grounded in your own neighborhood.

| # | Topic | The question, in the seller's words | Postcard month |
|---|-------|--------------------------------------|----------------|
| 01 | Sell As-Is or Make Repairs First | Should I sell my home as-is, or should I make repairs first? | 1 |
| 02 | How Much Is My Home Worth | How much is my home worth in today's market? | 3 |
| 03 | Ready to Sell? Do This First | I'm getting ready to sell. What should I do first? | 5 |
| 04 | How Should I Price My Home | How should I price my home to attract buyers but not leave money behind? | 7 |
| 05 | How Long Will It Take to Sell | How long will it take to sell my home? | 9 |
| 06 | How Do I Sell My Home | How do I sell my home, and what happens step by step? | 11 |
| 07 | How Much Will I Walk Away With | How much money will I actually walk away with? | 13 |
| 08 | What Are the Costs of Selling | What are the costs of selling a home? | 15 |
| 09 | When Is the Best Time to Sell | When is the best time of year to sell? | 17 |
| 10 | Sell Before Buying My Next Home | Should I sell my current home before buying my next one? | 19 |
| 11 | Biggest Mistakes Sellers Make | What are the biggest mistakes sellers make? | 21 |
| 12 | What Happens After an Offer | What happens after I accept an offer? | 23 |

The topic column is the short title used for postcards and thumbnails. The question column is the asset: write the article that answers the question exactly as a seller asks it.

## Related
- [Hyper Local Seller Content (overview)](LC_hyper-local-seller-content.md) | [Seller Blog Writing](LC_seller-blog-writing.md) | [Content Repurposing](LC_content-repurposing.md) | [24-Month Postcard Plan](LC_postcard-plan-24-month.md) | [Content Distribution System](LC_content-distribution-system.md)
