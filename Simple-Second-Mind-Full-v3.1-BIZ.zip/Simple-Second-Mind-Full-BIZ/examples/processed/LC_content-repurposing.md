---
type: process
tags: [social-media, email, video, gbp, repurposing]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# Content Repurposing

Keep the core advice consistent. Change the opening, length and call to action to fit where someone will see it.

## The system at a glance

| Platform | Adaptation | Call to action |
|----------|------------|----------------|
| Blog | Full article | Discuss your home |
| Facebook | Shorter, local, link back | Read the full answer |
| Instagram | Brief, skimmable, save-worthy | Link in bio |
| Google Business Profile | Helpful, local, direct | Read or call |
| Email | One topic, one question | Reply |
| YouTube | Scripted from the article | Subscribe, then read |
| Postcard | One question, one takeaway | QR to the article |

Every version points back to the same source article. Nothing is written twice from scratch.

## Worked example: Sell as-is or make repairs first

**Facebook**
> Thinking about selling in Hoffman Estates? Before you spend money on repairs, compare what buyers expect, what similar homes offer and how quickly you need to move. A project that looks good on paper may not be your best next step. Read the guide: [BLOG LINK].

**Instagram**
> Sell as-is or fix it first? Start with three questions: What needs attention? What will buyers compare it with? What fits your timeline? Save this for your next move. Full guide at the link in my bio.

**Google Business Profile**
> Selling a home in Hoffman Estates? Learn how to weigh repairs, condition and timing before deciding whether to sell as-is. Read the full local guide: [BLOG LINK].

Thumbnail: keep it recognizable. Resize or crop per placement, check the preview, use each platform's link option.

## Monthly email
One topic from the 12-article library each month. Short explanation, link to the full article, invite a reply. Send only to people who agreed to receive your emails.

Sample:
```text
Subject: Before you spend money fixing up your home

Hi [FIRST NAME],

If selling is on your radar, deciding what to repair can feel like a moving target. I would start by looking at your home's condition, your timeline and what buyers will compare it with.

I put together a guide to help you think it through: [BLOG LINK].

Wondering which projects belong on your list? Reply and tell me what you are considering.
[AGENT NAME]
```

## Optional YouTube layer
- Script: open with the seller question, explain the main decision, add a real local example, close with one invitation.
- Record naturally, use the matching thumbnail, link the article in the description.
- Publish on YouTube, then create recurring social posts in GEOsential pointing to it.

## Related
- [Seller Blog Writing](LC_seller-blog-writing.md) | [Content Distribution System](LC_content-distribution-system.md)
