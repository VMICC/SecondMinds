---
type: worksheet
tags: [seller-content, worksheet, getting-started]
source: LC_GEOsential_Hyper_Local_Content_Mini_Guide.pdf
---
# First Content Cycle (Worksheet)

*Restored from the closing worksheet of the source guide ("Make it yours"). Fill it in once, for one question, before scaling to all 12.*

1. **First question I will answer:**
2. **Local example or experience I can use:**
3. **Where it will appear:** blog / Facebook / Instagram / Google Business Profile / email / video / postcard (circle the ones you will actually do)
4. **Postcard month assigned:**
5. **Distribution step still needed before this can run itself:**

When all five lines are filled, write the article with [Seller Blog Writing](LC_seller-blog-writing.md), adapt it with [Content Repurposing](LC_content-repurposing.md), and slot it into the [24-Month Postcard Plan](LC_postcard-plan-24-month.md). Then pick the next question from the [Seller Question Library](LC_seller-question-library.md) and repeat. Twelve cycles is the full library.

## Related
- [Hyper Local Seller Content (overview)](LC_hyper-local-seller-content.md) | [Seller Question Library](LC_seller-question-library.md) | [Seller Blog Writing](LC_seller-blog-writing.md)
