# Archive

Processed files from `/raw` land here, along with old daily pages (`daily/`) and monthly task logs (`monthly/`). Those subfolders are created the first time they are needed.

This is a permanent record. Do not edit or delete files after they land here. Contents are local only under the root `.gitignore`.
