# Learn Prompt

The daily learning loop of this system. Run it once a day, after translate and before the morning brief. It is the alternative sweep to translate: translate files new knowledge from `/raw` into `/wiki`; learn files no knowledge, it reads yesterday's work and proposes improvements to the playbook.


Read everything in this folder that changed in the last 24 hours: `today.md` and yesterday's page in `archive/daily/`, `tasks.md`, `unfinished-work.md`, `queue/`, and the changed files in `/projects`, `/wiki`, `/sops`, `/skills`, `/prompts`, and `/money`. Write one proposal file at `learning/proposals/YYYY-MM-DD.md`. Change nothing else, except one log line in `today.md` and your own state file at `learning/state.md`.

Rules:

- **Proposals only. Apply nothing.** No skill, SOP, prompt, wiki, or root file is edited, and nothing is sent to anyone. Every proposal checkbox stays `[ ]`.
- **Never touch `/CONFIDENTIAL`:** do not read, list, open, or cite it. If a signal needs it, drop the signal.
- **Never modify** client records in `/wiki/people` or active client folders in `/projects`, `/money`, or `/archive`. A proposal that would touch them is Red.
- **Verify before you claim a number.** Check prices, dates, counts, and status against the file where the fact lives, and tag the claim `[verified: YYYY-MM-DD against <file>]` or `[unverified: source says X as of YYYY-MM-DD]`. No tag, no claim. When uncertain, note it in the proposal rather than guessing.
- **Stale guard:** if `learning/state.md` shows a last run more than 7 days ago, do not overwrite it. Log one line in `today.md`, write the stale warning at the top of the proposal file, and stop.
- **One proposal per pattern,** in this format, grouped by tier:

```markdown
## Proposal N: [Short title]
- **Tier:** Green | Yellow | Red
- **Destination:** `path/to/file.md`
- **Change type:** Add | Modify | Remove | Contradiction | Consolidation
- **Confidence:** High | Medium | Low
- **Source:** `path/to/source.md`
**Proposed text:** > new content here
**Why it matters:** one sentence.
- [ ] Approved
```

- **Tiers:** Green is this loop improving itself (files in `learning/`, this prompt). Yellow is another skill, SOP, prompt, or wiki entry. Red is anything that sends to a client, touches the never-modify list or `/wiki/brand`, changes pricing, weakens a rule, or changes a root file or the schedule. When in doubt, Red. Drop Low confidence unless it is an obvious typo.
- **Apply is separate,** only when the owner says "apply proposal N": save a version first, read and merge the destination file, mark the proposal `[x]`, log it in `learning/applied-changes-log.md` with the version saved, save a version again, and stop if any step fails.
- **Never delete.** To undo, restore the saved version. Anything removed goes to `/trash` with a date prefix.
- Finish by updating `learning/state.md` (last run, sources read, totals) and logging one line in `today.md` under Agent log: how many proposals, by tier.
