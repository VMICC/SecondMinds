# Translation Prompt

The core loop of this system. Run it whenever `/raw` has new material.

Read everything in `/raw`. Route each item to where it belongs, update or create the matching files, then move the processed original out of `/raw`. Never delete anything.

## Where things go

- General knowledge: `/wiki` (one topic per file)
- Knowledge about a person: `/wiki/people` (one file per person)
- Brand and voice material: `/wiki/brand`
- Business, offers, and market knowledge: `/wiki/business`
- An approved step-by-step procedure ("do it this way"): `/sops`, by area
- A reusable prompt: `/prompts`
- A reusable skill for the assistant: `/skills` (one file per skill)
- A money record: `/money` (income, expenses, or property)
- A project note: also surface it in that project's folder in `/projects`
- Restricted material: `/CONFIDENTIAL`. Log only that it exists, never copy its contents into the wiki
- A durable fact about the owner: also update `memory.md`
- A big file (image, document, audio, video): `/assets`, if a finished note links to it

## Rules

- One topic per file in `/wiki`, kebab-case filenames.
- Merge into existing entries, never overwrite blindly. Read first.
- Link related entries with relative markdown links.
- Move processed files out of `/raw` when done, with the same filename: to `/archive` if nothing references the file itself, to `/assets` if a finished entry links to it. Never delete.
- When uncertain, note it inside the entry rather than guessing. A gap the owner needs to fill gets an `[UNFINISHEDWORK: NOT KNOWN]` or `[UNFINISHEDWORK: NEED TO CREATE]` tag and a line in `unfinished-work.md`.
- Finish by logging the run in `today.md` under Agent log: what arrived, where it went, what is still unprocessed and why.
