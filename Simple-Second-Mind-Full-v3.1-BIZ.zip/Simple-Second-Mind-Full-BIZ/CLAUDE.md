# Claude

Work in this folder follows `AGENTS.md`. Read `memory.md` first.
When instructions conflict, `AGENTS.md` wins.
