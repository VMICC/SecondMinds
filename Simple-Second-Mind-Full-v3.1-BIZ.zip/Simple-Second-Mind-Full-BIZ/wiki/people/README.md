One file per person: who they are, what matters to them, and what the owner wants to remember.
