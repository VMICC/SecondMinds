# Wiki

Clean notes live here, one topic per file, with kebab-case filenames. AI-managed knowledge, written clean and kept current.

- General notes live at this level.
- `people/` one file per person.
- `brand/` voice, clients, differentiator, stories, and brand material.
- `business/` how the work works: offers, market, proof, and content angles.
- `guardrails.md` ships here with the general starters installed; the interview asks about the owner's industry rules (never assumed in this edition) and adds the owner's own rules. Anything public-facing gets checked against it.
- `ai-context.md` is created at the end of the first-run interview: the whole brain compressed into one portable file the owner can paste into any other AI tool.

Notes are created and updated from files in `/raw` by `prompts/translate.md`. Always read an existing entry before merging new material into it.
