# Guardrails

The rules that keep this owner's marketing and client work out of trouble. This edition ships with only the general starters below, on purpose: "business owner" covers fields with completely different regulators, so no industry's rules are assumed here. The first-run interview (Block 7) asks about the owner's field, writes the answers into this file, and flags anything unknown instead of guessing at it. From that block onward, the assistant checks anything public-facing against this file before showing it to the owner.

> This is not legal advice and the assistant is not a compliance officer. These are the common guardrails that keep most business owners out of trouble. Your field, your state, and your licensing body, if you have one, may be stricter. Before you run paid ads or publish anything public that makes a claim, have the right person look at it once.

## General starters (every field)

- Never guarantee a result, an outcome, an income, or a timeline, in writing or out loud in a recorded format.
- Never publish a number (clients served, results, percentages, rankings) that cannot be backed up from a record the owner actually has.
- Statistics and claims in content carry their source and their period. A number without a source does not ship.
- A client's name, photo, story, or result in public material needs that client's permission first. Getting it is the owner's job, not the assistant's.
- Testimonials describe what actually happened for that client. They are never edited into a stronger claim, and never presented as typical unless the owner can show they are.

## This owner's field (filled in by the interview, Block 7)

The interview asks, and the answers land here. Anything left blank was not known at build time:

- Licensing board or certifying body, and whether its advertising rules are known:
- Claims or promises this owner may never make:
- Required on anything published (disclaimer, license or registration number, results disclosure):
- Content pulled or flagged in this industry, and what for:

**If any line above is blank or marked not known:** this owner's industry rules were not fully known at build time. Confirm them with a professional in this field before publishing anything that makes a claim, a guarantee, or a comparison, and register that check as unfinished work until it is done.

## The accountability rule

An AI drafting something does not move responsibility for it. The owner's name is what the public sees, and the owner owns everything published under it. "The AI wrote it" is never a defense, so nothing public leaves this system without the owner's approval, through `/queue`, like everything else outbound.

## The owner's own rules

Filled in by the first-run interview (Block 7) and added to whenever a new rule shows up in real work:

- Never do without asking first:
- Private, belongs only in `/CONFIDENTIAL` (existence noted here, content never copied here):
