# Banned Words

## Why this matters

Voice is brand. It is a big reason a customer picks one business over another.

An AI left on its own writes like a brochure: filler, hype, and corporate phrases. The owner then has to hand-edit every draft, forever. That is a hidden tax on every piece of content.

Fix it once, at setup, with one question and a starter list. After that, every draft starts closer to done.

## The one question

Ask this once, during setup:

> **What words or phrases do you never want used in anything written for you?**

- A short answer is fine. Even 3 to 5 items help.
- If the owner cannot think of any, ask: "What do people in your field say that makes you cringe?"
- If there is still nothing, write "none yet" and use the starter list below. Add personal bans later, as bad drafts show up.
- Do not ask this question again in later sessions.

Write the answers in the Personal Bans section at the bottom of this file. If it is not written here, it will be forgotten.

## Starter list: never use these

### Words

actually, blueprint, certainly, comprehensive, delve, disruptive, effortlessly, elevate, embark, empower, essentially, exciting, facilitate, furthermore, groundbreaking, harness, impactful, innovative, journey (as a metaphor), landscape (as a metaphor), leverage, literally, maximize, meticulous, moreover, navigate (as a metaphor), optimize, paradigm, realm, really, revolutionary, robust, seamless, significantly, simply, streamline, synergy, tapestry, transform, truly, ultimately, unlock, unprecedented, utilize, very, vibrant

Plain rule: if a word sounds like it belongs in a keynote or a press release, cut it, even if it is not on this list.

Notes:

- **just** is banned as a softener: "just checking in," "I just wanted to." It is fine when it means "only."
- **honest / honestly** are banned as qualifiers. Everything you write is honest. Saying one line is the honest one makes the rest sound like they were not.

### Phrases

Openers:

- "I just wanted to reach out"
- "I hope this email finds you well"
- "Just checking in"
- "Just a quick note"
- "Hi there!"

Announcements. Skip these and start with the real sentence:

- "Here's the truth" / "the truth is"
- "Here's the deal"
- "Here's what nobody tells you"
- "I'll be straight with you"
- "Let's be real" / "let's be honest"
- "Real talk"
- "To be honest" / "my honest opinion"
- "Because here's the thing"

Filler:

- "Per my last email"
- "Going forward"
- "At your earliest convenience"
- "Circle back" / "touch base"
- "Reach out" (say call, email, or text)
- "Move the needle"
- "Win-win"
- "Best practices"
- "Deep dive" (as a noun)
- "Bandwidth" (when you mean time)
- "Game changer"
- "It's important to note"
- "Let's dive in" / "let's unpack"

Closings. End with a real next step instead:

- "Looking forward to hearing from you"
- "Don't hesitate to reach out"
- "Thanks in advance"
- "Best regards"

### Business clichés

- "Your trusted partner"
- "Going above and beyond"
- "I'm passionate about helping businesses succeed"
- "Take your business to the next level!"
- "We help companies grow" (with nothing specific after it)
- "Don't miss this opportunity!"
- "Call today!" (with no reason attached)
- "Tag a business owner who needs this!"
- "Did you know..." as an opener
- "In today's economy..." as an opener
- "Just launched!" with no story and no numbers

### Email only

These also trip spam filters:

- "Guaranteed," "free money," "no risk"
- "Act now!," "urgent," "limited time"
- All caps subject lines, subject lines over 50 characters, more than 3 links

## Banned shapes

Clean words can still sound like a machine if the shape is wrong. Rewrite when you see:

1. Three short punches in a row (a triplet).
2. "It's not X, it's Y" or "This isn't just X, it's Y."
3. A question followed by a list as the answer.
4. Three or more "even if you..." lines in a row.
5. Fragments with no person in them. Name who did it.
6. More than one call to action in one piece. One piece, one next step.

## Punctuation

- Em dashes: never. Use a comma, a colon, or a period.
- En dashes: only in numeric ranges.
- Exclamation points: one per message at most.
- Semicolons and ellipsis: avoid.
- Emojis: one or two at most in a social post, none in formal email.
- All caps: never for a full sentence.

## Say this instead

| Instead of | Write |
|---|---|
| reach out | call, email, or text |
| leverage, utilize | use |
| facilitate | help, run, set up |
| your trusted partner | your name, who you serve, one real result |
| going above and beyond | the specific thing you did, with a date or number |
| just checking in | the real reason you are writing, in the first line |

## Exceptions

Only three:

1. **Literal use.** The word is fine when it means what it actually means.
2. **A client's exact words.** Quotes and testimonials keep their wording. This list governs what we write, not what they said.
3. **Legal or regulated wording.** If a term is the correct legal term, accuracy wins.

## Personal bans

Words and phrases I never use:

1. 
2. 
3. 
4. 
5. 

Phrases I do use, that should show up in my drafts:

1. 
2. 
3. 

## Keep it working

- Load this file every time anything client-facing is drafted.
- Before anything ships, scan it for a banned word, phrase, shape, or em dash. Fix hits before sending.
- Read it out loud. If it sounds like a brochure, rewrite it.
- When a draft sounds wrong, fix the draft **and** add the word or phrase to Personal Bans above, so it only has to be fixed once.

## Done when

- [ ] The question was asked at setup and the answer is written above
- [ ] The starter list is on
- [ ] This file loads with every draft
