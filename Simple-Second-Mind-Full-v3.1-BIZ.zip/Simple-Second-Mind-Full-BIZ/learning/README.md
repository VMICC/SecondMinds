# Learning

Where the Learn prompt keeps its work. Learn reads yesterday's activity once a day and writes proposals for improving the playbook. It applies nothing on its own.

- `proposals/` holds one proposal file per day, named `YYYY-MM-DD.md`.
- `state.md` is the loop's own memory: last run, sources read, totals.
- `applied-changes-log.md` records what the owner applied, and the version saved before each apply, so any change can be reverted.
