# Learn state

- Last run: never
- Sources read:
- Total proposals generated: 0
- Active proposals:
