# Applied changes log

What the owner applied from the Learn proposals, newest last. Each entry names the destination file, the change, and the version saved before applying, so the change can be reverted.
