# Proposals

One file per day, named `YYYY-MM-DD.md`, written by the Learn prompt. Every proposal has a checkbox. The owner checks a box only by telling the assistant to apply that proposal number. Nothing in this folder is ever applied automatically.
