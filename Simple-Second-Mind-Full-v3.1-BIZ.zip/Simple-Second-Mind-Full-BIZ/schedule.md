# Schedule

The timetable for this system. One assistant runs it. Start with one heartbeat a day.

## Start here

Run ONE heartbeat a day: the morning brief. Learn rides the translate sweep below: after translate runs, the same job runs `prompts/learn.md` over yesterday's work, silently, and logs its proposal count in `today.md`. The brief mentions that count in one line. Before the very first brief, the first-run interview must be done (`memory.md` status INTERVIEWED). The brief does four things, in this order:

1. **Rollover with task forwarding** (`sops/agent/task-forwarding.md`): mark yesterday's tasks (✓ X → ←) before archiving yesterday's `today.md` to `archive/daily/`. ✓ and X items are logged in `tasks.md`; → items are rewritten onto the new `today.md` with their forward count; ← items move to `tasks.md`. Flag any item at (→×3) in the brief for a decision.
2. **The brief itself:** today's tasks, deadlines, and anything waiting on the owner, in one message.
3. **One unfinished item:** surface ONE item from `unfinished-work.md`, oldest first. If the owner says "more" or "ok", up to 2 more. Never more than 3 a day. If the list is empty, say nothing about it. For a NEED TO CREATE item, the line includes the offer to draft it (questions, scan their work, or scan a source they name).
4. **Approvals:** put every outbound draft in `/queue` for the owner's approval. Nothing sends from anywhere else.

Weekly and monthly reviews ride this same brief (Mondays, and the 1st of the month). They are not new heartbeats. Method: `sops/agent/weekly-and-monthly-review.md`.

Do not add more heartbeats until the daily brief is a habit. One run a day is enough to start; tighter intervals cost more and mostly repeat the same brief. Tighten only when the owner says so.

## Wiring into a scheduler (the two jobs)

Only two jobs ever get wired. The scheduler holds a time and a one-line pointer; every real instruction stays in these files.

Job 1, the translate sweep, daily, 30 to 60 minutes before the brief:

```
Open this folder. Read AGENTS.md. Run prompts/translate.md over everything new in raw/. Then run prompts/learn.md over yesterday's work. Log what you processed in today.md under Agent log.
```

Job 2, the morning brief, daily at the brief time in `memory.md`:

```
Open this folder. Read AGENTS.md and memory.md. Run the morning routine in schedule.md, steps 1 to 4. Send me the brief.
```

When both jobs exist in the owner's scheduler, set `Schedules wired: YES (YYYY-MM-DD)` in `memory.md`.

Until that line flips to YES, the system is not live: nothing runs on its own. The schedule check in `AGENTS.md` offers this wiring at every startup until it is done. Declining only defers it to the next session; the offer does not go away.

**The 30-minute floor.** Never wire any job faster than every 30 minutes, unless the owner explicitly says to. Every scheduled run costs tokens out of the same bank the owner chats and works from. Runs set too fast mostly repeat the same work while they drain that bank, and enough of them can exhaust it entirely, leaving the model nothing for real work. That is why the starting rhythm here is one run a day, and why tightening an interval is always the owner's explicit call, never the assistant's.

## Option: day/night cadence (work hours / sleep hours)

Off by default. It matters only once you run checks more often than the daily brief. The idea: the system pays attention while you are awake and rests while you sleep. The windows below are starting defaults. Your live values are the matrix at the end of this section, and they change just by you saying so.

- **Awake window:** 6:00 AM to midnight. Checks run at your chosen interval, never faster than the 30-minute floor.
- **Asleep window:** midnight to 6:00 AM. The interval stretches to one slow check for the whole window (a single run, for example at 3:00 AM). An asleep check is silent unless something is truly urgent (a deadline today, someone waiting on a reply). Anything else it finds is written into `today.md` and held for the morning brief.
- **Weekend evenings:** on Friday, Saturday, and Sunday the asleep window starts at 10:00 PM, not midnight.
- The daily cycle does not change: translate sweep before the brief, brief at the time in `memory.md`.

The simple wiring: most schedulers cannot change an interval by time of day inside one entry, so the same job gets two time ranges, one per window, with the identical pointer prompt. The job's instructions never change, because they live in this file. You turn the cadence on or off with one switch in `memory.md`. The windows and the interval live only in the matrix below.

### The six questions

The assistant asks these at setup (the interview's Finish step points here) and again any time you want the cadence changed. One at a time. Every question has a default; "use the default" is a complete answer to all six.

1. What time do you want the morning brief? (That time goes in `memory.md`.)
2. Between briefs, should the system check on a heartbeat, or stay once a day for now? If a heartbeat: pick a starting interval of 30 minutes, 1, 2, 4, or 6 hours. Never faster than 30 minutes.
3. What are your awake hours? Default: 6:00 AM to midnight.
4. What are your asleep hours? Default: midnight to 6:00 AM.
5. Do Friday, Saturday, and Sunday evenings slow down earlier? Default: yes, asleep from 10:00 PM on those days.
6. During asleep hours: no check at all, or one slow silent check (about 3:00 AM) that surfaces only a true urgency? Default: one silent check.

### The cadence matrix (your live values)

| Days | Awake: checks every [interval] | Asleep: one slow check, silent unless urgent |
| --- | --- | --- |
| Mon to Thu | 6:00 AM to midnight | midnight to 6:00 AM |
| Fri | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |
| Sat | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |
| Sun | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |

[interval] starts as: once a day, the brief only (no heartbeat). Change any cell by telling the assistant. The assistant updates this table and the wired jobs to match, and this table stays the only place the windows and the interval live.
