Restricted information. Do not copy contents into other folders. The assistant logs only that an item exists here, never what it says. Contents are local only under the root `.gitignore`.
