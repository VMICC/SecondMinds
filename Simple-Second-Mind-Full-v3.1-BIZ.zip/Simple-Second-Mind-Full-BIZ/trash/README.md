# trash

The bucket. Nothing in this folder system is ever permanently deleted by the assistant. If something has to be removed from where it is, it is moved here with a date prefix: `YYYY-MM-DD-name`.

Rules:

- Only the owner empties this folder. The assistant never does.
- Nothing here is referenced by the system. If a finished note links to a file, that file belongs in `assets/`, not here.
- This is not `archive/`. Archive is the permanent record. This is the bin on the way out.
- Contents are local-only under the root `.gitignore`. Only this README uploads, so the folder explains itself.
- Leave this folder out of backups on purpose: it is trash.
