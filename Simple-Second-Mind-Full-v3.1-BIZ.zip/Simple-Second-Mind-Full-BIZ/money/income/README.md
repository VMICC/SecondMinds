Income records: what came in, from what, when.
