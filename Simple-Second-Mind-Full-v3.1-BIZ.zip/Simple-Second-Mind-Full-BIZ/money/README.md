# Money

The money, all in one place. Records live here; the assistant works on them when you ask. Plain text notes, one file per item or per month, named with the date when time matters (for example, `income/2026-10-commissions.md`).

- `income/` money in: what came in, from what, when
- `expenses/` money out: what went out, for what, when
- `property/` property money: values, costs, and records per property

Rules:

- Records, not accounts. Never put account numbers, passwords, or login details here. Those belong in `/CONFIDENTIAL`, and usually in no file at all.
- Receipts and statements are big files. They live in `/assets`, and the note here points at them.
- When the assistant totals or summarizes money, it shows its source files so you can check the math.
