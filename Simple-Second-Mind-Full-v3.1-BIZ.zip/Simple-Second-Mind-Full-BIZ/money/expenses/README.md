Expense records: what went out, for what, when.
