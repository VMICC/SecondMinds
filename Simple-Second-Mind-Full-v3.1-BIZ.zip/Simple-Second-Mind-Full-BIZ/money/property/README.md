Property money records: values, costs, and per-property notes.
