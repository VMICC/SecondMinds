# Memory

Status: NOT INTERVIEWED
Schedules wired: NO

The standing context. Read first, every session. Keep it short and current.

On first run, the assistant runs the interview in `prompts/first-run-interview.md`. When it completes, flip the status line above to `Status: INTERVIEWED (YYYY-MM-DD)`, and flip the schedules line to YES with the date when both jobs in `schedule.md` exist.

This file holds only the cheat sheet and the system settings. The deep answers live in the wiki.

## About me (cheat sheet)

- Name:
- Call me:
- Role:
- Topics I think about:
- Timezone:
- Voice preference:
- Things I don't want in the wiki:

## System

- Morning brief time:
- Day/night cadence: off (windows and interval live in the cadence matrix in `schedule.md` only)
- Unfinished work reprompt: 1 item a day in the brief (up to 2 more if I say ok, never more than 3)
- Tasks: today's list in `today.md`, everything else in the Master Task List in `tasks.md`
- Learning: daily proposals in `learning/proposals/`, state in `learning/state.md`, applied only when I say "apply proposal N"
