Social media procedures and posting formats. One procedure per file. Start from `../sop-template.md`. Every draft post goes in `/queue` for approval before it goes out.
