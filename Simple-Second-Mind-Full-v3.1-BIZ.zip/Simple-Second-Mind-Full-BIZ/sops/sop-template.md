# SOP: <name of the procedure>

**Purpose:** What this procedure achieves, in one line.
**When:** What triggers it (a date, an event, a request).
**Owner of the outcome:** The owner approves; the assistant does the labor.

## Steps

1.
2.
3.

## Done when

- The finished result is: <what done looks like>
- It is filed at: <folder or file>
- The run is logged in `today.md` under Agent log.

## Notes

- Drafts for anyone else go in `/queue` for approval. Nothing sends directly.
- If a step cannot be completed, log why in `today.md` instead of improvising.
