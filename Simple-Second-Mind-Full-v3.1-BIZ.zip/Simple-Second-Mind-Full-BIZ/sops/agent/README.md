# Agent SOPs

Procedures for working with the assistant itself: how tasks move, how the day rolls over, how reviews run.

- `task-forwarding.md` how tasks move between `today.md` and the Master Task List without getting lost.
- `weekly-and-monthly-review.md` the reviews that ride the Monday and 1st-of-the-month briefs.
