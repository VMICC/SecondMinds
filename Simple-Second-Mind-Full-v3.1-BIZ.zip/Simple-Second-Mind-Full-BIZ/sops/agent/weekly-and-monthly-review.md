# SOP: Weekly and Monthly Review

How the two reviews work. Neither is a separate meeting or a separate scheduled job. Both ride the morning brief in `schedule.md`.

## Weekly review (rides the Monday brief)

1. Look at `tasks.md`, This week: every unfinished top priority is re-evaluated. Schedule it into a day this week, or send it back to the master list with a ←.
2. Check forward counts in `today.md` and `tasks.md`. Any item at (→×3) gets the decision question in the brief: still important, delegate it, ← defer it with a date, or X it.
3. Look at `unfinished-work.md`. Nothing new here; the daily one-item surfacing keeps running. The weekly review only notes if the list is growing faster than it shrinks.
4. The owner confirms the week's A priorities. The assistant updates `tasks.md` the same day.

## Monthly review (rides the brief on the 1st)

1. Carry every still-active item on the Master Task List into the new month. Nothing active is dropped in the move; the owner confirms any X.
2. Move last month's Closed log from `tasks.md` to `archive/monthly/YYYY-MM-tasks.md`.
3. Move last month's daily pages to `archive/daily/` if any are still at the root.
4. Check the system settings in `memory.md`: brief time, cadence on or off, schedules still wired. Fix anything stale and note the fix in the brief.

## The split

The assistant does all the labor: transcribing, counting, re-listing, archiving, flagging. The owner does only the judging: confirming priorities, and answering the (→×3) question when it comes.
