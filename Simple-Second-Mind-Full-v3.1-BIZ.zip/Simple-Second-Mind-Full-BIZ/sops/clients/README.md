Client work procedures: first contact, delivery, follow-up, and staying in touch. One procedure per file. Start from `../sop-template.md`.
