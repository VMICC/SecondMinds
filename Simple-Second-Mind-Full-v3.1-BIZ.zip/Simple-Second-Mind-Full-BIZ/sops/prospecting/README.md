Prospecting procedures: expireds, FSBOs, probate, sphere, follow-up. One procedure per file. Start from `../sop-template.md`.
