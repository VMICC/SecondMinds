Operations procedures: how the work itself runs behind the scenes. One procedure per file. Start from `../sop-template.md`.
