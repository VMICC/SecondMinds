# My Second Brain: Full

**Full v3.11-LO, October 2026. Loan officer edition.** If you are comparing copies, this line is the version. The changelog at the bottom of this file says what changed in each version. The -LO tag means this build is written for licensed loan officers: its interview, proof questions, and compliance starters all assume a mortgage professional. Real estate agent and general business builds carry their own tags (-RE and -BIZ).

I dump raw stuff into `/raw`. One AI assistant turns it into clean notes in `/wiki`, keeps my day in `/today.md`, and runs on a simple schedule. That's it. This is the Full version of the Lite second brain: same simple loop, plus the protections, scheduling, and organization that a working system needs. There is one assistant here, not a team. When this outgrows one assistant, that is a different system.

## First run

Open this folder with your AI assistant. Two things happen at startup, in this order:

1. The assistant offers to wire the two scheduled jobs in `schedule.md` (the translate sweep and the morning brief). Until they exist, `memory.md` says `Schedules wired: NO` and the offer comes back each session. Declining only puts it off to next time.
2. If `memory.md` says `Status: NOT INTERVIEWED`, the assistant runs the interview in `prompts/first-run-interview.md` before any other work. It imports what your other AI tools already remember first, grades what it finds Real, Thin, or Empty, verifies instead of re-asking, and asks only what is missing. Facts are tapped, stories are told in your own words, and the client, differentiator, and content sections are generated from your answers and shown back for one correction. It ends by having you type one question and watching your own folder answer it.

## The loop

1. Write or drop anything into `/raw`.
2. The assistant runs `prompts/translate.md`: raw material becomes clean notes in `/wiki`, procedures in `/sops`, money records in `/money`, and processed originals move to `/archive`.
3. Read the updated `/wiki`, and start the day from `/today.md`.

Once a day, the same sweep also runs learn: yesterday's work becomes proposals for improving the playbook, filed in `/learning` for your approval.

## The daily rhythm

One heartbeat a day to start: a translate sweep, then a morning brief. The brief rolls yesterday's tasks forward, surfaces one item from `unfinished-work.md`, and puts every outbound draft in `/queue` for your approval. The full timetable, the 30-minute floor, and the optional day/night cadence live in `schedule.md`.

## Folders

- `/raw`: anything I capture: notes, documents, screenshots, links. Unprocessed, local only
- `/wiki`: clean notes written by the assistant (people, brand, and business get their own subfolders)
- `/sops`: approved procedures, one page each, organized by area
- `/projects`: active work, one folder per project, each with its own README
- `/prompts`: reusable prompts for working with this folder
- `/skills`: reusable skills for the assistant, one file per skill
- `/money`: money records: income, expenses, property
- `/assets`: big files a finished note points at. Local only
- `/archive`: processed originals and old daily pages. A permanent record, local only
- `/queue`: outbound drafts waiting for my approval. Nothing sends from anywhere else
- `/CONFIDENTIAL`: restricted material, and nowhere else. Local only
- `/trash`: anything removed lands here, date-prefixed. Only I empty it
- `/learning`: the daily learning loop's proposals, state, and applied-changes log
- `/examples`: one worked example to read before you start, plus a five-minute exercise. Delete it when you are done with it

## Root files

- `AGENTS.md`: the one instruction file. Every rule lives here and only here
- `CLAUDE.md`, `GEMINI.md`: short pointer files for tools that look for their own filename. They point at `AGENTS.md`, they never copy it
- `memory.md`: the cheat sheet: who I am, my system settings, interview and schedule status. Read first, every session
- `today.md`: today's page: ranked tasks, notes, and the assistant's log
- `tasks.md`: the Master Task List: everything not scheduled today
- `unfinished-work.md`: the don't-know register. Nothing I cannot answer gets skipped and forgotten
- `schedule.md`: the timetable: the two jobs, the brief, the cadence option
- `manifest.md`: the inventory: every file and folder, one line each

## One source of truth

`AGENTS.md` is canonical. Tools that insist on their own filename get a two-line pointer stub instead of a copy, so there is never a second version to drift. Stubs, not shortcuts that break when this folder is zipped and opened on another computer.

## Local only, by design

The whole folder can be kept in version history so the text is never lost, and one `.gitignore` at the root keeps heavy or restricted material on this machine only: the contents of `/assets`, `/raw`, `/archive`, `/CONFIDENTIAL`, and `/trash` never upload (each folder's README does, so the folder explains itself), and neither do heavy file types anywhere else. Your AI reads your local disk, so ignored files work exactly like tracked ones.

Back those local-only folders up once with your normal computer backup. Version history is not their backup. If the machine dies, version history rebuilds the text; only a backup rebuilds the originals. `/trash` is left out of the backup on purpose: it is trash.

## Changelog

- **v3.11-LO, October 2026:** the prefill handoff is wired into the first run. The interview asks for the filled handoff (its Step 1) before its first question, and `AGENTS.md` gains a prefill check that watches `/raw` at every startup until the interview is complete: silent when nothing is there, ingesting a found prefill before any other interview work, and never ingesting the same file twice. A prefill can also arrive mid-interview without restarting confirmed blocks, two prefills that disagree are both shown at verification instead of being merged, and confirmed answers outrank prefill answers. Skipped questions gain their later path: a final pass over the skips at the Finish, and a named re-offer at the start of their block on any re-run, while don't-know items keep the unfinished-work path they already had (one per day in the brief, up to 3, with the draft offer). Nothing else changed.
- **v3.10-LO, October 2026:** fair housing and fair lending completed for the loan officer build. `wiki/guardrails.md` gains a full Fair Housing and Fair Lending section (the Fair Housing Act and ECOA protected bases stated plainly, no discouraging applications, same underwriting and pricing standards for everyone with documented exceptions, no redlining, no steering, government monitoring information handled as required and never used in a decision, independent appraisals with a reconsideration of value path, advertising and targeting under the same rules, exact application data for HMDA, and same-day escalation of any discrimination concern), and the Equal Housing Lender starter is tied to that section instead of standing alone as a logo rule. The interview's compliance block now installs and walks that set out loud, and its company-rules question covers fair lending rules as well. Nothing else changed from v3.1-LO.
- **v3.1-LO, October 2026:** the loan officer edition, an alternative build of v3.1-RE for licensed loan officers only. Everything profession-specific was swapped, nothing structural changed: the first-run interview asks loan officer proof (NMLS ID asked once, loans closed in the owner's own words, states licensed, loan types), builds borrower profiles per type (first-time, move-up and jumbo, refinance, self-employed, VA, investor) from 3 questions each, builds the differentiator on the borrower journey from first contact through after funding, collects borrower words in four buckets (first call, rate shoppers, credit anxiety, ready to apply), and installs loan officer compliance instead of fair housing. `wiki/guardrails.md` ships with the rate and approval starters, the NMLS and equal housing starters; the mortgage cliché section replaces the real estate clichés in `wiki/brand/banned-words.md`; and the SOP areas are borrower and partners instead of buyer and seller. The worked example set is unchanged from v3.1 (it demonstrates the raw-to-wiki processing); its GAP fixes were re-verified for this build.
- **v3.1, October 2026:** the worked example gained its second half. `/examples/processed` now holds the same guide after processing (seven one-topic files, built by Claude, then checked: broken links, the wrong source filename, the missing overview, the full question wording, and the dropped worksheet all fixed), so the example shows a real before and after. Exercise updated to compare against the processed set.
- **v3, October 2026:** worked example added in `/examples` (a complete mini guide in markdown, plus a five-minute exercise); the first-run interview gained a banned-words question and an optional real estate section (stories, client words, market, proof); `banned-words.md` added in `/wiki/brand` with its starter list; this version stamp added.
- **v2, October 2026:** the Learn prompt wired in (`prompts/learn.md`, the `learning/` folder, and the apply-only-on-say-so rule). Learn rides the translate sweep; it is not a third job.
- **v1, October 2026:** first Full release: the Lite second brain plus the schedule, memory, unfinished work, trash, approvals queue, CONFIDENTIAL, expanded SOPs, skills, and money folders. One assistant, no team folders.
