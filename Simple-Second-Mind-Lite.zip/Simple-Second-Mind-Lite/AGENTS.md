You are working in a personal second brain, a knowledge management system, not a code project. Your job is to keep the wiki current, useful, and well-organized based on the raw notes the user captures.

Read `README.md` first. This is the source of truth for the system. This file gives you the additional context you need to do good work here.

---

## About the User

<!-- CUSTOMIZE this section -->

- **Name:** <your name>
- **Role:** <what you do, for example "founder building software tools", "designer at a growing company">
- **Topics I think about:** <comma-separated list, for example "product strategy, AI assistants, health, sales">
- **Voice preference:** <how you want wiki entries to read, for example "terse and direct, no filler", "clear and explanatory", "bulleted and scannable">
- **Things I don't want in the wiki:** <for example "no motivational filler", "no executive summaries on short entries", "no emojis">

---

## Common Tasks

- **Translate raw:** run the prompt in `prompts/translate.md` against `/raw`.
- **Project digest:** summarize a `/projects/<name>/` folder into its README.
- **Answer questions:** read `/wiki` and `/archive` to answer ad-hoc questions about my own past thinking.

---

## Hard Rules

1. **Never delete** anything from `/raw` or `/archive`. Move only, never delete.
2. **Never overwrite** a `/wiki` entry blindly. Always read it first, then merge.
3. **Never modify** `/archive` after a file lands there. It is a permanent record.
4. **Save a version after meaningful changes** with a clear message (for example `translate: 4 inbox files processed`).
5. **When uncertain, log it in the entry** rather than guessing.

---

## Wiki Voice and Structure

<!-- CUSTOMIZE if needed -->

- Default tone: clear, factual, terse.
- Preserve my own phrasing when it carries signal. Don't sand everything into neutral encyclopedia tone.
- Headings only when the entry is long enough to need them.
- Bullets only when the content is genuinely a list.
- One topic per file. Kebab-case filenames.

---

## Out of Scope

- Web browsing unless I explicitly ask.
- External service calls outside of declared automations.
- Anything touching accounts, payments, or authentication.
- Editing files in `/raw` or `/archive`.
