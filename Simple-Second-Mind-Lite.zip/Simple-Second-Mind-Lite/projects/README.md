# Projects

Active work lives here, one folder per project.

Create a folder for each project and give that folder its own README describing the project.
