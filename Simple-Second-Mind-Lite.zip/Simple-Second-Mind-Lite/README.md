# My Second Brain

I dump raw stuff into `/raw`. An AI assistant turns it into clean notes in `/wiki`. That's it.

## Folders

- `/raw`: anything I capture: notes, documents, screenshots, links
- `/wiki`: clean notes written by the AI assistant
- `/projects`: active work, one folder per project, each with its own README
- `/archive`: processed `/raw` files land here so I can see what's been handled
- `/prompts`: reusable prompts for working with this folder

## The Loop

1. Write or drop anything into `/raw`.
2. Run an AI assistant with the prompt in `prompts/translate.md`.
3. Read the updated `/wiki`.

Keep a version history of this folder so nothing is ever lost.
