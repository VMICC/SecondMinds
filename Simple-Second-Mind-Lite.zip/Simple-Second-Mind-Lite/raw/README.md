# Raw

Drop anything you capture here: notes, documents, screenshots, and links.

Files in this folder have not been processed yet. Do not edit files here after dropping them in.
