# Wiki

Clean notes live here, one topic per file, with kebab-case filenames.

Notes are created and updated from files in `/raw`. Always read an existing entry before merging new material into it.
