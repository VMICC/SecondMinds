# First-Run Interview: Loan Officer Edition

The setup interview for this second brain, written for a licensed loan officer. Every question, proof metric, borrower type, and compliance starter in it assumes a mortgage professional. This is the v3.1-LO interview: fewer questions asked flat, more generated from the answers and shown back for one correction.

## What this does

This interview turns a blank folder into a loan officer's second brain. It does not start with questions. It starts with what the loan officer already has. Material exported from other AI tools, an old bio, or an earlier version of this brain usually answers half of this interview before a single question is asked. So the order is fixed:

1. **Import first.** Drop exported files into `/raw`, or say "none".
2. **Ingest.** The assistant runs `prompts/translate.md` over `/raw`.
3. **Scan and grade.** The assistant checks the whole folder, and any earlier brain the loan officer points to, and grades every foundation Real, Thin, or Empty (see Step 2).
4. **Verify.** Found answers are shown back for confirmation, not asked again from scratch.
5. **Ask only what is missing.** One question at a time. Facts are tapped, stories are told, and whole sections are generated from earlier answers instead of asked.

## Running this again later

This interview can be run again at any time. It will not ask questions that are already confirmed.

Every answer carries one tag:

- `[confirmed YYYY-MM-DD]` the loan officer said it and confirmed it
- `[imported, not yet verified]` it came from a file, the loan officer has not confirmed it yet
- `[skipped]` the loan officer chose to skip it
- `[open]` not asked yet, or no usable answer yet

A gap the loan officer cannot fill gets a different tag. It is not an answer state:

- `[UNFINISHEDWORK: NOT KNOWN]` the loan officer does not know yet; it needs finding, checking, or deciding
- `[UNFINISHEDWORK: NEED TO CREATE]` it does not exist yet; it has to be made

Every unfinished item is also registered in `unfinished-work.md`. From there it comes back one per day in the morning brief, until it is answered and re-tagged `[confirmed]`.

On a re-run, the assistant skips every `[confirmed]` question, works only on what is `[open]`, `[skipped]` if the loan officer wants to revisit it, or `[imported, not yet verified]`, and ends with a short list of what changed. Foundations graded Thin (Step 2) get one thickening follow-up, never a rebuild.

## Rules for the assistant running this interview

- One question at a time. Wait for the answer before asking the next one.
- **Tap or Talk, marked on every question below.** Tap questions offer 2 to 4 likely answers as choices, plus a free-text escape, because facts and categories should never cost typing. Talk questions are answered in the loan officer's own words, dictated if they prefer, and never get canned options: a tapped story is an invented story. Questions with both parts go tap first for the shape, then talk for the substance.
- Write each answer down as you go, with its tag and date, so nothing is lost if the session ends early.
- Never ask for anything already confirmed in this folder, or said earlier in this session. Check first. If the loan officer already described their borrower during the voice questions, say it back and ask them to confirm it in the borrower block instead of asking fresh.
- Imported material outranks asking. If a file already answers it, verify it instead of asking it.
- Never treat imported or inferred material as fact. It stays `[imported, not yet verified]` until the loan officer confirms it. Generated profiles and positioning are labelled proposed until the loan officer confirms them.
- "Skip" is always a valid answer. Tag it `[skipped]` and move on. A whole block can be skipped the same way.
- "I don't know" is always valid too. Tag the gap, register it in `unfinished-work.md`, and move on. Do not press, do not guess.
- **Push once on a weak answer, then move on.** "I care about my borrowers" gets one sharpening choice (faster, clearer, more available, or something other loan officers do not attempt), never a loop of follow-ups.
- **Generate, do not ask,** wherever a block below says so. Drafting the one-liner, the borrower profile, and the content angles is the assistant's job. The loan officer's job is one correction pass.
- **Answer the question under the question.** "Can I change this later?" usually means "I am afraid of getting it wrong." Answer both, briefly, then continue.
- **Invite questions out loud three times:** after Block 1, halfway through, and before the Finish. Silence usually means stuck, not satisfied.
- **Warn before long stretches of file work,** and report anything fixed as fixed. A repair reported without its result reads as a fault.
- **Offer voice dictation twice:** once at the start, and again at the stories block, where it pays off most. Nowhere else.
- **Running behind: compress, never stall.** Take the shortest usable answer, tag the section Thin, and move on. A finished thin file beats an unfinished session.
- Never invent facts, stories, numbers, license details, loan results, or rates. Never state a rate anywhere in this interview's output. If something does not exist yet, write the placeholder: **Add real material here later.**
- Do not ask for passwords or account access.
- Anything the loan officer marks private goes in `/CONFIDENTIAL`, and only its existence is noted anywhere else.

## Writing defaults (confirm in Block 2, then follow everywhere)

- Write like you are talking to one person, not an audience. Normal language, contractions, mixed sentence lengths, direct statements.
- Simple words a busy person gets on the first read.
- Say it once, clearly, and move on.
- No em dashes. Use a period, a comma, a colon, or parentheses.

---

## Step 1: Import your existing material

Assistant: do not ask any interview questions before this step is offered. Say this, in plain words:

> Before we start, let's not make you repeat yourself. If you have used any AI tool before, export or copy what it remembers about you and your business, and drop those files into the `raw/` folder. Good things to include: memory or "about me" exports, a bio you already wrote, your current marketing pieces, and anything else that already describes you and your borrowers. If you built an earlier version of this brain, tell me where that folder lives too, and I will carry what is in it instead of asking it again. Tell me when the files are in `raw/`, or say "none" and we will go straight to the questions.

If the loan officer says "none," tag Step 1 `[skipped]` and go to Step 3.

## Step 2: Run translate, scan, and grade

1. Run the prompt in `prompts/translate.md` over everything in `/raw`. Processed files move out of `/raw` the way that prompt directs. Never delete anything.
2. Scan the whole folder, plus any earlier brain folder the loan officer named, and build a pre-fill list for every block below: which foundations have material, and where it came from. Do not show the loan officer the whole list at once. Use it silently in Step 3.
3. **Grade each foundation:**

   - **Real:** it has the loan officer's actual content. Carry it. After the loan officer verifies it, tag it `[confirmed]` and never ask it again.
   - **Thin:** a heading, one vague line, or filler that could describe any loan officer. Carry what is there, then ask the one follow-up that thickens it.
   - **Empty:** placeholder text, an unanswered prompt, or nothing. Treat it as never answered. Ask normally.

   When torn between Thin and Real, call it Thin and ask. One extra question is cheap; a hollow answer filed as fact makes every later draft sound generic.
4. **Carry-over confirmation.** If an earlier brain was found, confirm it is theirs before carrying anything, by quoting one concrete detail from it (a borrower type, a state, a phrase) and asking one tap: yours, or not yours. Not theirs means carry nothing and run the interview normally.
5. An earlier brain folder is never moved, renamed, edited, or deleted. It stays as the loan officer's backup, and the carry-over (source folder, date, which foundations carried) is logged in `today.md`.

## Step 3: Verify first, then ask what is missing

For each question: if the answer was found, show it back short ("I found this, is it still right?") for confirm, correct, or skip. If it is missing, ask it. One at a time.

### Block 1: Identity and loan officer proof

1. **[Talk]** What is your name, and what should the assistant call you?
2. **[Talk]** What company or lender are you with, and what is your NMLS ID? (The ID is a proof point here and a compliance field in Block 7. It is asked once, here.)
3. **[Talk]** What timezone are you in?
4. **[Tap]** How long have you been in mortgage lending? (Under 2 years / 2 to 5 years / 5 to 10 years / 10 years or more)
5. **[Talk]** How many loans have you closed? Your own number, in your own words. Never rounded, never estimated by the assistant.
6. **[Tap, then Talk]** What states are you licensed in? Tap the shape first (Just one state / Two or three / Four or more), then name the actual states. The names have to be the loan officer's.
7. **[Tap]** What loan types do you focus on? Multiple picks allowed (Conventional / FHA and VA / Jumbo / First-time buyer programs / Refinance / Self-employed and non-QM).
8. **[Tap, then Talk]** What have you actually done that you are proud of? Tap a doorway first (Volume / One specific result for one borrower / Recognition / Staying power), then tell the detail in your own words.
9. **[Talk]** What topics do you think about most? (The subjects this brain should be organized around.)

Answers go to the cheat sheet in `memory.md`. Loans closed, loan types, states, and the NMLS ID also seed the proof and guardrails files (Blocks 7 and 8 read them from here, they do not ask again).

### Block 2: Voice

10. **[Tap]** How do you naturally talk? Multiple picks allowed (Direct / Warm / High energy / Calm).
11. **[Tap]** When you are helping a borrower, which one are you? (The teacher / The advisor / The peer / Depends on the borrower)
12. **[Tap]** What do you never want to sound like? Multiple picks allowed (Salesy / Corporate / Hyped / Generic).
13. **[Talk]** What words or phrases do you never want used in anything written for you? (This is the banned-words question from `/wiki/brand/banned-words.md`. Ask it once, here, and never again in later sessions. A short answer is fine, even 3 to 5 items. If the loan officer cannot think of any, ask "What do other loan officers say that makes you cringe?" If there is still nothing, write "none yet": the starter list in that file stays on. Write the answer in the Personal Bans section of `/wiki/brand/banned-words.md`, not in the voice file.)
14. **[Talk]** Is there a piece of your own writing that sounds like you? (Drop it in `/raw` if so. It becomes the voice reference in `/wiki/brand/voice.md`.)
15. **[Talk]** What do you not want in the wiki? (For example: no motivational filler, no summaries on short entries, no emojis.)

The voice file is built from 10 to 15 plus the loan officer's example phrases in their actual words. The example phrases matter most: without them the file does nothing.

### Block 3: Borrowers and differentiator (generated, not asked flat)

Before asking anything here, re-read Blocks 1 and 2. If the loan officer already described a borrower, say it back and ask for confirmation instead of asking fresh.

16. **[Tap]** How many kinds of borrowers do you serve? (Just one / Two / Three or more / Let me explain)

Then, **for each borrower type, one at a time:**

17. **[Tap, then Talk]** Who do you serve? Tap the type (First-time borrowers / Move-up and jumbo buyers / Refinance borrowers / Self-employed and hard-to-qualify borrowers / VA borrowers / Investor borrowers), then one talk follow-up only: what kind of shape are they usually in when they come to you?
18. **[Tap]** What do you actually do for them? Not "I do loans," the thing they walk away with. Multiple picks allowed (A result they could not get alone / The stress and guesswork taken off them / It closes faster, or on better terms they qualify for / They understand every step as we go), plus their own words if none of these fit.
19. **[Generate, then Tap to confirm]** The assistant drafts the "I help [who] with [problem]" line from 17 and 18, shows it, and asks one tap: that is it, or close, let me adjust it. The loan officer never has to compose this sentence out loud.

**Then generate the full borrower profile** for each type, from these answers plus everything already in the folder, across: who they are, what they have already tried, their biggest fears (a denial, a rate surprise, a closing delay, paperwork that never ends), what they actually want, what blocks them, and why this loan officer. Label it proposed until the loan officer confirms it. Show it in full, then ask one question: "Anything in there wrong?" Fix what they name and move on. Never walk it section by section. Never average two borrower types into one profile.

**Then the differentiator, three combined questions:**

20. **[Tap, then Talk]** Walk me through how you take a borrower from first contact to funded, and past closing. Tap where to start (First contact and pre-approval / Under contract and processing / Underwriting and conditions / Closing and after funding), then talk it through.
21. **[Tap, then Talk]** What do you do better than most loan officers, or control in the process that others hand off? Multiple tap picks allowed (I am faster / I communicate at every step / I structure hard files / I stay involved after funding / I know something the others do not), then one talk follow-up on what they picked.
22. **[Tap]** When somebody chooses you, what happens differently for them? Multiple picks allowed (It closes on time / They always know where things stand / Fewer surprises / A plan, not just a rate quote / They come back and send people).

Never ask what mistakes other lenders make. Infer the contrast, or state it in the output.

**Then generate the differentiator file:** two or three name options for the loan officer's way of working (a real name, never a task list with a label), its steps from first contact through after funding, two or three "most loan officers / me" contrast lines, why it works in plain terms, three or four lines the loan officer can say out loud on a pre-approval call, and the one-liner. Rewrite anything generic before showing it: a line that could sit on any lender's website is not finished. No line in this file states a rate, promises an approval, or guarantees a timeline. If the loan officer is new, position on speed, availability, communication, and follow-through, never on invented experience.

23. **[Tap]** Should this sound more high-end, more direct, plainer, or is it right? One rewrite pass on their answer, then stop.

Borrower profiles go to `/wiki/brand/ideal-client.md`, one labelled section per borrower type. The differentiator goes to `/wiki/brand/differentiator.md`.

### Block 4: Stories

24. **[Tap]** Which of these do you have a real story for? Multiple picks allowed (Why I got into lending / A loan that almost died / A scared borrower / A mistake I learned from / The moment I knew I was good at this).

Remind the loan officer here to talk instead of type. Then take only the picks, **one at a time, all Talk:**

25. Why did you get into mortgage lending? What were you doing before?
26. Tell me about a loan that almost died, and what you did.
27. Tell me about a borrower who was scared or overwhelmed. What changed for them?
28. What is a mistake you made early on that you now protect borrowers from?
29. Tell me about a moment when you knew you were actually good at this.

Rules: keep the loan officer's exact words, and keep the hard parts, because the fear and the mistake are what make a story believable. One follow-up at most per story ("What did that feel like at the time?"), then move on. Skip is fine. Three real stories beat five padded ones. Never write a story the loan officer did not tell, never add a detail they did not give, and never include a borrower's identifying details in a story file. File each story in four parts: what happened, in their words, what it shows, where to use it. Stories go to `/wiki/brand/stories.md`.

### Block 5: Borrower words (pull first, ask only the gaps)

Do not open this block with questions. Read `/wiki/brand/ideal-client.md` and `/wiki/brand/stories.md` first, pull every line of real borrower language already there, and show it back with where it came from. If that covers the buckets below, say so and ask nothing.

Ask only for genuine gaps, one at a time, all **[Talk]**:

30. What does a borrower say to you on the first call, in their exact words?
31. What does a rate shopper say when they are comparing you to someone else?
32. What do people say when they are worried about their credit or their approval chances?
33. What is the sentence you hear that means someone is actually ready to apply?

Collect it raw. Do not clean it up and do not turn it into marketing copy. An empty bucket gets the placeholder and an unfinished-work tag, never an invented quote. Borrower words go to `/wiki/brand/client-words.md`.

### Block 6: Market and competitors

34. **[Confirm, do not ask]** "You told me you are licensed in [states from Block 1] and focus on [loan types from Block 1]. Still right?" A change here updates Block 1's answers, it does not create second ones. Loan types are confirmed here, never re-asked as a new question.
35. **[Tap]** Which part of your market do you know best? Multiple picks allowed (First-time buyer programs in my state / A specific metro or county / Refinance seasons / Self-employed borrowers). Skip this question if Block 1 and the profiles already answer it, and say so.
36. **[Talk]** Who are the two or three lenders or banks you lose loans to most, and what do they do well?

Competitor rule: never state a fact about a named competitor that the loan officer did not supply, and describe what they do well, never what is wrong with them. Never state a competitor's rate. If the loan officer does not know, do not guess and do not research it inside the interview: register it `[UNFINISHEDWORK: NOT KNOWN]` and move on. Market goes to `/wiki/business/market.md`.

### Block 7: Guardrails and compliance

No questions to open this block. Install the starters from `/wiki/guardrails.md` (they ship with this file: the rate and approval starters, the full fair housing and fair lending set covering discouragement, redlining, steering, monitoring information, appraisals, and ad targeting, and the NMLS and Equal Housing Lender starters, each with its plain-language why), and read the loan officer that file's opening line: this is not legal advice, and their state, company, and regulators may be stricter. Walk the fair lending set out loud, one line each: it is the part of this build a loan officer is most likely to have had as training but never as a writing rule, and it binds content and targeting, not only loan decisions. The NMLS ID from Block 1 is written into the guardrails file here.

37. **[Tap]** Do you know your company's advertising, social media, and fair lending rules? (Yes, I know them / Yes, but not the details / No / Not sure) Anything but the first answer registers a check as unfinished work.
38. **[Talk]** Is there anything you should never do without being asked first, and anything private that belongs only in `/CONFIDENTIAL`? (Two answers, one question: the never-do list goes in `/wiki/guardrails.md`, private material goes in `/CONFIDENTIAL` with only its existence noted.)

From this block onward, check anything public-facing against `/wiki/guardrails.md` before showing it to the loan officer.

### Block 8: Proof

39. **[Tap]** Do you have testimonials, reviews, or results you can share? (Yes, I can paste some in / Yes, but they are not written down / Numbers but no quotes / Not yet)

- Written down: paste them in, and the assistant structures them with the real numbers and the real quotes.
- Not written down: the loan officer says one out loud and the assistant writes it down for them. That is the most common real answer, and it is not a no.
- Numbers but no quotes, or not yet: build the proof file on process, standards, and the Block 1 numbers instead. Do not treat it as a failure.

Block 1 already supplied loans closed, years, and loan types: this block reads them, it does not re-ask them. Never invent a number, a result, or a testimonial, and never attach a rate or an approval claim to a proof item. Leave an "add as it comes in" section at the bottom, and note in the file that naming a borrower publicly needs that borrower's permission, which is the loan officer's call to make. Proof goes to `/wiki/business/proof.md`.

### Block 9: Content angles (ask nothing)

Generate this block from Blocks 3 to 8, asking zero questions: borrower questions first-time buyers ask and refinancers ask, the ten objections in the borrower's exact words each with a reframe and one proof idea, myth-busting topics, and five to seven messaging pillars (for each: what the loan officer believes, what the audience believes instead, three content angles, five hooks, three calls to action that are not salesy). No content angle in this file states a rate, quotes a payment, or implies guaranteed approval: education about how rates and approvals work is the angle, never a number. Organize by awareness level and by format (video, post, email). Content angles go to `/wiki/business/content-angles.md`.

### Block 10: The system

40. **[Talk]** What time do you want the morning brief? (Goes in `memory.md`.)
41. **[Tap]** Scheduling: work through the six cadence questions in `schedule.md` now, or take the defaults (once a day, brief only) and change them later?

## Where answers go

- Name, call-me, company, NMLS ID, topics, timezone, voice preference: the cheat sheet in `memory.md`
- People named along the way: one file each in `/wiki/people`
- Voice from Block 2: `/wiki/brand/voice.md`
- Banned words from question 13: the Personal Bans section of `/wiki/brand/banned-words.md` (the starter list in that file is already on)
- Borrower profiles from Block 3: `/wiki/brand/ideal-client.md`, one labelled section per borrower type
- Differentiator from Block 3: `/wiki/brand/differentiator.md`
- Stories from Block 4: `/wiki/brand/stories.md`
- Borrower words from Block 5: `/wiki/brand/client-words.md`
- Market and competitors from Block 6: `/wiki/business/market.md`
- Guardrails from Block 7: `/wiki/guardrails.md` (ships with the loan officer starters installed; this block adds the loan officer's own rules and NMLS ID to it)
- Proof from Block 8: `/wiki/business/proof.md`
- Content angles from Block 9: `/wiki/business/content-angles.md`
- Projects named along the way: `tasks.md` (seeded) and one folder each in `/projects`
- Private material: `/CONFIDENTIAL` (existence logged only)
- Brief time and cadence answers: `memory.md` and the matrix in `schedule.md`

## Finish

1. **The read-back, before anything else in this section.** Say: "Your brain is built. Let's prove it works. Type this exactly: **Read my folder. Who am I, who do I serve, and what makes me different?**" The loan officer types it, not the assistant. Answer from the files only, in the loan officer's voice, with their market, their borrowers, and their differentiator. If the answer comes out generic, a file is thin: say so, tag it, and thicken it rather than pretending. Do not add a content request on top of the read-back.
2. **Generate the portable context file** at `/wiki/ai-context.md` from the answers already given, asking nothing new: identity, borrowers, differentiator, voice rules, proof, guardrails, and one short paragraph the loan officer can paste into any other AI tool to set the whole context at once.
3. Flip `memory.md` to `Status: INTERVIEWED (YYYY-MM-DD)`.
4. If the two jobs were wired at startup, confirm `Schedules wired: YES (YYYY-MM-DD)` in `memory.md`. If not, leave it NO; the offer returns next session.
5. Seed `tasks.md` with the projects and open loops named in the interview.
6. List every `[UNFINISHEDWORK]` item created, and confirm each one is registered in `unfinished-work.md`.
7. End with a short list of what was filled, what was skipped, and what is still open or Thin. Never report the folder complete when a section is thin or placeholder-only. If nothing was open, say so and stop.
