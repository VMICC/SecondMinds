# Prompts

Reusable instructions for working with this folder. One prompt per file.

- `translate.md` the core loop: raw material in, clean knowledge out.
- `learn.md` the daily learning loop: reads yesterday's work, writes proposals in `learning/proposals/`, applies nothing.
- `first-run-interview.md` the setup interview, business owner edition: import first, grade what is found Real / Thin / Empty, verify instead of re-asking, tap for facts and talk for stories, and generate the client, differentiator, and content blocks from the answers instead of asking them flat. Ends with a read-back and the portable `wiki/ai-context.md`. It asks for the prefill handoff before the first question, and the brain checks `/raw` for one at every startup until the interview is done.
- `master-starter-prompt.md` a copy-and-paste starter that points any new AI tool at this folder and turns on the two scheduled jobs.

A prompt is an instruction you run on purpose. A procedure you follow every time lives in `/sops` instead. A reusable capability with a trigger and an output lives in `/skills`.
