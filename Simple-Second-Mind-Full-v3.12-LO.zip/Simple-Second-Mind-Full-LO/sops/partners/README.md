Referral partner procedures: working with agent partners, builders, and past borrowers who send people your way. One procedure per file. Start from `../sop-template.md`.
