# SOPs: approved procedures

An SOP is a procedure: the approved, step-by-step way something gets done here, written so the assistant (or anyone) runs it the same way every time. SOPs live here, organized by area.

An SOP is not background knowledge. Background ("understand this deeply") belongs in a wiki note. The test:

- "Do it this way" = an SOP, it lives here.
- "Understand this" = knowledge, it lives in `/wiki`.

Areas (rename or drop any area that does not fit your work; these five come from the class version):

- `borrower/` procedures for working with borrowers, from pre-approval to after funding
- `partners/` procedures for working with referral partners
- `agent/` procedures for working with the assistant itself: task forwarding, reviews, the brief
- `prospecting/` procedures for finding new work
- `social-media/` procedures for posting and engagement

Rules:

- One procedure per file, named for what it does (for example, `open-house-follow-up.md`).
- Start a new SOP from `sop-template.md` in this folder.
- When a procedure changes, edit the SOP. Do not keep the real method in your head, in a chat, or in a prompt.
- A reusable capability that is bigger than a procedure (a trigger, steps, and a defined output) is a skill instead, and lives in `/skills`.
