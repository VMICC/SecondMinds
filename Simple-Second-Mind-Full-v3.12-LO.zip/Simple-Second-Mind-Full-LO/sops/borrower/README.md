Borrower-side procedures: pre-approval, processing, closing, and after funding. One procedure per file. Start from `../sop-template.md`.
