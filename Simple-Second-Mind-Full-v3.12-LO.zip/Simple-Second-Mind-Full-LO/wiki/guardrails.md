# Guardrails

The rules that keep this loan officer's marketing and borrower work out of trouble. The first-run interview (Block 7) installs the starters below, writes in the loan officer's NMLS ID, and adds the loan officer's own rules to this file. From that block onward, the assistant checks anything public-facing against this file before showing it to the loan officer.

> This is not legal advice and the assistant is not a compliance officer. These are the common guardrails that keep most loan officers out of trouble. Your state, your company, and your regulators may be stricter. Before you run paid ads or publish anything public, have the right person look at it once.

## Rate and approval starters

- **Never state a rate without the APR next to it,** along with the terms and assumptions that rate depends on. Most content should not state a rate at all: teach how rates work instead.
- **Never say or imply "guaranteed approval,"** "everyone qualifies," or any version of approval as a promise. Approval always depends on underwriting.
- **Never promise a closing date or a timeline** as a guarantee. State the typical range and what it depends on, or say nothing.
- **Never quote a monthly payment** without the full picture behind it (loan amount, term, taxes, insurance, and the APR). A payment number standing alone misleads.
- **No income, savings, or savings-versus-renting claims** stated as fact for a specific borrower. Education in general terms is fine; a personalized promise is not.

## Fair housing and fair lending starters

Two laws do most of the work, and both cover mortgage lending directly. The **Fair Housing Act** bans discrimination in home lending based on race, color, national origin, religion, sex, disability, or familial status. The **Equal Credit Opportunity Act (Regulation B)** bans it in any credit decision based on those, plus marital status, age, income coming from public assistance, or someone having exercised their rights under consumer credit law. Plain version: if a decision, a price, a term, an offer, or a piece of content would come out different because of any item on those lists, stop. These rules bind what the content says, who it is aimed at, and how borrowers are treated, not just the loan decision itself.

- **Never discourage an application.** Everyone gets the same encouragement, the same information, and the same effort, in person, in messages, and in content. No pre-screening by tone, delay, or extra hurdles for some borrowers.
- **Same standards for everyone.** The same underwriting guidelines, documentation requests, product offers, and pricing, applied the same way. Any pricing or underwriting exception gets documented with its real business reason (a genuine compensating factor), never with anything about who the borrower is.
- **No redlining.** Do not skip, avoid, or spend less on marketing, service, or outreach in an area because of the racial or ethnic makeup of the people who live there, and never treat a neighborhood's makeup as a reason to steer, price, or decline.
- **No steering.** Offer the loan options the borrower qualifies for and let the borrower choose. Never push a borrower toward a costlier product or a worse term than the one they qualify for, and never let compensation decide which products get presented.
- **Borrower questions about neighborhoods get facts, not signals.** Answer with checkable facts and public sources, the same as describing an area in content. Never offer an opinion about who lives there or whether it is "that kind" of area, in either direction.
- **Government monitoring information is collected only the way the application requires.** Say why it is being asked (federal monitoring), note that the borrower may decline to provide it, and never use it in any decision, price, or piece of content.
- **Appraisals stay independent.** Never mention a protected basis or a neighborhood's makeup to an appraiser, and never pressure a value in either direction. If a borrower believes a value reflects bias, follow the company's reconsideration of value process. Do not debate it with them in a message or a comment.
- **Advertising and targeting follow the same rules.** No statement, image, or audience setting that signals a preference about who should or should not apply, and no ad targeting that excludes people by a protected basis or a close stand-in for one.
- **Application information stays exact.** Loan data is reported and reviewed for fair lending (HMDA), so never coach an applicant to state anything other than the truth, and never clean up a number to make a file look better.
- **A discrimination concern is a same-day escalation.** If a borrower says they were treated unfairly, do not argue the point anywhere, public or private. Pass it to the company's compliance contact the same day and note it in the file.

## Identity on public material

- **The NMLS ID goes on everything public:** ads, posts, emails, the website, video descriptions. If a piece has no place for it, the piece is not ready.
  - NMLS ID (filled in by the interview):
- **Equal Housing Lender language** appears on public-facing material, in the form and logo your company requires. It is not optional decoration; it is part of the fair housing rules above.
- **A borrower's name, photo, story, or result in public material needs that borrower's permission first,** and never includes their financial details. Getting permission is the loan officer's job, not the assistant's.
- Follow the company's advertising, social media, and fair lending rules wherever they are stricter than the general ones. If those rules are not known yet, that check is registered as unfinished work, not guessed at.

## The accountability rule

An AI drafting something does not move responsibility for it. The loan officer's name and license are what the public sees, and the loan officer owns everything published under them. "The AI wrote it" is never a defense, so nothing public leaves this system without the loan officer's approval, through `/queue`, like everything else outbound.

## The loan officer's own rules

Filled in by the first-run interview (Block 7) and added to whenever a new rule shows up in real work:

- Never do without asking first:
- Private, belongs only in `/CONFIDENTIAL` (existence noted here, content never copied here):
