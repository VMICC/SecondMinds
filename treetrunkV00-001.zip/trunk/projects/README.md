Active work. One file or folder per project.
