# Assets (local only)

Big files live here and are never pushed to GitHub. The master `.gitignore`
at the trunk root ignores everything in this folder except this README, so
the folder shows up in the repo and explains itself, while the files stay on
this machine.

Your AI tools read your local disk, not GitHub, so ignored files work
exactly like tracked ones in every local tool. Git carries text. Originals
and media live here.

- `images/` listing photos, screenshots, brand graphics
- `pdfs/` reports, contracts, big guides
- `media/` video and audio
- `originals/` anything bulky that a finished note still points at

The test for what belongs here is reference, not file type: if a finished
note links to the file, it is an asset. A processed original that nothing
references goes to `archive/` instead.

Finished notes reference assets by relative path (for example
`assets/pdfs/inspection-report.pdf`). The reference travels with the repo;
the file opens locally.
