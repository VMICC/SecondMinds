# Today

## Today's tasks

Ranked A (must), B (should), C (could). Symbols at rollover: ✓ done,
X canceled, → forwarded, ← deferred to `tasks.md`. Method:
`sops/agent/task-forwarding.md`.

- [ ] A1 ·

## On my mind

-

## Agent log

-
