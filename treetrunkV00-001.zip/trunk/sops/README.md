# SOPs: approved business practices

An SOP is a business practice: the approved, step-by-step way this business
does something, written so anyone (or any agent) runs it the same way every
time. SOPs live here, organized by area of the business.

SOPs are not training guides. The `guides/` folders inside the chiefs'
teams are training guides: they teach a specialist a domain (frameworks,
mastery material, background). The test:

- "Do it this way" = an SOP, it lives here.
- "Understand this deeply" = a guide, it lives with the owning chief.

- `buyer/` practices for working with buyers
- `seller/` practices for working with sellers
- `agent/` practices for working with the AI team itself
- `prospecting/` practices for expireds, FSBOs, probate, sphere
- `social-media/` practices for posting and engagement
