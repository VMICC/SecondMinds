Social media procedures and posting formats.
