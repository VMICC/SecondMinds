Seller-side procedures.
