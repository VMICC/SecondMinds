Buyer-side procedures.
