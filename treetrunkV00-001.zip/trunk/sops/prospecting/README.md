Prospecting procedures: expireds, FSBOs, probate, sphere.
