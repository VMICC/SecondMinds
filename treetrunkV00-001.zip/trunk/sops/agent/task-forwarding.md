# SOP: Task Forwarding and the Master Task List

How tasks move through this system without getting lost: ABC daily
priorities, forwarding symbols, and a Master Task List (MTL) that
holds everything not scheduled today.

Two files, one job each:

- `today.md` is the daily page. Only today's tasks live there, ranked.
- `tasks.md` at the root is the Master Task List. Everything else
  lives there: this week's top priorities, the unscheduled master list, and
  items parked for a future month.

## The symbols

Marked on each open task at rollover, before yesterday's page is
archived:

- ✓ **Done.** The task is completed.
- X **Canceled.** No longer necessary. Logged, not silently deleted.
- → **Forwarded.** Migrated to tomorrow's daily list.
- ← **Deferred.** Moved back to the Master Task List, or to a future
  month, because it cannot be done now.

No open task is ever just deleted. It gets a symbol, so every task's
ending is a decision on the record.

## Daily: ABC and forwarding

1. The day's tasks are ranked A (must do), B (should do), C (could
   do), numbered inside each letter: A1, A2, B1. The agent proposes
   the ranking in the morning brief; the owner confirms or changes
   the A items. That is the owner's 15-minute daily planning, done
   inside the brief they already read.
2. At the next morning's rollover, the Chief of Staff applies the
   symbols to yesterday's list before archiving the page:
   - ✓ and X items are logged in `tasks.md` under Closed this month.
   - → items are rewritten onto the new `today.md` and their forward
     count goes up by one, shown as (→×2), (→×3).
   - ← items move to `tasks.md`, to the master list or a named month.
3. The new day's list is then re-ranked against the day's new
   priorities. A forwarded task does not keep yesterday's rank by
   default; it earns its place again.

## Weekly: top priorities

Tasks tied to a role or a chief that are not scheduled today sit in
`tasks.md` under This week. At the weekly review (it rides the Monday
morning brief, no separate meeting), each unfinished top priority is
re-evaluated: scheduled into a day this week, or sent back to the
master list with ←.

## Monthly: transcription

Projects and long-term tasks live on the Master Task List. At the
month rollover (it rides the brief on the 1st), the agent carries
every still-active item into the new month and moves the month's
Closed log to `archive/monthly/YYYY-MM-tasks.md`. Nothing active is
dropped in the move; the owner confirms any X.

## The pain of transcribing, adapted

In the paper planner, rewriting a task by hand hurt, and the hurt
forced a question: is this genuinely important but not urgent,
or is it a distraction to delegate, defer long-term, or eliminate?

The agent does the rewriting here, so the owner feels no pain. The
system replaces pain with a count and a forced question:

- Every forward is counted, in the open: (→×2), (→×3).
- At (→×3), the item is flagged in the morning brief with exactly
  that question: still important but not urgent, or delegate it,
  ← defer it with
  a date, or X it?
- The agent never forwards an item a fourth time silently. The owner
  picks one of the four outcomes; the agent records it.

## What the agent does, what the human does

The agent does all the labor: transcribing, counting, re-listing,
archiving, flagging. The human does only the judging: confirming the
A items each morning, and answering the (→×3) question when it comes.
That split is the point. The list never rots quietly, deferring is a
dated decision instead of a disappearance, and today's list stays
short because the Master Task List holds everything else.
