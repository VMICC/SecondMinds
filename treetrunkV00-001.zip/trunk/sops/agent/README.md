Procedures for working with the AI agent itself.
