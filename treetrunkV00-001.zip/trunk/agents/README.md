# The AI Team

You are the CEO. Five chiefs run the business under you. The Chief of Staff (0) coordinates the other four and reports to you; everyone else reports to the Chief of Staff.

Each chief folder holds `soul.md` (who it is), `identity.md` (name and reporting line), and `agents.md` (charter, team, and the owned-skills list). **Skill and playbook lists live in exactly one place: the owning chief's `agents.md`.** This catalog is only an index of chiefs and teams.

Ownership follows the System AI Team site (department, then specialist). Training guides come from the System C-Suite zip; the numbered workflow cases come from the System AI Realtor OS guide (overview: `wiki/business/ai-realtor-os.md`).

## 0. Chief of Staff

Runs the system, coordinates the other chiefs. Reports to the Owner (CEO).

Team (1): `executive-assistant`
Owns 2 skills and 5 playbooks, listed in `0-chief-of-staff/agents.md`.

## 1. Operations

Processes, projects, CRM. Reports to the Chief of Staff.

Team (3): `chief-operating-officer`, `crm-systems-administrator`, `head-of-operations`
Owns 3 skills and 8 playbooks, listed in `1-operations/agents.md`.

## 2. CFO

Money: cash flow, GCI, per-property numbers. Reports to the Chief of Staff.

Team (2): `head-of-finance`, `real-estate-financial-analyst`
Owns 1 skills and 6 playbooks, listed in `2-cfo/agents.md`.

## 3. Marketing-Sales

Customer acquisition and follow-up. Reports to the Chief of Staff.

Team (13): `ai-search-visibility-strategist`, `brand-manager`, `buyer-specialist`, `content-marketing-manager`, `direct-response-copywriter`, `email-marketing-manager`, `growth-marketing-manager`, `head-of-marketing`, `head-of-sales`, `listing-conversion-specialist`, `open-house-host`, `paid-media-manager`, `social-media-manager`
Owns 28 skills and 68 playbooks, listed in `3-marketing-sales/agents.md`.

## 4. Client-Experience

Sphere care, transaction experience, reviews, retention. Reports to the Chief of Staff.

Team (4): `head-of-customer-success`, `review-and-testimonial-manager`, `transaction-experience-coordinator`, `vip-client-concierge`
Owns 11 skills and 6 playbooks, listed in `4-client-experience/agents.md`.
