# Approvals queue

Every outbound draft from every chief lands here to wait for the owner.
Nothing sends from anywhere else.

- One file per draft, named `YYYY-MM-DD-<what-it-is>.md`
  (for example, `2026-10-21-birthday-text-johnson.md`).
- The owner reviews the queue each morning, alongside the brief.
- Approved and sent: the Chief of Staff moves the file to `archive/`
  with the same name.
- Rejected: the owner deletes the file, or says "kill it" in the review
  and the Chief of Staff archives it instead.
- If a draft is not in this queue, it does not go out.
