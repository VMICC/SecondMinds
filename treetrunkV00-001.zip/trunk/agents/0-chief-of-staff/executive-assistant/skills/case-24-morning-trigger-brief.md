# Case 24: The morning trigger brief + commitment capture

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/0-chief-of-staff/executive-assistant/`
**You get:** One morning brief + task list
**Channels:** Chat / Email digest
**Source:** System AI Realtor OS guide, page 14 / 16

## The problem

Your day starts scattered: a DM promise here, a showing there, a lead from last night, a deadline today, and two of them fall through the cracks by noon. This is the job that runs all the others.

## Copy + paste prompt

```
Every morning, brief me in one message: (1) conversation triggers from the last 24 hours with a draft reply for each, (2) transaction deadlines due today or unconfirmed, (3) every commitment I made in messages or email, turned into a dated task. If a section is empty, say 'nothing new', do not fill it.
```

_Repo addition: the brief also surfaces one item from `unfinished-work.md` (oldest first; up to 2 more only if the owner says ok, never more than 3 a day). If the list is empty, it is not mentioned. For a NEED TO CREATE item, the line includes the offer to draft it (questions, a scan of the owner's work, or a scan of a website they name)._

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
