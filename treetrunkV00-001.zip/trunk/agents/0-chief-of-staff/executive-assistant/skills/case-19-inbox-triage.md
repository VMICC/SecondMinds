# Case 19: Triage the inbox into urgent / today / file it, with drafts attached

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/0-chief-of-staff/executive-assistant/`
**You get:** 3-bucket digest + reply drafts
**Channels:** Email
**Source:** System AI Realtor OS guide, page 12 / 16

## The problem

100+ emails hide the three that matter: a new offer, a buyer inquiry on a cancelled listing, a title company that cannot match a check.

## Copy + paste prompt

```
Triage my inbox into Urgent, Today, and File. Urgent means: offers, counters, deadlines, transaction issues, and new buyer or seller inquiries. For every Urgent and Today item, draft my reply and name the exact recipient it should go to. File the rest by listing or buyer. Never send without my approval.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
