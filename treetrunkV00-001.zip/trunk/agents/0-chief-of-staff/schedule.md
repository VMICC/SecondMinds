# Schedule: Chief of Staff

The timetable for the whole team. Start with one heartbeat a day.

## Start here

Run ONE heartbeat a day: the morning brief (Case 24). (Before the very first brief, the first-run interview must be done: `memory.md` status INTERVIEWED.) It pulls the day's
triggers, deadlines, and commitments into a single message, in this order:

1. Rollover with task forwarding (`sops/agent/task-forwarding.md`):
   mark yesterday's tasks (✓ X → ←) before archiving `today.md`.
   ✓ and X are logged in `tasks.md`; → items are rewritten onto the
   new `today.md` with their forward count; ← items move to
   `tasks.md`. Flag any (→×3) item in the brief for a decision.
2. Run the brief (it pulls in Cases 02, 07, and 19).
3. Surface ONE item from `unfinished-work.md`, oldest first. If the
   owner says "more" or "ok", up to 2 more. Never more than 3 a day.
   If the list is empty, say nothing about it. For a NEED TO CREATE
   item, the surfacing line includes the offer to draft it (questions,
   scan their work, or scan a website they name).
4. Put every outbound draft in `queue/` for the owner's approval.

Weekly and monthly task reviews ride this same brief (Mondays, and
the 1st of the month). They are not new heartbeats.

Do not add more heartbeats until the daily brief is a habit. One run a day
is enough to start; tighter intervals cost more and mostly repeat the same
brief. Tighten only when the owner says so.

## Wiring into a scheduler (the two jobs)

Only two jobs ever get wired. The scheduler holds a time and a one-line
pointer; every real instruction stays in these files.

Job 1, the translate sweep, daily, 30 to 60 minutes before the brief:

```
Open the trunk folder. Read AGENTS.md. Run prompts/translate.md over
everything new in raw/. Log what you processed in today.md under
Agent log.
```

Job 2, the morning brief, daily at the brief time in `memory.md`:

```
Open the trunk folder. Read AGENTS.md and memory.md. Run the morning
routine in agents/0-chief-of-staff/schedule.md, steps 1 to 4. Send me
the brief.
```

When both jobs exist in the owner's scheduler, set `Schedules wired:
YES (YYYY-MM-DD)` in `memory.md`.

Until that line flips to YES, the system is not live: nothing runs on
its own. The schedule check in `AGENTS.md` offers this wiring at every
startup until it is done. Declining only defers it to the next
session; the offer does not go away.

**The 30-minute floor.** Never wire any job, these two or any added
later, faster than every 30 minutes, unless the owner explicitly
says to. Every scheduled run costs tokens out of the same bank the
owner chats and works from. Runs set too fast mostly repeat the same
work while they drain that bank, and enough of them can exhaust it
entirely, leaving the model nothing for real work. That is why the
starting rhythm here is one run a day, and why tightening an
interval is always the owner's explicit call, never the agent's.

### Option: day/night cadence (work hours / sleep hours)

Off by default. It matters only once the owner runs heartbeats more
often than the daily brief. The idea: the system pays attention while
the owner is awake and rests while they sleep. The windows in the
bullets below are only the starting defaults. The owner's live values
are the matrix at the end of this section, and they change just by
the owner saying so.

- **Awake window:** 6:00 AM to midnight. Heartbeats run at the
  owner's chosen interval, never faster than the 30-minute floor.
- **Asleep window:** midnight to 6:00 AM. The interval stretches to
  one slow check for the whole window (a single run, for example at
  3:00 AM). An asleep check is silent unless something is truly
  urgent (a deadline today, a client waiting on a reply). Anything
  else it finds is written into `today.md` and held for the morning
  brief. Overnight token spend is at most that one run.
- **Weekend evenings:** on Friday, Saturday, and Sunday the asleep
  window starts at 10:00 PM, not midnight. Agents are typically not
  checking anything then, so the system rests too: slow check only,
  silent unless urgent, everything else held. The Monday morning
  brief catches the whole weekend at once.
- The daily cycle does not change: translate sweep before the brief,
  brief at the wake time in `memory.md`.

The dumb wiring: most schedulers cannot change an interval by time
of day inside one entry, so the same job gets two time ranges, one
per window, with the identical pointer prompt. In a cron-style
scheduler that is two hour ranges on one job; in an app scheduler it
is two tasks with the same text. The job's instructions never change,
because they live in this file. The owner turns the cadence on or
off with one switch in `memory.md`. The windows and the interval live
only in the matrix below.

#### Build the matrix: the six questions

The agent asks these at setup (the interview's Finish points here)
and again any time the owner wants the cadence changed. One at a
time. Every question has a default; "use the default" is a complete
answer to all six.

1. What time do you want the morning brief? (That time goes in
   `memory.md`. It is the one fixed run everything else hangs off.)
2. Between briefs, should the system check on a heartbeat, or stay
   once a day for now? If a heartbeat: pick a starting interval of
   30 minutes, 1, 2, 4, or 6 hours. Never faster than 30 minutes.
3. What are your awake hours, when the system should pay attention?
   Default: 6:00 AM to midnight.
4. What are your asleep hours, when it should go quiet? Default:
   midnight to 6:00 AM.
5. Do Friday, Saturday, and Sunday evenings slow down earlier?
   Default: yes, asleep from 10:00 PM on those days.
6. During asleep hours: no check at all, or one slow silent check
   (about 3:00 AM) that surfaces only a true urgency and holds
   everything else for the brief? Default: one silent check.

#### The cadence matrix (the owner's live values)

| Days | Awake: checks every [interval] | Asleep: one slow check, silent unless urgent |
| --- | --- | --- |
| Mon to Thu | 6:00 AM to midnight | midnight to 6:00 AM |
| Fri | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |
| Sat | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |
| Sun | 6:00 AM to 10:00 PM | 10:00 PM to 6:00 AM |

[interval] starts as: once a day, the brief only (no heartbeat).
Change any cell by telling the agent. The agent updates this table
and the wired jobs to match, and this table stays the only place the
windows and the interval live.

## The full rhythm (add jobs as the system matures)

| When | Jobs | Owning chief |
| --- | --- | --- |
| Daily | 24 morning brief (pulls 02, 07, 19) | 0 Chief of Staff |
| Monday | 01 birthdays, 03 home anniversaries, 04 quiet check-ins | 4 Client-Experience |
| Weekly | 11 new movers, 12 Instagram engagers, 15 repurpose a post | 3 Marketing-Sales |
| Monthly | 20 CRM cleanup | 1 Operations |
| Weekly | Task review: top priorities re-ranked, (→×3) flags decided | 0 Chief of Staff |
| Monthly | Task transcription: active items carried to the new month, closed log archived | 0 Chief of Staff |
| Per listing | 13 listing copy (canonical skill), 14 launch pack, 17 showing feedback | 3 Marketing-Sales |
| Per contract | 21 deadlines, 22 inspection brief | 4 Client-Experience |
| Per contract | 23 offer comparison | 3 Marketing-Sales |
