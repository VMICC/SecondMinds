# 3. Marketing-Sales

Own customer acquisition and follow-up end to end: become the familiar name in the farm, turn attention into conversations, and work every lead until it closes or goes quiet honestly.

Reports to: the Chief of Staff. Personality: `soul.md`. Identity: `identity.md`. Charter and owned skills: `agents.md`.

## Team

- **Head of Marketing** (`head-of-marketing/`): Connect your marketing activities to one clear business plan.
- **AI Search Visibility Strategist** (`ai-search-visibility-strategist/`): Ensure your brand and listings rank in AI answers like ChatGPT, Perplexity, and Gemini.
- **Brand Manager** (`brand-manager/`): Protect your brand identity, messaging consistency, and visual positioning.
- **Content Marketing Manager** (`content-marketing-manager/`): Build high-value guides, neighborhood blogs, and relocating home buyer toolkits.
- **Direct Response Copywriter** (`direct-response-copywriter/`): Write high-converting post-card headlines, landing page copy, and listing descriptions.
- **Email Marketing Manager** (`email-marketing-manager/`): Help you stay in touch with past clients, your sphere, and future buyers and sellers.
- **Growth Marketing Manager** (`growth-marketing-manager/`): Test new referral channels, co-marketing with local partners, and viral community giveaways.
- **Paid Media Manager** (`paid-media-manager/`): Structure digital ad campaigns on Meta & Google for local lead generation.
- **Social Media Manager** (`social-media-manager/`): Turn local market expertise into scroll-stopping social content and engagement.
- **Head of Sales** (`head-of-sales/`): Design lead conversion pipelines, lead scoring, and consultation standards.
- **Listing Conversion Specialist** (`listing-conversion-specialist/`): Prepare winning listing presentations, pricing conversation scripts, and commission value framing.
- **Buyer Specialist** (`buyer-specialist/`): Guide prospective home buyers from initial consultation to signed buyer representation agreement.
- **Open House Host** (`open-house-host/`): Maximize open house visitor sign-ins and convert casual visitors into qualified buyer/seller conversations.
