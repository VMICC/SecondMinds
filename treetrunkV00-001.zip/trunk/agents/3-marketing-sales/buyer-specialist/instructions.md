# Instructions: Buyer Specialist

Follow the standing orders in `AGENTS.md` at the trunk root and the training list in `read-first.md` in this folder.
Skills for this role live in the `skills/` folder here.
