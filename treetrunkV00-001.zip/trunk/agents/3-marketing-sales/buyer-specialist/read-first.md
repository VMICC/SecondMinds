# Read first: Buyer Specialist

**Department:** Sales & Follow-up

**Role:** Guide prospective home buyers from initial consultation to signed buyer representation agreement.

## Training

- Buyer consultation framework
- Buyer agreement compensation dialogue
- Needs discovery & property criteria mapping
- Offer presentation & strategy

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
