# Structure a 30-minute Buyer Consultation Session

**Department:** Sales & Follow-up  
**Specialist:** Buyer Specialist  
**Version:** v1.1  
**Last updated:** 2026-09-25  
**Source path:** `sales/buyer-specialist/buyer-consultation.md`

Conduct a professional initial buyer meeting that establishes trust and secures representation.

## Required inputs

- Buyer relocation status
- Pre-approval status
- Preferred neighborhood preferences

## Instructions

Output 5-phase meeting agenda: 1) Goals & Lifestyle, 2) Market Reality & Financing, 3) Search Strategy, 4) Representation Agreement Value, 5) Next Steps.

## Example request

> Give me a step-by-step buyer consultation script that clearly explains my value and the buyer representation agreement.
