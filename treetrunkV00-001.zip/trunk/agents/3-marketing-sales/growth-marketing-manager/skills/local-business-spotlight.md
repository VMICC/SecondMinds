# Launch a Local Business Spotlight co-marketing campaign

**Department:** Marketing  
**Specialist:** Growth Marketing Manager  
**Version:** v1.0  
**Last updated:** 2026-10-05  
**Source path:** `marketing/growth-marketing-manager/local-business-spotlight.md`

Partner with top local coffee shops or bakeries to co-host community giveaways and build sphere contact lists.

## Required inputs

- Partner business name & contact person
- Giveaway offer value
- Lead capture mechanism

## Instructions

Outline outreach pitch email to business owner, co-branded Instagram post copy, QR code sign script, and follow-up email to participants.

## Example request

> Draft a co-marketing proposal email to a popular local bakery for a 'Coffee & Home Insights' monthly giveaway.
