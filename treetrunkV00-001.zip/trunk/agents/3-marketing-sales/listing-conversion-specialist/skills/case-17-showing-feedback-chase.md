# Case 17: Chase showing feedback, so sellers hear it from you, not silence

**Section:** C / Listings & Marketing (One input. Every version you need.)
**Owner:** `agents/3-marketing-sales/listing-conversion-specialist/`
**You get:** Chase drafts + grouped seller summary
**Channels:** SMS to agents / Email to seller
**Source:** System AI Realtor OS guide, page 11 / 16

## The problem

Showing agents do not return feedback unless chased twice, and sellers interpret silence as failure.

## Copy + paste prompt

```
Track showings on my listings. At 24 hours with no feedback, draft a short chase text to the showing agent; at 48 hours, draft a second nudge. Compile all feedback into a seller summary grouped by price, condition, and layout, with direct quotes kept separate from your summary.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
