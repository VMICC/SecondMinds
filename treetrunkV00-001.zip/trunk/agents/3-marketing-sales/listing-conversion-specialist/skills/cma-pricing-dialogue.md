# Draft a pricing narrative for a sensitive seller CMA

**Department:** Sales & Follow-up  
**Specialist:** Listing Conversion Specialist  
**Version:** v1.2  
**Last updated:** 2026-10-12  
**Source path:** `sales/listing-conversion-specialist/cma-pricing-dialogue.md`

Explain market data clearly to sellers who expect higher pricing than recent comps justify.

## Required inputs

- Subject property details
- Seller target price vs realistic CMA price range
- Comp statistics & days on market trend

## Instructions

Frame conversation around '3 Pricing Strategies: Aggressive, Market Value, and Event-Based'. Use empathetic, consultative dialogue.

## Example request

> Draft a script for presenting a CMA when the seller wants $850k but comps support $800k. Help me protect our relationship while guiding them to market reality.
