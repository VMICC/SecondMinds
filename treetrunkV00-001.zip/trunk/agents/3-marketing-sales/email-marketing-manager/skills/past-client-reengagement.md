# Prepare a past-client re-engagement campaign

**Department:** Marketing  
**Specialist:** Email Marketing Manager  
**Version:** v1.0  
**Last updated:** 2026-09-20  
**Source path:** `marketing/email-marketing-manager/past-client-reengagement.md`

Re-ignite relationships with past buyers and sellers through anniversary equity checks.

## Required inputs

- Intended audience
- Campaign goal
- Local information
- Preferred call to action
- Voice guide

## Instructions

### Anniversary Check-in Framework
- Acknowledge their home purchase anniversary date
- Provide a personalized snapshot of neighborhood appreciation
- Offer to review their current property tax assessment or refi numbers
- Reassure them you're always in their corner

## Example request

> Prepare a past-client re-engagement email sequence to reconnect with clients who closed 12 to 24 months ago with an updated equity snapshot.
