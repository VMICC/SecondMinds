# Create a future-seller nurture sequence

**Department:** Marketing  
**Specialist:** Email Marketing Manager  
**Version:** v1.0  
**Last updated:** 2026-10-02  
**Source path:** `marketing/email-marketing-manager/future-seller-nurture.md`

Draft a 4-part automated email sequence for homeowners thinking of selling in 6-12 months.

## Required inputs

- Intended audience
- Campaign goal
- Local information
- Preferred call to action
- Voice guide

## Instructions

### 4-Part Seller Nurture Framework
- Email 1: 3 Pre-listing investments with highest ROI
- Email 2: How inventory shifts affect neighborhood buyer demand
- Email 3: Case study: How smart staging saved 18 days on market
- Email 4: Low-key offer for a private 15-minute home walk-through

## Example request

> Create a 4-part future seller email nurture sequence for homeowners who requested our 'Neighborhood Remodel ROI' report.
