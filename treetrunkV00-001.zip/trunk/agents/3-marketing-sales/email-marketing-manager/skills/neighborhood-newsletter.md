# Draft a neighborhood newsletter

**Department:** Marketing  
**Specialist:** Email Marketing Manager  
**Version:** v1.1  
**Last updated:** 2026-10-12  
**Source path:** `marketing/email-marketing-manager/neighborhood-newsletter.md`

Write an engaging, personal newsletter featuring local updates, recent sales, and community spotlights.

## Required inputs

- Intended audience
- Campaign goal
- Local information
- Preferred call to action
- Voice guide

## Instructions

### Structure
1. Personal greeting & short local hook
2. Local update (1 notable market stat + 1 community event/spotlight)
3. Featured seller or buyer insight
4. Low-pressure Call to Action (e.g. "Reply 'VALUATION' for a custom equity report")

## Example request

> Draft a neighborhood newsletter for homeowners in my farm. Use my voice guide, include the local update I provide, and invite readers to reply with their real estate questions.
