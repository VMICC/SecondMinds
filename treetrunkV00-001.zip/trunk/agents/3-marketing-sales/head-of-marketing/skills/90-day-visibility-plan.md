# Plan 90 days of neighborhood visibility

**Department:** Marketing  
**Specialist:** Head of Marketing  
**Version:** v1.2  
**Last updated:** 2026-10-15  
**Source path:** `marketing/head-of-marketing/90-day-visibility-plan.md`

Build an actionable, multi-touch 90-day visibility schedule for your target farm.

## Required inputs

- Target neighborhood name & home count
- Farming budget & primary touchpoints
- Current market positioning
- Voice & tone guide

## Instructions

### Goal
Create a cohesive 90-day neighborhood visibility plan combining mailers, digital posts, community updates, and open house buzz.

### Framework
1. Week 1-4: Establish local market authority (data & statistics)
2. Week 5-8: Showcase human story & neighborhood lifestyle
3. Week 9-12: Invitation to action (free valuation consultation / market forecast)

### Output Format
Produce a 12-week grid organized by Channel, Content Topic, CTA, and Asset Needed.

## Example request

> Draft a 90-day neighborhood visibility plan for my target farm 'Oakridge Estates'. Use my voice guide, focus on market updates and local business spotlights, and include a clear call to reply for home valuation.
