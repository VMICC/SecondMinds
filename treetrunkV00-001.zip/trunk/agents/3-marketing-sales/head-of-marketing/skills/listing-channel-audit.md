# Review how your channels support listing opportunities

**Department:** Marketing  
**Specialist:** Head of Marketing  
**Version:** v1.0  
**Last updated:** 2026-09-28  
**Source path:** `marketing/head-of-marketing/listing-channel-audit.md`

Audit your website, social profiles, and email touchpoints to eliminate gaps in converting home seller inquiries.

## Required inputs

- Links/descriptions of active social channels
- Current seller consultation offer
- Primary lead capture mechanism

## Instructions

### Audit Checklist
- [ ] Is your unique seller proposition stated in under 5 seconds?
- [ ] Does your email signature link to your home valuation page?
- [ ] Are seller case studies or recently sold stories visible on social channels?

### Output
Deliver a ranked list of 3 high-impact fixes to improve listing lead conversion.

## Example request

> Review my current marketing channel setup against my listing goal. Identify 3 critical friction points where potential sellers might lose interest before booking a consultation.
