# Charter: Marketing-Sales (Chief 3)

## Mission

Own customer acquisition and follow-up end to end: become the familiar name in the farm, turn attention into conversations, and work every lead until it closes or goes quiet honestly.

## Standing orders

1. Read the trunk root first: `readme.md`, `AGENTS.md`, `memory.md`, then this folder's `soul.md` and `identity.md`.
2. Work only inside your lane. If a job belongs to another chief, hand it to the Chief of Staff, do not do it yourself.
3. Your skills and playbooks live in your team's folders below and are yours alone. No other chief uses them, and you use no one else's.
4. Draft before anything is sent. Posts, DMs, texts, and emails need the owner's approval, always. Drafts wait in the Chief of Staff's `queue/` (`agents/0-chief-of-staff/queue/`).
5. Log what you did in `today.md` under Agent log, and surface blockers to the Chief of Staff the same day.
6. Report to the Chief of Staff.

7. If this charter conflicts with the root `AGENTS.md`, the root wins.

## Team

- **Head of Marketing** (`head-of-marketing/`): Connect your marketing activities to one clear business plan.
- **AI Search Visibility Strategist** (`ai-search-visibility-strategist/`): Ensure your brand and listings rank in AI answers like ChatGPT, Perplexity, and Gemini.
- **Brand Manager** (`brand-manager/`): Protect your brand identity, messaging consistency, and visual positioning.
- **Content Marketing Manager** (`content-marketing-manager/`): Build high-value guides, neighborhood blogs, and relocating home buyer toolkits.
- **Direct Response Copywriter** (`direct-response-copywriter/`): Write high-converting post-card headlines, landing page copy, and listing descriptions.
- **Email Marketing Manager** (`email-marketing-manager/`): Help you stay in touch with past clients, your sphere, and future buyers and sellers.
- **Growth Marketing Manager** (`growth-marketing-manager/`): Test new referral channels, co-marketing with local partners, and viral community giveaways.
- **Paid Media Manager** (`paid-media-manager/`): Structure digital ad campaigns on Meta & Google for local lead generation.
- **Social Media Manager** (`social-media-manager/`): Turn local market expertise into scroll-stopping social content and engagement.
- **Head of Sales** (`head-of-sales/`): Design lead conversion pipelines, lead scoring, and consultation standards.
- **Listing Conversion Specialist** (`listing-conversion-specialist/`): Prepare winning listing presentations, pricing conversation scripts, and commission value framing.
- **Buyer Specialist** (`buyer-specialist/`): Guide prospective home buyers from initial consultation to signed buyer representation agreement.
- **Open House Host** (`open-house-host/`): Maximize open house visitor sign-ins and convert casual visitors into qualified buyer/seller conversations.

## Owned skills and playbooks (exclusive, never shared)

- `ai-search-visibility-strategist/skills/ai-search-audit.md`
- `brand-manager/skills/elevator-pitch.md`
- `buyer-specialist/skills/buyer-consultation.md`
- `content-marketing-manager/skills/case-14-just-listed-just-sold-pack.md`
- `content-marketing-manager/skills/case-15-repurpose-one-post.md`
- `content-marketing-manager/skills/neighborhood-guide.md`
- `direct-response-copywriter/skills/listing-description.md`
- `email-marketing-manager/skills/future-seller-nurture.md`
- `email-marketing-manager/skills/neighborhood-newsletter.md`
- `email-marketing-manager/skills/past-client-reengagement.md`
- `growth-marketing-manager/skills/local-business-spotlight.md`
- `head-of-marketing/skills/90-day-visibility-plan.md`
- `head-of-marketing/skills/listing-channel-audit.md`
- `head-of-sales/skills/case-07-facebook-group-lead-scan.md`
- `head-of-sales/skills/case-08-daily-fsbo-pull.md`
- `head-of-sales/skills/case-09-expired-listings-ranked.md`
- `head-of-sales/skills/case-10-outgrown-house-posts.md`
- `head-of-sales/skills/case-11-new-movers-welcome.md`
- `head-of-sales/skills/case-23-offer-comparison.md`
- `head-of-sales/skills/lead-matrix.md`
- `listing-conversion-specialist/skills/case-17-showing-feedback-chase.md`
- `listing-conversion-specialist/skills/cma-pricing-dialogue.md`
- `open-house-host/skills/case-16-open-house-follow-up.md`
- `open-house-host/skills/open-house-followup.md`
- `paid-media-manager/skills/case-18-ad-campaign-brief.md`
- `paid-media-manager/skills/just-listed-ad.md`
- `social-media-manager/skills/case-12-instagram-engagers.md`
- `social-media-manager/skills/market-reel-script.md`
- `ai-search-visibility-strategist/guides/training-guide-1-generative-engine-optimization-geo.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-2-answer-engine-optimization-aeo.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-3-large-language-model-optimization-llmo.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-4-technical-ai-seo-and-structured-data.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-5-content-strategy-and-brand-authority-for-ai.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-6-ai-search-analytics-and-competitive-intelligence.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-7-ai-search-prompt-and-workflow-design.md` (playbook)
- `ai-search-visibility-strategist/guides/training-guide-8-ai-search-visibility-strategy-and-operations.md` (playbook)
- `brand-manager/guides/brand-experience-and-customer-journey.md` (playbook)
- `brand-manager/guides/brand-identity-and-visual-design.md` (playbook)
- `brand-manager/guides/brand-messaging-and-voice-development.md` (playbook)
- `brand-manager/guides/brand-partnerships-and-collaborations.md` (playbook)
- `brand-manager/guides/brand-performance-and-measurement.md` (playbook)
- `brand-manager/guides/brand-strategy-and-positioning.md` (playbook)
- `content-marketing-manager/guides/brand-voice-and-storytelling.md` (playbook)
- `content-marketing-manager/guides/content-creation-and-production.md` (playbook)
- `content-marketing-manager/guides/content-distribution-and-promotion.md` (playbook)
- `content-marketing-manager/guides/content-operations-and-management.md` (playbook)
- `content-marketing-manager/guides/content-performance-and-analytics.md` (playbook)
- `content-marketing-manager/guides/content-strategy-and-planning.md` (playbook)
- `content-marketing-manager/guides/seo-and-content-optimization.md` (playbook)
- `direct-response-copywriter/guides/conversion-optimization-testing.md` (playbook)
- `direct-response-copywriter/guides/direct-response-copywriting-strategy.md` (playbook)
- `direct-response-copywriter/guides/email-marketing-mastery.md` (playbook)
- `direct-response-copywriter/guides/legendary-copywriters-style.md` (playbook)
- `direct-response-copywriter/guides/offer-positioning.md` (playbook)
- `direct-response-copywriter/guides/sales-psychology.md` (playbook)
- `email-marketing-manager/guides/analytics-and-performance-optimization.md` (playbook)
- `email-marketing-manager/guides/deliverability-and-technical-management.md` (playbook)
- `email-marketing-manager/guides/email-copywriting-and-optimization.md` (playbook)
- `email-marketing-manager/guides/email-strategy-and-campaign-development.md` (playbook)
- `email-marketing-manager/guides/list-engagement-and-nurturing.md` (playbook)
- `email-marketing-manager/guides/marketing-automation-and-workflows.md` (playbook)
- `email-marketing-manager/guides/revenue-generation-and-monetization.md` (playbook)
- `growth-marketing-manager/guides/channel-development-and-scaling.md` (playbook)
- `growth-marketing-manager/guides/customer-lifecycle-and-retention-marketing.md` (playbook)
- `growth-marketing-manager/guides/data-analytics-and-growth-insights.md` (playbook)
- `growth-marketing-manager/guides/experimentation-and-testing-framework.md` (playbook)
- `growth-marketing-manager/guides/funnel-analysis-and-optimization.md` (playbook)
- `growth-marketing-manager/guides/growth-strategy-and-planning.md` (playbook)
- `growth-marketing-manager/guides/growth-technology-and-automation.md` (playbook)
- `head-of-marketing/guides/ai-enhanced-marketing-operations.md` (playbook)
- `head-of-marketing/guides/copywriting-and-messaging-mastery.md` (playbook)
- `head-of-marketing/guides/customer-value-journey.md` (playbook)
- `head-of-marketing/guides/funnel-architecture-and-offer-creation.md` (playbook)
- `head-of-marketing/guides/paid-media-and-customer-acquisition.md` (playbook)
- `head-of-sales/guides/lead-qualification-and-pipeline-management.md` (playbook)
- `head-of-sales/guides/sales-analytics-forecasting-and-marketing-alignment.md` (playbook)
- `head-of-sales/guides/sales-compensation-and-commission-design.md` (playbook)
- `head-of-sales/guides/sales-enablement-and-content-creation.md` (playbook)
- `head-of-sales/guides/sales-process-architecture-and-pipeline-optimization.md` (playbook)
- `head-of-sales/guides/sales-psychology-and-closing-mastery.md` (playbook)
- `head-of-sales/guides/sales-talent-acquisition-and-development.md` (playbook)
- `head-of-sales/guides/sales-team-leadership-and-performance-management.md` (playbook)
- `head-of-sales/guides/sales-technology-and-crm-optimization.md` (playbook)
- `paid-media-manager/guides/ad-creative-and-copy-development.md` (playbook)
- `paid-media-manager/guides/bidding-targeting-and-optimization.md` (playbook)
- `paid-media-manager/guides/campaign-management-and-execution.md` (playbook)
- `paid-media-manager/guides/landing-page-and-conversion-rate-optimization-cro.md` (playbook)
- `paid-media-manager/guides/paid-media-operations-and-technology.md` (playbook)
- `paid-media-manager/guides/paid-media-strategy-and-planning.md` (playbook)
- `paid-media-manager/guides/performance-analytics-and-reporting.md` (playbook)
- `social-media-manager/guides/audience-building-and-engagement-excellence.md` (playbook)
- `social-media-manager/guides/content-creation-and-creative-production.md` (playbook)
- `social-media-manager/guides/influencer-relations-and-partnership-development.md` (playbook)
- `social-media-manager/guides/platform-mastery-and-content-optimization.md` (playbook)
- `social-media-manager/guides/social-commerce-and-performance-analytics.md` (playbook)
- `social-media-manager/guides/social-media-strategy-and-brand-development.md` (playbook)
