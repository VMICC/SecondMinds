# Case 18: Build the ad campaign brief: copy, audience, and budget in one pass

**Section:** C / Listings & Marketing (One input. Every version you need.)
**Owner:** `agents/3-marketing-sales/paid-media-manager/`
**You get:** Launch-ready brief + follow-up drafts
**Channels:** Meta ads / Messenger
**Source:** System AI Realtor OS guide, page 11 / 16

## The problem

Running an ad means writing copy, picking photos, defining the audience, and setting the follow-up: four jobs, so the ad never launches.

## Copy + paste prompt

```
Build a campaign brief for this [listing / lead magnet]: 3 headlines, 2 versions of ad text, photo order, audience definition for [farm], a starter budget, and a 3-step follow-up sequence for commenters and clickers. Draft the follow-ups, do not send them.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._

_Scope note: this is the full campaign brief. For a single just-listed ad only, use `just-listed-ad.md` in this same folder._
