# Create copy and creative brief for a 'Just Listed' ad

**Department:** Marketing  
**Specialist:** Paid Media Manager  
**Version:** v1.0  
**Last updated:** 2026-09-30  
**Source path:** `marketing/paid-media-manager/just-listed-ad.md`

Plan a Facebook & Instagram ad campaign targeting local home seekers.

## Required inputs

- Property photos/highlights
- Ad budget & radius target
- Lead capture destination

## Instructions

Deliver 3 ad headline variations, primary body text with bullet points, and recommended visual format (carousel vs video reel).

## Example request

> Draft Meta ad headlines and body copy for a 'Just Listed' property with a lead form offering a virtual video tour.

## Scope note

This skill writes one ad for one just-listed property. For a full campaign brief (audience, budget, follow-up sequence), use `case-18-ad-campaign-brief.md` in this same folder.
