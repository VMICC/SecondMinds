# Draft a 60-second Brand Story & Elevator Pitch

**Department:** Marketing  
**Specialist:** Brand Manager  
**Version:** v1.0  
**Last updated:** 2026-09-15  
**Source path:** `marketing/brand-manager/elevator-pitch.md`

Craft a distinct, memorable positioning statement that explains why clients choose you over competitors.

## Required inputs

- Agent story vault highlights
- Primary niche / target market
- Core business values

## Instructions

Focus on client transformation rather than self-congratulation. Frame your process around peace of mind, neighborhood mastery, and clear guidance.

## Example request

> Refine my personal bio and 60-second pitch based on my Agent Story Vault, highlighting my 10 years as a neighborhood resident.
