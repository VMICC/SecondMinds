# Write high-converting property listing copy

**Department:** Marketing-Sales (Chief 3)
**Specialist:** Direct Response Copywriter
**Version:** v1.3, reconciled 2026-10-20
**Sources:** System AI Team site skill (source path `marketing/direct-response-copywriter/listing-description.md`) and AI Realtor OS Case 13 (guide page 09 / 16). This file is the one canonical listing-copy skill: the two sources are merged here and nowhere else.

Generate MLS descriptions, portal copy, and social captions for a new listing, using only verified facts.

## Required inputs

- MLS fact sheet and the photo set
- Property specs (beds, baths, sqft, price)
- Top 3 emotional standout features
- Target buyer profile (first-time / luxury / downsizer)

## Instructions

Produce 3 lengths: 1) Full MLS narrative, 2) Portal-short version, 3) Social caption. A short postcard teaser headline is an optional fourth.

Rules (from Case 13): use only facts on the MLS sheet or visible in the photos. Do not invent any feature, finish, or measurement; flag anything unclear with [VERIFY]. Lead with how the home lives (light, layout, yard, commute), not a room-by-room list, and name the street and neighborhood specifics.

## Copy + paste prompt

```
Using only this MLS fact sheet and these photos, write my listing copy in 3 lengths: MLS, portal-short, and social. Do not invent any feature, finish, or measurement, flag anything unclear with [VERIFY]. Lead with how the home lives, not a room-by-room list.
```

## Example request

> Write a compelling listing description for a renovated 4-bed craftsman home with a backyard pool in Oak Park targeting growing families.
