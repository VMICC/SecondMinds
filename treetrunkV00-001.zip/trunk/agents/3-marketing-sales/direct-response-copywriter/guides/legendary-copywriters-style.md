# Legendary Copywriters Style Guide

## Direct Response Copywriter Agent Training Guide: Legendary Copywriters Style Guide

Master the Techniques of History's Greatest Copywriters - ChatGPT Project Optimized

### David Ogilvy - "The Father of Advertising"

#### Core Philosophy

"The consumer isn't a moron; she is your wife. You insult her intelligence if you assume that a mere slogan and a few vapid adjectives will persuade her to buy anything."

#### Signature Techniques

1. Fact-Heavy Headlines

Use specific, researched facts

Include the product name in headlines

Test multiple headline variations

Examples:

"At 60 miles an hour the loudest noise in this new Rolls-Royce comes from the electric clock"

"The man in the Hathaway shirt"

"Only Dove is one-quarter moisturizing cream"

2. Long-Form Educational Copy

Inform and educate, don't just sell

Use subheadings for easy scanning

Include detailed product information

Back claims with research and facts

3. Sophisticated Imagery and Positioning

Create aspirational brand image

Use elegant, refined language

Position products for discerning customers

Build brand personality through copy

4. The Ogilvy Formula:

Headline with news or benefit

Amplify with subheadline

Visual that supports the story

Body copy that informs and persuades

Call-to-action that's clear and direct

When to Use Ogilvy Style:

Premium/luxury products

Educated, affluent audience

Brand-building campaigns

Products requiring explanation

B2B professional services

Copy Characteristics:

Respectful of audience intelligence

Fact-based and research-driven

Elegant but accessible language

Strong brand personality

Educational approach

### Eugene Schwartz - "The Breakthrough Advertising Master"

#### Core Philosophy

"Copy cannot create desire for a product. It can only take the hopes, dreams, fears and desires that already exist in the hearts of millions of people, and focus those already existing desires onto a particular product."

#### Signature Techniques

1. Market Sophistication Analysis

Stage 1: Simple benefit statement

Stage 2: Elaborate on benefit with proof

Stage 3: Show unique mechanism

Stage 4: Elaborate on mechanism

Stage 5: Identify with prospect's desires

2. Mass Desire Identification

Tap into existing market desires

Don't create new desires, redirect existing ones

Focus on what people already want

Amplify existing frustrations and hopes

3. The Schwartz Headline Formula:

Promise + Mechanism + Proof

"How [Mechanism] [Delivers Benefit] [For Target Market]"

Focus on the "how" not just the "what"

Examples:

"How to Win Friends and Influence People"

"The Lazy Man's Way to Riches"

"How I Made $1,000,000 in Mail Order"

4. Awareness Level Copywriting:

Most Aware: Just price and deal

Product Aware: Benefits and features

Solution Aware: Product vs. alternatives

Problem Aware: Problem and solution

Unaware: Identify problem first

When to Use Schwartz Style:

Mass market products

Direct response campaigns

Products with unique mechanisms

Crowded, competitive markets

Audiences at different awareness levels

Copy Characteristics:

Psychologically sophisticated

Mechanism-focused

Desire-amplifying language

Market awareness-appropriate

Mass appeal approach

### Claude Hopkins - "The Scientific Advertiser"

#### Core Philosophy

"The time has come when advertising has in some hands reached the status of a science. It is based on fixed principles and is reasonably exact."

#### Signature Techniques

1. Test Everything

A/B test all elements

Track and measure results

Use coupons for tracking

Base decisions on data, not opinions

2. Specific Claims with Proof

Use exact numbers and statistics

Provide verifiable facts

Include testimonials and case studies

Avoid vague superlatives

Examples:

"Pepsodent removes the film on teeth"

"Schlitz beer bottles are sterilized with live steam"

"Van Camp's pork and beans - 94% pure food"

3. Reason-Why Advertising

Always give reasons for claims

Explain the "why" behind benefits

Use logical progression of ideas

Build credible arguments

4. Hopkins' Testing Rules:

Test headlines extensively

Measure actual sales, not just response

Use split-run testing

Let results guide decisions

When to Use Hopkins Style:

Products requiring credibility

Skeptical audiences

Measurable direct response campaigns

Products with technical benefits

Competitive markets requiring proof

Copy Characteristics:

Scientifically rigorous

Fact-based and specific

Logical argument structure

Results-driven approach

Conservative, credible tone

### Joseph Sugarman - "The Psychological Triggers Master"

#### Core Philosophy

"The purpose of the first sentence is to get you to read the second sentence. The purpose of the second sentence is to get you to read the third sentence. And so on."

#### Signature Techniques

1. The Slippery Slide

Each sentence leads to the next

Maintain reading momentum

Use curiosity gaps and open loops

Vary sentence length for rhythm

2. Psychological Triggers (30+ triggers)

Reason Why: People need reasons for actions

Collectibility: Limited edition appeal

Sense of Urgency: Time-sensitive offers

Fear: What they might lose

Instant Gratification: Immediate benefits

Exclusivity: Special access or membership

3. Story-Driven Copy

Start with engaging stories

Use personal anecdotes

Create emotional connection

Weave product benefits into narrative

4. The Sugarman Formula:

Attention-grabbing opening

Story that builds interest

Transition to product benefits

Handle objections naturally

Strong call-to-action

Examples of Openings:

"I was sitting in my office when the phone rang..."

"It was the most embarrassing moment of my life..."

"The ad was so bad, I almost threw it away..."

When to Use Sugarman Style:

Consumer products

Emotional purchase decisions

Direct mail campaigns

Products requiring demonstration

Audiences who enjoy stories

Copy Characteristics:

Story-driven approach

Psychological sophistication

Conversational tone

Emotional engagement

Smooth reading flow

### Gary Halbert - "The Prince of Print"

#### Core Philosophy

"The most important thing in advertising is to find a starving crowd and then give them what they want to eat."

#### Signature Techniques

1. Market-First Approach

Find hungry markets first

Identify desperate needs

Target people already buying

Focus on market over product

2. The Halbert Energy Formula:

E = Emotion

N = Newness

E = Exclusivity

R = Reciprocity

G = Guilt

Y = Yes Momentum

3. Personal, Conversational Style

Write like talking to a friend

Use "you" and "I" frequently

Share personal experiences

Be authentic and vulnerable

4. The Halbert Letter Structure:

Personal greeting

Credibility establishment

Problem identification

Solution presentation

Social proof

Offer details

Urgency creation

Personal signature

Examples of Style:

"Dear Friend and Subscriber,"

"Let me tell you about the time I..."

"Here's what I discovered..."

"This may sound crazy, but..."

When to Use Halbert Style:

Personal brands and services

Relationship-based selling

High-involvement purchases

Audiences seeking authenticity

Direct mail and email marketing

Copy Characteristics:

Highly personal tone

Conversational language

Story-heavy approach

Emotional authenticity

Market-focused thinking

### Dan Kennedy - "The Millionaire Maker"

#### Core Philosophy

"There is no B2B or B2C. There is only P2P: Person to Person."

#### Signature Techniques

1. Personality-Driven Copy

Strong, opinionated voice

Controversial statements

Personal branding emphasis

Authority positioning

2. The Kennedy Credibility Formula:

Credentials and achievements

Client success stories

Media mentions and awards

Specific results and numbers

3. Multi-Step Sales Process

Lead magnets and free reports

Educational email sequences

Webinars and presentations

High-ticket backend offers

4. The Kennedy Headlines:

"Who Else Wants [Benefit]?"

"The Secret of [Achievement]"

"How to [Achieve Goal] Even If [Objection]"

"Warning: [Cautionary Statement]"

Examples:

"Who Else Wants to Be a Millionaire?"

"How to Make Your Car Last a Lifetime"

"Warning: Don't Start a Business Until You Read This"

When to Use Kennedy Style:

Professional services

High-ticket coaching/consulting

B2B sales and marketing

Authority-based positioning

Multi-step sales funnels

Copy Characteristics:

Strong personality voice

Authority positioning

Educational approach

Multi-step selling

Results-focused messaging

### Clayton Makepeace - "The Total Package"

#### Core Philosophy

"Great copy is a total package that combines compelling emotional appeals with logical justification and irresistible offers."

#### Signature Techniques

1. The Big Promise

Lead with transformational outcome

Make it specific and believable

Support with proof and mechanism

Create emotional urgency

2. The Makepeace Structure:

Big Promise (headline)

Credibility (who's behind it)

Discovery Story (how it was found)

Mechanism (how it works)

Proof (evidence it works)

Benefits (what you get)

Objections (handle concerns)

Offer (what's included)

Guarantee (risk reversal)

Urgency (why act now)

3. Emotional Amplification

Paint vivid before/after pictures

Use sensory language

Create urgency through consequences

Appeal to core human desires

4. The Makepeace Headlines:

"The [Number] [Category] That [Benefit]"

"How [Unlikely Person] [Achieved Result]"

"The [Adjective] [Thing] That [Outcome]"

Examples:

"The 5 Foods That Kill Belly Fat"

"How a 65-Year-Old Grandmother Became a Millionaire"

"The Weird Trick That Eliminates Back Pain"

When to Use Makepeace Style:

Health and wellness products

Financial opportunities

Self-improvement offers

Information products

Long-form sales letters

Copy Characteristics:

Emotionally compelling

Benefit-heavy approach

Strong proof elements

Complete sales arguments

Transformational focus

### Style Selection Guide

#### By Product Type

Luxury/Premium: Ogilvy (sophisticated, fact-based)

Mass Market: Schwartz (desire-focused, mechanism-driven)

Technical/B2B: Hopkins (scientific, proof-heavy)

Consumer Electronics: Sugarman (story-driven, psychological)

Personal Services: Halbert (conversational, authentic)

Coaching/Consulting: Kennedy (authority-based, educational)

Health/Wealth: Makepeace (emotional, transformational)

#### By Audience Sophistication

Highly Educated: Ogilvy, Hopkins

Mass Market: Schwartz, Makepeace

Relationship-Focused: Halbert, Kennedy

Story-Lovers: Sugarman, Halbert

Results-Driven: Kennedy, Makepeace

Skeptical: Hopkins, Ogilvy

#### By Channel

Print Ads: Ogilvy, Hopkins

Direct Mail: Halbert, Makepeace

Email: Kennedy, Sugarman

Sales Letters: Schwartz, Makepeace

Landing Pages: Sugarman, Kennedy

Social Media: Halbert, Kennedy

### Combining Styles

#### Effective Combinations

Ogilvy + Hopkins:

Sophisticated facts with scientific proof

Perfect for premium B2B products

Schwartz + Sugarman:

Mass desire focus with psychological triggers

Ideal for consumer direct response

Halbert + Kennedy:

Personal authenticity with authority positioning

Great for personal brand services

Makepeace + Schwartz:

Emotional transformation with mechanism focus

Powerful for health/wealth offers

### Master Copywriter Checklist

Before writing, ask:

Which master's style fits this audience?

What would [chosen master] focus on first?

How would they structure this argument?

What tone would they use?

What proof would they emphasize?

How would they handle objections?

What call-to-action would they use?

### Quick Style Reference

| Master | Best For | Key Technique | Signature Element |
| --- | --- | --- | --- |
| Ogilvy | Premium brands | Fact-heavy headlines | Sophisticated imagery |
| Schwartz | Mass market | Market sophistication | Mechanism focus |
| Hopkins | Skeptical buyers | Reason-why copy | Scientific testing |
| Sugarman | Story lovers | Slippery slide | Psychological triggers |
| Halbert | Personal brands | Conversational tone | Market-first thinking |
| Kennedy | Authority building | Personality-driven | Multi-step selling |
| Makepeace | Transformation | Big promise | Emotional amplification |

Study these masters' techniques and adapt their styles to match your audience, product, and objectives. The best copywriters blend multiple approaches while maintaining authenticity and focus on results.
