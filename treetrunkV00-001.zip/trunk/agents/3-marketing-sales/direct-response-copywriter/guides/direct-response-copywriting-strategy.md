# Direct Response Copywriting Strategy Guide

## Direct Response Copywriter Agent Training Guide: Direct Response Copywriting Strategy Guide

When & How to Use Each Framework - ChatGPT Project Reference

### Quick Framework Selection

#### By Audience Temperature

Cold (Never heard of you): AIDA, SLAP

Warm (Aware of problem): PAS, BAB

Hot (Ready to buy): Direct offer + urgency

#### By Product Type

High-ticket ($1000+): PASTOR, Problem-Promise-Proof-Proposal

Low-ticket ($1-100): SLAP, 4 U's, Simple AIDA

Services: Star-Story-Solution, QUEST

B2B: QUEST, ACCA (professional, ROI-focused)

B2C: PAS, BAB (emotional, benefit-focused)

#### By Channel

Email sequences: Soap Opera, Godfather

Landing pages: PASTOR, Long AIDA

Social ads: Condensed AIDA, PAS

VSL: PAS + Story, PASTOR + Multiple stories

### Situation-Specific Strategies

#### Cold Traffic Strategy

Challenge: Attention and credibility Framework: AIDA or SLAP Focus: Pattern interrupts, strong headlines Proof: High-authority social proof Length: Shorter initially Opening: "STOP: Before you [common action], read this..."

#### Warm Prospects Strategy

Challenge: Differentiation and urgency Framework: PAS or BAB Focus: Problem agitation, unique positioning Proof: Comparative case studies Length: Medium to long-form Opening: "If you're like most [audience], you've tried [solutions] only to find..."

#### Hot Prospects Strategy

Challenge: Closing and objection handling Framework: Direct offer with urgency Focus: Clear value prop, risk reversal Proof: Recent testimonials, guarantees Length: Concise, action-oriented Opening: "You're ready to [goal]. Here's how to start today..."

### Channel-Specific Applications

#### Email Marketing

##### Welcome Series

Framework: Godfather Sequence Strategy: Build relationship through value

Welcome + immediate value

Personal story/origin

Valuable resource

Social proof/community

Soft product introduction

##### Product Launch

Framework: Soap Opera + Urgency
Strategy: Build anticipation

Tease announcement

Reveal problem/opportunity

Introduce solution

Social proof

Handle objections

Create urgency

Last chance

#### Social Media Ads

##### Facebook/Instagram

Framework: AIDA (condensed)

Headline: 5-7 words, benefit/curiosity

Body: Problem + solution + proof (125 words max)

CTA: Action-oriented

Visual: Outcome-focused

##### LinkedIn (B2B)

Framework: QUEST

Headline: Role-specific benefit

Body: Business problem + insight + solution preview

CTA: Professional action

Visual: Data-focused, professional

#### Landing Pages

##### Lead Generation

Framework: AIDA + Social Proof Above fold: Headline + subheadline + opt-in form + trust indicators Below fold: Benefits + social proof + objection handling

##### Sales Pages

Framework: PASTOR or Long AIDA Structure: Headline → Problem → Solution → Benefits → Proof → Features → FAQ → Guarantee → Offer → Urgency → CTA

### Psychological Trigger Timing

#### Use Fear-Based Copy When:

Insurance/security products

Health/safety concerns

Competitive disadvantage

Compliance issues

Time-sensitive opportunities

Integration: Problem agitation (PAS), urgency sections Examples: "Every day you wait, competitors gain ground..." / "Hidden costs could bankrupt your business..."

#### Use Desire-Based Copy When:

Lifestyle/luxury products

Achievement programs

Transformation services

Aspirational purchases

Status enhancement

Integration: AIDA attention, BAB "after" section, PASTOR transformation Examples: "Imagine walking into any room with confidence..." / "Picture achieving [goal] while others struggle..."

#### Use Logic-Based Copy When:

B2B decisions

High-ticket purchases

Technical products

Professional services

Investment opportunities

Integration: Proof sections, QUEST education, Problem-Promise-Proof-Proposal Examples: "Data shows 300% ROI in 6 months..." / "Step-by-step process delivers results..."

### Advanced Combinations

#### Multi-Framework Approach

For: Complex, high-value offers Example: QUEST + PASTOR

Qualify audience (QUEST)

Understand situation (QUEST)

Problem identification (PASTOR)

Amplify consequences (PASTOR)

Educate on solution (QUEST)

Story transformation (PASTOR)

Stimulate excitement (QUEST)

Show transformation (PASTOR)

Present offer (PASTOR)

Transition to action (Both)

#### Sequential Strategy

For: Multi-touch campaigns Email Example:

Email 1: SLAP (attention)

Email 2: PAS (problem focus)

Email 3: Star-Story-Solution (social proof)

Email 4: BAB (transformation)

Email 5: Direct offer + urgency

### Timing Considerations

#### Seasonal Strategies

Black Friday: Price urgency

New Year: Transformation focus

Q1: Goal-setting and planning

Q4: Results and preparation

#### Market Conditions

Economic uncertainty: Value/ROI focus, guarantees, cost savings

Economic growth: Opportunity focus, premium positioning, expansion

### Testing Strategy

#### Priority Testing Order

Headlines (biggest impact)

Opening hooks (engagement)

Call-to-action (conversion)

Offer presentation (value perception)

Social proof placement (credibility)

#### Framework Testing

Test A: AIDA structure

Test B: PAS structure

Measure: Engagement + conversion

Analyze: Audience preference

### Decision Tree

#### Start: What's Your Goal?

Generate Leads:

Cold traffic → AIDA with attention grabbers

Warm traffic → QUEST with qualification

Make Sales:

Simple products → PAS for quick decisions

Complex products → PASTOR for comprehensive persuasion

Build Relationships:

New relationships → Godfather sequence

Established audience → Story-based approaches

Launch Products:

Soap Opera + Urgency for anticipation

#### Secondary Filters:

By Audience:

Cold → Attention-focused (AIDA, SLAP)

Warm → Problem-focused (PAS, BAB)

Hot → Direct offer + urgency

By Complexity:

Simple → Short frameworks (AIDA, PAS)

Complex → Comprehensive (PASTOR, QUEST)

By Price:

Low → Impulse-focused (SLAP, 4 U's)

High → Logic/proof-focused (Problem-Promise-Proof-Proposal)

### Common Mistakes

#### Framework Mismatches

❌ Complex frameworks for simple decisions ✅ Match complexity to decision complexity

❌ Urgency frameworks for relationship-building
✅ Value-first for long-term relationships

#### Audience Misalignment

❌ B2C emotional triggers for B2B ✅ Adapt triggers to audience context

❌ Same triggers for all audiences ✅ Test different approaches per segment

#### Timing Errors

❌ Leading with offers before interest ✅ Follow framework structure, build engagement first

❌ Urgency without value ✅ Establish value before scarcity

### Quick Reference Cheat Sheet

| If Your Audience Is... | Use This Framework | Focus On... |
| --- | --- | --- |
| Seeing you first time | AIDA | Strong headlines, credibility |
| Knows the problem | PAS | Problem agitation, differentiation |
| Ready to buy | Direct + Urgency | Clear value, risk reversal |
| Skeptical | Star-Story-Solution | Relatable proof stories |
| Professional/B2B | QUEST | Education, ROI, logic |
| Price-sensitive | Value-focused PAS | Cost savings, efficiency |
| Premium market | PASTOR | Comprehensive benefits, status |

Use this guide to select the optimal copywriting approach for every situation. Reference alongside the Training Guide for complete framework implementation.
