# Sales Psychology Training Guide

## Direct Response Copywriter Agent Training Guide: Sales Psychology Training Guide

Copywriter Assistant Reference - ChatGPT Project Optimized

### Core Psychology Principles

#### 1. Reciprocity Principle

What it is: People feel obligated to return favors When to use: Lead magnets, free content, relationship building How to apply:

"Here's a free [valuable resource] because [reason]"

"I'm giving you this [gift] with no strings attached"

"As a thank you for [action], here's [bonus]"

Copy examples:

"Before I ask for anything, let me give you this free guide..."

"I want to share something valuable with you first..."

"Here's a gift to help you [achieve goal]..."

#### 2. Social Proof

What it is: People follow others' actions as guidance Types & Applications:

Customer Numbers:

"Join 50,000+ entrepreneurs who use [product]"

"Over 10,000 customers can't be wrong"

"Trusted by [impressive number] businesses"

Testimonials:

"[Name] increased revenue 40% in 90 days"

"This changed my business completely" - [Customer]

"[Specific result] in just [timeframe]"

Expert Endorsements:

"Recommended by [authority figure]"

"As featured in [prestigious publication]"

"[Expert] calls this 'the best solution available'"

Peer Approval:

"Business owners like you are choosing [product]"

"Other [industry] professionals prefer [solution]"

"People in your situation typically see [result]"

#### 3. Authority Bias

What it is: People trust and follow perceived experts When to use: Establishing credibility, overcoming skepticism How to establish authority:

Credentials:

"With 15 years in [industry]..."

"Having helped 500+ businesses..."

"As a certified [qualification]..."

Results:

"After generating $50M in sales..."

"Having trained 10,000+ professionals..."

"With a track record of [impressive outcome]..."

Recognition:

"Featured in Forbes, Inc., and Entrepreneur"

"Keynote speaker at [prestigious events]"

"Advisor to Fortune 500 companies"

#### 4. Scarcity Principle

What it is: Limited availability increases perceived value Types & When to Use:

Time Scarcity:

Use for: Product launches, special offers, seasonal promotions

"Offer expires in 48 hours"

"Registration closes Friday at midnight"

"Limited-time pricing ends [date]"

Quantity Scarcity:

Use for: Exclusive programs, physical products, consulting spots

"Only 50 spots available"

"Limited to first 100 customers"

"Exclusive group of 25 members"

Access Scarcity:

Use for: Premium offerings, insider programs, VIP access

"Members-only opportunity"

"Invitation-only program"

"Exclusive access for [qualified group]"

Authenticity Rules:

Must be genuine limitations

Provide specific reasons for scarcity

Don't manufacture false scarcity

#### 5. Loss Aversion

What it is: Fear of losing is stronger than desire to gain When to use: Overcoming procrastination, creating urgency Applications:

Cost of Inaction:

"Every day you wait costs you [specific amount]"

"While you're deciding, competitors are gaining ground"

"The longer you delay, the harder it becomes to [achieve goal]"

Opportunity Loss:

"Don't miss out on [specific opportunity]"

"This chance won't come again"

"What you stand to lose by waiting..."

Status Quo Risks:

"Staying where you are means [negative consequence]"

"The hidden cost of doing nothing"

"What happens if you don't [take action]?"

#### 6. Commitment and Consistency

What it is: People align actions with previous commitments When to use: Getting micro-commitments, building engagement Techniques:

Small Commitments First:

"Are you committed to growing your business?"

"Do you want to increase your revenue?"

"Would you like to solve [problem] once and for all?"

Public Commitments:

"Share your goal in the comments"

"Tell someone about your decision"

"Join others who've committed to [action]"

Written Commitments:

"Write down your biggest challenge"

"Complete this assessment"

"Fill out your goal worksheet"

#### 7. Anchoring Effect

What it is: First number presented influences all following judgments When to use: Pricing presentations, value comparisons Applications:

High Anchor Pricing:

Present premium option first

"Our enterprise package is $10,000, but for small businesses, we offer this at just $997"

"Consultants charge $500/hour for this, but you get it all for $97"

Value Anchoring:

"This strategy generated $100,000 for one client"

"The average business loses $50,000 annually to this problem"

"One implementation saved a company $25,000"

#### 8. Contrast Principle

What it is: Perception changes based on comparisons When to use: Highlighting benefits, positioning offers Techniques:

Before vs. After:

"Instead of struggling with [problem], imagine [solution]"

"Rather than [current struggle], you'll [desired outcome]"

"Transform from [before state] to [after state]"

Competitor Comparisons:

"While others offer [basic solution], we provide [superior solution]"

"Unlike [alternative], our approach [unique benefit]"

"Where [competitor] falls short, we excel"

Problem vs. Solution:

"Stop [negative behavior] and start [positive behavior]"

"End [frustration] and begin [satisfaction]"

"Replace [old way] with [new way]"

### Emotional Triggers

#### 9. Fear-Based Motivation

When to use: Insurance, security, competitive threats, health Effective applications:

"What happens if [negative scenario] occurs?"

"Don't let [threat] destroy [valuable thing]"

"Protect yourself from [specific danger]"

Balance with hope:

Always follow fear with solution

Provide clear path to safety

Emphasize control and empowerment

#### 10. Desire and Aspiration

When to use: Lifestyle products, achievement programs, status symbols Trigger phrases:

"Imagine having [desired outcome]"

"Picture yourself [ideal scenario]"

"What would [achievement] mean to you?"

"Join the elite group who [exclusive benefit]"

#### 11. Pride and Status

When to use: Premium products, exclusive programs, professional advancement Applications:

"Separate yourself from [common group]"

"Join the top 1% who [exclusive action]"

"Be among the first to [new opportunity]"

"Exclusive access for [qualified group]"

#### 12. Curiosity and Mystery

When to use: Headlines, email subject lines, content hooks Techniques:

"The secret that [authority] don't want you to know"

"What [successful group] do differently"

"The hidden reason why [common problem] happens"

"Why [surprising fact] changes everything"

### Cognitive Biases in Copy

#### 13. Confirmation Bias

What it is: People seek information confirming existing beliefs Application: Align with audience's existing beliefs, then guide to new conclusions

"You already know that [accepted belief]"

"As you've probably experienced [common situation]"

"Most people believe [common assumption], and they're right about [part], but..."

#### 14. Bandwagon Effect

What it is: People do what others are doing Usage: Show momentum and popular adoption

"Thousands are already [taking action]"

"The fastest-growing solution in [industry]"

"Join the movement of [group] who [action]"

#### 15. Halo Effect

What it is: Positive impression in one area influences overall perception Application: Lead with strongest credential or result

"The same system that helped [impressive client] can help you"

"From the creator of [successful product]"

"Used by [prestigious companies]"

### Application Framework

#### Psychology Selection by Audience Type

Skeptical Audience:

Primary: Authority + Social Proof

Secondary: Reciprocity (free value first)

Avoid: Heavy scarcity (increases skepticism)

Eager Audience:

Primary: Scarcity + Social Proof

Secondary: Desire/Aspiration

Avoid: Too much fear (may overwhelm)

Analytical Audience:

Primary: Authority + Logic-based Social Proof

Secondary: Consistency (logical progression)

Avoid: Pure emotion without logic

Price-Sensitive Audience:

Primary: Loss Aversion + Value Anchoring

Secondary: Social Proof (cost savings)

Avoid: Status/premium positioning

#### Psychology by Copy Type

Headlines:

Curiosity + Social Proof

Fear + Solution promise

Desire + Specificity

Opening Paragraphs:

Reciprocity (free value)

Social Proof (you're not alone)

Authority (credibility establishment)

Body Copy:

Contrast (before vs. after)

Social Proof (detailed testimonials)

Authority (credentials and results)

Offers:

Scarcity (limited availability)

Anchoring (value comparison)

Loss Aversion (cost of inaction)

Closing:

Consistency (commitment alignment)

Urgency (time scarcity)

Social Proof (others are acting)

### Ethical Guidelines

#### Authentic Application

Use real scarcity, not manufactured

Provide genuine value in reciprocity

Share true testimonials and results

Build real authority through expertise

#### Balanced Approach

Combine multiple principles (don't rely on one)

Balance emotion with logic

Provide substance behind psychology

Respect audience intelligence

#### Long-term Thinking

Build trust, don't exploit

Focus on mutual benefit

Create genuine value

Maintain ethical standards

### Psychology Combinations

#### High-Converting Combinations

Authority + Social Proof + Scarcity: "As featured in Forbes [Authority], with 10,000+ successful clients [Social Proof], but only 50 spots available [Scarcity]"

Reciprocity + Loss Aversion + Urgency: "Here's a free strategy [Reciprocity] that prevents costly mistakes [Loss Aversion], but you must act by Friday [Urgency]"

Desire + Social Proof + Consistency: "Imagine achieving [goal] [Desire] like our 500+ successful clients [Social Proof]. Are you ready to commit to your success? [Consistency]"

### Quick Reference Guide

| Psychology Principle | Best For | Avoid When | Key Phrases |
| --- | --- | --- | --- |
| Reciprocity | Lead generation, relationship building | Hard selling immediately | "Here's a free...", "As a gift..." |
| Social Proof | Overcoming skepticism | No credible testimonials | "Join 10,000+...", "Customers report..." |
| Authority | Establishing credibility | Audience knows you're new | "With 15 years...", "Having helped..." |
| Scarcity | Creating urgency | False limitations | "Only 50 spots...", "Expires Friday..." |
| Loss Aversion | Overcoming procrastination | Happy, satisfied audience | "Every day costs you...", "Don't miss..." |
| Desire | Aspirational products | Practical, necessity items | "Imagine having...", "Picture yourself..." |

Use this guide to select and apply the right psychological triggers for your specific audience and copy type. Always combine multiple principles for maximum effectiveness while maintaining ethical standards.
