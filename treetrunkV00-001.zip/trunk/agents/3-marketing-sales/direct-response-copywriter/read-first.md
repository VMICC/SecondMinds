# Read first: Direct Response Copywriter

## Direct Response Copywriter Assistant Training Guide

Optimized for ChatGPT Project Reference

### Core Frameworks

#### 1. AIDA Framework

Use: Foundation for all persuasive copy

Attention: Compelling headline

Interest: Focus on benefits/problems

Desire: Show transformation

Action: Direct specific action

Template: "[Attention Hook] → [Problem/Benefit] → [Outcome Vision] → [Clear CTA]"

#### 2. PAS Framework

Use: Problem-focused copy

Problem: Identify main issue

Agitate: Make urgent/painful

Solution: Present offer as fix

Template: "Are you [problem]? → Every day costs you [consequence] → [Product] eliminates [problem] by [method]"

#### 3. PASTOR Framework

Use: Long-form comprehensive copy

Problem: Core issue

Amplify: Pain/consequences

Story: Case study/example

Transformation: Possible outcome

Offer: Present solution

Response: Create urgency

#### 4. Before & After Bridge (BAB)

Use: Clear transformation focus

Before: Current struggle

After: Desired future

Bridge: Your solution connects them

#### 5. QUEST Framework

Use: Targeted audience qualification

Qualify: Right audience

Understand: Their situation

Educate: Provide insights

Stimulate: Create excitement

Transition: Move to offer

### Specialized Formulas

#### 6. The 4 U's (Headlines)

Urgent: Time sensitivity

Unique: Something different

Ultra-specific: Concrete details

Useful: Clear value

#### 7. Star-Story-Solution

Star: Introduce customer

Story: Their journey

Solution: Your product as key

#### 8. Problem-Promise-Proof-Proposal

Problem: Define issue

Promise: Specific outcome

Proof: Evidence/testimonials

Proposal: Make offer

### Email Sequences

#### 9. Soap Opera Sequence

Use: Multi-email storytelling

Email 1: Introduce conflict

Email 2: Deepen story

Email 3: Turning point

Email 4: Resolution

Email 5: Offer with urgency

#### 10. Godfather Sequence

Use: Value-first relationship building

Email 1: Free valuable content

Email 2: Another resource

Email 3: Insider strategy

Email 4: Natural offer

### Psychology Triggers

#### Scarcity/Urgency

Limited quantity: "Only 50 spots"

Limited time: "Expires midnight"

Exclusive access: "Members only"

#### Social Proof Types

Testimonials: Direct customer quotes

Statistics: "10,000+ customers"

Expert endorsements: Authority figures

Case studies: Detailed success stories

#### Objection Handling

Acknowledge: "You might think..."

Understand: "I get that concern..."

Reframe: "Here's another view..."

Evidence: "Here's proof..."

### Copy Elements

#### Headlines (6-12 words)

Benefit-focused: "How to [achieve goal] in [timeframe]"

Curiosity-driven: "The secret [authority] don't want you to know"

Problem-focused: "Stop [negative behavior] that's costing you [consequence]"

#### Call-to-Action Buttons

Action-oriented: "Get Instant Access," "Start Now"

Benefit-focused: "Increase My Revenue," "Save Me Time"

Personal: "Get My Copy," "Send Me Details"

#### Guarantees

Money-back: "100% satisfaction or refund"

Performance: "Results guaranteed or work for free"

Better-than-free: "Keep bonuses if unsatisfied"

### Framework Selection Guide

| Situation | Best Framework | Why |
| --- | --- | --- |
| Cold traffic | AIDA/SLAP | Attention-grabbing |
| Warm audience | PAS/BAB | Leverage awareness |
| Long sales pages | PASTOR | Comprehensive persuasion |
| Email sequences | Soap Opera/Godfather | Relationship building |
| High-ticket | Problem-Promise-Proof-Proposal | Logic-based |
| B2B | QUEST/ACCA | Professional approach |
| Skeptical audience | Star-Story-Solution | Proof through narrative |

### Audience Adaptations

#### B2B Focus

ROI and business impact

Efficiency gains

Risk mitigation

Professional tone

Data-driven proof

#### B2C Focus

Personal benefits

Emotional satisfaction

Lifestyle improvement

Conversational tone

Emotional triggers

### Landing Page Structure

Headline (clear value prop)

Subheadline (supporting detail)

Benefits section

Social proof

Features/how it works

Objection handling/FAQ

Guarantee

Call-to-action

Urgency/scarcity

### Testing Priorities

Headlines (biggest impact)

Opening hooks

Call-to-action text/placement

Offer presentation

Social proof placement

### Common Mistakes to Avoid

Using complex frameworks for simple decisions

Leading with offers before building interest

Creating urgency without establishing value

Mismatching psychological triggers to audience type

Ignoring mobile optimization

### Prompt Template for AI Assistant

"Write [copy type] using [framework] for [target audience] promoting [product/service].

Target: [detailed description] Product: [features/benefits]
USP: [unique differentiator] Action: [desired outcome] Tone: [style preference] Length: [word count] Proof: [available testimonials/data] Objections: [common concerns]

Include [specific elements like urgency, guarantee, social proof]"

Reference this guide when training your Sales Copy Writer Assistant. Each framework includes templates and examples for immediate implementation.
