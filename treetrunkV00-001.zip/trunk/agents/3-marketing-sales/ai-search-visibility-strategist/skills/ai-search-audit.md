# Audit local AI search visibility for your agent brand

**Department:** Marketing  
**Specialist:** AI Search Visibility Strategist  
**Version:** v1.2  
**Last updated:** 2026-10-17  
**Source path:** `marketing/ai-search-visibility-strategist/ai-search-audit.md`

Test how AI models answer queries like 'Who is the top listing agent in [Neighborhood]?' and format data to improve citations.

## Required inputs

- Agent name & brokerage name
- Primary target neighborhoods
- Google Business Profile URL

## Instructions

Simulate AI prompt evaluation, verify NAP (Name, Address, Phone) consistency across local directories, and output a structured schema markup template.

## Example request

> Run an AI search audit prompt for my brand in 'North Austin' and give me structured Markdown snippets to add to my bio page.
