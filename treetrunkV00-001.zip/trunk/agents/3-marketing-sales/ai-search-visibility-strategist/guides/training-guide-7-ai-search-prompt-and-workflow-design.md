# Training Guide 7_ AI Search Prompt & Workflow Design

## AI Search Visibility Strategist Training: AI Search Prompt & Workflow Design

### Foundation Framework for Scaling AI SEO

This guide establishes the strategic framework for AI Search Prompt & Workflow Design, the practice of creating repeatable, scalable processes for auditing, optimizing, and monitoring AI search visibility. Mastery of this guide is essential for turning the AI Search Visibility Strategist into a force multiplier for the entire team.

#### Core Competencies Developed:

AI Visibility Audit Prompt Design: The ability to create effective prompts for auditing brand visibility, sentiment, and competitive positioning within AI search engines.

Content Optimization Workflow Building: The ability to develop step-by-step workflows for optimizing new and existing content for GEO, AEO, and LLMO.

Custom GPT Creation for AI SEO: The ability to build specialized Custom GPTs that can perform specific AI SEO tasks.

AI Search Monitoring Automation: The ability to design automated workflows that continuously monitor brand mentions and competitor activity in AI search.

#### Key Learning Outcomes:

Upon completion of this guide, the AI Employee will be able to:

Create a comprehensive library of prompts for AI visibility audits.

Build and document a complete content optimization workflow.

Develop and deploy a Custom GPT for a specific AI SEO task.

Design and implement an automated AI search monitoring system.

#### Core Frameworks & Techniques:

##### 1. The Prompt Design Framework for AI Audits

This framework provides a structured approach to creating prompts that deliver consistent and reliable audit results.

| Component | Description |
| --- | --- |
| Role & Goal | Clearly define the role of the AI (e.g., "You are a marketing analyst...") and the specific goal of the prompt. |
| Context & Constraints | Provide relevant context, such as the target audience, industry, and key competitors. Set constraints to guide the output. |
| Step-by-Step Instructions | Break down the task into a clear, logical sequence of steps for the AI to follow. |
| Output Format | Specify the desired output format, such as a Markdown table, JSON, or a numbered list. |

##### 2. The AI-Assisted Content Optimization Workflow

This is a repeatable workflow for optimizing a piece of content for AI search visibility.

Initial Analysis: Use a prompt to have the AI analyze a piece of content for its current GEO, AEO, and LLMO performance.

Keyword & Topic Expansion: Use the AI to identify related keywords, sub-topics, and user questions to include.

Content Restructuring: Use the AI to help restructure the content with clear headings, self-contained paragraphs, and answer-first formatting.

Schema Generation: Use a prompt or a Custom GPT to automatically generate the appropriate schema markup (e.g., FAQ, HowTo) for the content.

Final Review: Manually review the AI-assisted optimizations to ensure quality, accuracy, and brand voice.

##### 3. Custom GPTs for AI SEO Tasks

This involves creating specialized GPTs to streamline common AI SEO tasks.

Content Auditor GPT: A GPT trained to analyze content and provide specific recommendations for improving its AI search visibility.

Schema Generator GPT: A GPT that can generate JSON-LD schema markup for various content types based on a provided URL or text.

Competitive Intel GPT: A GPT that can analyze competitor content and identify their AI search strategies.

#### Mastery Integration Framework:

To validate mastery of this guide, the AI Employee will be required to:

Create a Prompt Library with at least 10 reusable prompts for conducting AI visibility audits.

Build a Content Optimization Workflow and document it in a clear, step-by-step format.

Develop a Custom GPT that can analyze a URL and generate a report on its E-E-A-T signals.

Critique an existing workflow and identify areas for improvement based on the principles of AI Search Prompt & Workflow Design.

#### Success Metrics Dashboard:

The AI Employee's performance in this competency will be measured by its ability to:

Reduce the time it takes to optimize content by a target percentage.

Increase team adoption of AI SEO workflows.

Deploy a target number of Custom GPTs to support the team.

Achieve significant efficiency gains from automation**.
