# Training Guide 6_ AI Search Analytics & Competitive Intelligence

## AI Search Visibility Strategist Training: AI Search Analytics & Competitive Intelligence

### Foundation Framework for AI Performance Measurement

This guide establishes the strategic framework for AI Search Analytics & Competitive Intelligence, the practice of tracking, measuring, and analyzing a brand's visibility within AI-generated search results. Mastery of this guide is essential for making data-driven decisions and proving the ROI of AI search optimization efforts.

#### Core Competencies Developed:

AI Visibility Tool Mastery: The ability to utilize leading AI search analytics platforms to track brand mentions and citations.

Competitive AI Audit Execution: The ability to analyze competitors' AI search visibility to identify their strategies, strengths, and weaknesses.

AI Search Reporting Development: The ability to create comprehensive reports and dashboards that communicate AI search performance to stakeholders.

Analytics to Strategy Translation: The ability to use data-driven insights to refine and optimize the overall AI search visibility strategy.

#### Key Learning Outcomes:

Upon completion of this guide, the AI Employee will be able to:

Set up and manage a comprehensive AI search analytics stack.

Conduct a full competitive AI audit and deliver a detailed report with strategic recommendations.

Create and automate monthly AI search performance reports.

Use analytics to identify and prioritize new AI search optimization opportunities.

#### Core Frameworks & Techniques:

##### 1. The AI Search Analytics Stack

This framework outlines the key tools and platforms required for comprehensive AI search analytics.

| Tool Category | Examples | Primary Use Case |
| --- | --- | --- |
| AI Visibility Monitoring | Semrush Enterprise AIO, AirOps, Goodie, SE Ranking | Tracking brand citations, share of voice, and sentiment across multiple AI platforms. |
| Manual Auditing | ChatGPT, Perplexity, Google AI Overviews | Manually running queries to spot-check AI responses and gather qualitative insights. |
| Traditional SEO Tools | Google Search Console, Ahrefs, Moz | Tracking organic traffic, keyword rankings, and backlink profiles that influence AI visibility. |
| Data Visualization | Google Looker Studio, Tableau | Creating custom dashboards that integrate data from multiple sources to provide a holistic view of performance. |

##### 2. The Competitive AI Visibility Audit

This is a step-by-step process for analyzing a competitor's presence in AI search.

Identify Core Topics: Define the key topics and questions for which the brand wants to be visible.

Select Competitors: Identify the top 3-5 direct and indirect competitors in the space.

Run Benchmark Queries: Use AI visibility tools to run a set of benchmark queries across major AI platforms.

Analyze Share of Voice: Compare the citation frequency of the brand versus its competitors for the target queries.

Identify Content Gaps: Determine which topics competitors are being cited for where the brand is not.

Reverse Engineer Success: Analyze the content and strategies of top-performing competitors to identify what is working.

##### 3. The AI Search Performance Report

This is a template for a monthly report that communicates AI search performance to key stakeholders.

Executive Summary: High-level overview of key findings and recommendations.

AI Visibility Dashboard: Key metrics including citation volume, share of voice, and sentiment over time.

Competitive Landscape: Analysis of competitor performance and any significant changes.

Key Wins & Opportunities: Highlights of successful initiatives and new opportunities identified.

Action Plan for Next Month: Specific, data-driven actions to be taken in the upcoming month.

#### Mastery Integration Framework:

To validate mastery of this guide, the AI Employee will be required to:

Set Up an AI Visibility Dashboard using a tool like Google Looker Studio that tracks at least five key AI search metrics.

Conduct a Competitive AI Audit for a brand, delivering a report that includes a share of voice analysis and at least three strategic recommendations.

Create a Monthly Performance Report based on a provided dataset.

Critique an existing analytics report and identify areas for improvement based on the principles of AI Search Analytics.

#### Success Metrics Dashboard:

The AI Employee's performance in this competency will be measured by its ability to:

Generate data-driven strategy adjustments on a monthly basis.

Maintain high accuracy in competitive analysis.

Achieve high stakeholder satisfaction with reports.

Provide fast time to insight for ad-hoc queries.
