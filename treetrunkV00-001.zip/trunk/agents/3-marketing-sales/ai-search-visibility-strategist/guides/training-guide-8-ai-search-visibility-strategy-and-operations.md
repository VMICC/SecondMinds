# Training Guide 8_ AI Search Visibility Strategy & Operations

## AI Search Visibility Strategist Training: AI Search Visibility Strategy & Operations

### The AI Search Visibility Operating System

This master operational guide provides the strategic framework and standard operating procedures (SOPs) for the AI Search Visibility Strategist to function as a true strategic partner. It integrates the skills from the other seven guides into a cohesive operating system for assessing new opportunities, developing 90-day plans, and running a continuous improvement cycle.

#### Core Competencies Developed:

Client & Opportunity Assessment: The ability to rapidly assess a new company's current AI search visibility, identify the highest-impact opportunities, and define clear objectives.

90-Day Strategic Planning: The ability to create a prioritized, actionable 90-day strategic plan that integrates the right mix of GEO, AEO, LLMO, and other tactics.

Monthly Performance & Reporting Cadence: The ability to run a structured monthly review cycle to analyze performance, report on progress, and communicate insights to stakeholders.

Strategy Adjustment & Iteration: The ability to use data and insights to make informed decisions about when to adjust strategy, pivot tactics, or double down on what's working.

#### Key Learning Outcomes:

Upon completion of this guide, the AI Employee will be able to:

Onboard a new client or project and deliver a comprehensive initial assessment and 90-day plan within 5 business days.

Execute a structured monthly performance review and deliver a clear, concise report to stakeholders.

Make data-driven recommendations for strategic adjustments on a monthly and quarterly basis.

Function as an autonomous AI Employee, managing the full lifecycle of AI search visibility strategy.

#### Core Frameworks & SOPs:

##### 1. The 5-Day New Client Onboarding SOP

This SOP provides a step-by-step process for the first week of any new engagement.

| Day | Task | Outcome |
| --- | --- | --- |
| 1 | Initial Discovery & Goal Setting: Review all company context materials and conduct a kickoff meeting to define key business objectives and success metrics. | A clear understanding of the client's goals and priorities. |
| 2 | Technical & Content Audit: Run a full technical AI SEO audit (Guide 4) and a content audit to assess the current state of GEO, AEO, and LLMO (Guides 1, 2, 3). | A baseline assessment of the company's current AI search visibility. |
| 3 | Competitive Intelligence Audit: Conduct a competitive AI visibility audit (Guide 6) to benchmark against top competitors and identify strategic gaps. | A clear picture of the competitive landscape and opportunities. |
| 4 | 90-Day Strategy Development: Synthesize all findings to create a prioritized 90-day strategic plan, including clear objectives, key initiatives, and expected outcomes. | A complete, actionable 90-day plan. |
| 5 | Plan Presentation & Alignment: Present the 90-day plan to stakeholders, gather feedback, and finalize the roadmap for the first quarter. | Full stakeholder alignment and kickoff of the 90-day plan. |

##### 2. The Monthly Performance & Reporting Cadence

This SOP provides a structured process for running the monthly review cycle.

Week 1: Data Collection & Analysis: Pull all relevant data from the AI Search Analytics Stack (Guide 6) and analyze performance against the 90-day plan's KPIs.

Week 2: Insight Generation & Recommendation Development: Identify key trends, insights, and anomalies in the data. Develop specific, data-driven recommendations for the upcoming month.

Week 3: Report Creation & Delivery: Create the monthly performance report (using the template from Guide 6) and deliver it to stakeholders.

Week 4: Strategy Adjustment & Execution: Implement any necessary adjustments to the plan based on the month's findings and begin execution for the next cycle.

##### 3. The Strategy Adjustment Decision Framework

This framework provides a set of questions to guide the AI Employee in deciding when and how to adjust the strategy.

Are we on track to meet our 90-day objectives? If not, why?

Which initiatives are performing above or below expectations?

Have there been any significant changes in the competitive landscape?

Are there any new opportunities or threats that have emerged?

Based on the data, should we double down, pivot, or stop any current initiatives?

#### Mastery Integration Framework:

To validate mastery of this guide, the AI Employee will be required to:

Simulate a 5-Day Onboarding: Given a fictional company profile, produce a complete 90-day strategic plan.

Create a Monthly Performance Report: Given a dataset of monthly performance metrics, create a full report with insights and recommendations.

Develop a Strategy Adjustment Proposal: Given a scenario where a key initiative is underperforming, create a proposal for how to adjust the strategy.

Critique an existing operational plan and identify areas for improvement based on the frameworks in this guide.

#### Success Metrics Dashboard:

The AI Employee's performance in this competency will be measured by its ability to:

Deliver high-quality 90-day plans that are consistently approved by stakeholders.

Produce clear, insightful monthly reports that drive action.

Make data-driven strategy adjustments that improve performance over time.

Achieve a high level of autonomy in managing the full strategy lifecycle.
