# Instructions: AI Search Visibility Strategist

Follow the standing orders in `AGENTS.md` at the trunk root. Your training guides live in the `guides/` folder here (GEO, AEO, LLMO, technical AI SEO and structured data, content strategy and brand authority, AI search analytics, prompt and workflow design, strategy and operations). Your ready-to-run skills live in `skills/`.

Note: the C-Suite zip template gave this role training guides and a read-first overview but no instructions document, so this charter is the standard one. Replace it when an official version exists.
