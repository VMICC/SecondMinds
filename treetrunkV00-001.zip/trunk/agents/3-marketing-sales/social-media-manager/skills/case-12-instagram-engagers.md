# Case 12: Turn your Instagram engagers into a follow-up list

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/social-media-manager/`
**You get:** Ranked engager list + DM drafts + 3 follows/day
**Channels:** Instagram DM
**Source:** System AI Realtor OS guide, page 08 / 16

## The problem

People save your market posts, watch every Story, and ask questions in comments, and you never turn that attention into a conversation list.

## Copy + paste prompt

```
Review my last 14 days on Instagram. List people who engaged more than once, what they engaged with, and whether they look local and real. Draft a DM for the top 5 that references the exact post. Separately, suggest 3 accounts to follow today and why each is strategic.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
