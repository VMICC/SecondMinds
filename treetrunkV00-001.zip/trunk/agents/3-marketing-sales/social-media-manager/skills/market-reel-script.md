# Script a 30-second local market update Reel

**Department:** Marketing  
**Specialist:** Social Media Manager  
**Version:** v1.4  
**Last updated:** 2026-10-18  
**Source path:** `marketing/social-media-manager/market-reel-script.md`

Create an engaging, non-boring short video script analyzing recent sales or market shifts.

## Required inputs

- Recent average price change or inventory stat
- Target city or neighborhood
- Key takeaway for buyers/sellers

## Instructions

### Hook Structure
- 0-3s: Disruptive hook
- 3-15s: 2 key market stats rendered in plain English
- 15-25s: What this means for local homeowners
- 25-30s: Direct CTA to comment or DM for full report

## Example request

> Write a 30-second Instagram Reel script explaining why inventory just jumped 12% in Westwood. Keep the tone warm and conversational using my Voice Guide.
