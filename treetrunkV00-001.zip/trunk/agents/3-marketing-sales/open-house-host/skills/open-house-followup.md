# Draft 24-hour open house guest follow-up texts & emails

**Department:** Sales & Follow-up  
**Specialist:** Open House Host  
**Version:** v1.0  
**Last updated:** 2026-10-08  
**Source path:** `sales/open-house-host/open-house-followup.md`

Send personalized, non-intrusive messages to guests who toured your open house.

## Required inputs

- Open house address & key property highlights
- Guest notes (e.g. looking for yard, working with lender)

## Instructions

Deliver 2 text templates (Hot guest vs Neighbor guest) plus 1 email recap template offering disclosures and disclosures packet.

## Example request

> Draft a 3-part text sequence to send open house visitors within 24 hours of touring 124 Oak Street.
