# Case 16: Open house follow-up: every sign-in gets a personal note within 24 hours

**Section:** C / Listings & Marketing (One input. Every version you need.)
**Owner:** `agents/3-marketing-sales/open-house-host/`
**You get:** Sorted list + per-person drafts + seller recap
**Channels:** SMS / Email
**Source:** System AI Realtor OS guide, page 10 / 16

## The problem

Sign-in sheets sit in your bag for three days. A generic 'thanks for coming' to 20 people converts nobody.

## Copy + paste prompt

```
From this open house sign-in sheet and my notes, sort visitors into unrepresented buyers, neighbors, and browsers. Draft a personal follow-up for each person using one detail they mentioned. Then draft my seller recap: traffic, top positive comments, top objections, and your recommended next move.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
