# Case 11: New movers in your farm: welcome them before anyone else does

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Weekly mover list + welcome & 60-day drafts
**Channels:** Notecard / Door drop
**Source:** System AI Realtor OS guide, page 08 / 16

## The problem

New homeowners in your farm need vendors, schools info, and a local agent to know, and the first agent to be useful usually becomes their agent.

## Copy + paste prompt

```
Build a weekly list of homes that closed in [farm] in the last 7 days where I was not the agent. Draft a welcome notecard for each: one local tip, one seasonal tip, and an offer to share my vendor list. No sales pitch. Also draft a 60-day check-in version.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
