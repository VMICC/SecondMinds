# Case 10: Spot the 'we have outgrown this house' posts in your own feed

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Early-signal list + two-stage drafts
**Channels:** Messenger / Comment
**Source:** System AI Realtor OS guide, page 07 / 16

## The problem

Your existing friends post the real signals (twins on the way, working from home in the kitchen, in-laws moving in) weeks before they ever search for an agent.

## Copy + paste prompt

```
Watch my friends feed for posts suggesting a housing change: outgrowing the house, new baby, work-from-home space, parents moving in, empty nest. Give me the link and a draft that responds to the life news only. Draft a housing follow-up separately, for me to use only if they bring up moving.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
