# Case 09: Daily expired listings, sorted by 'likely to relist'

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Ranked expired list + top-5 drafts
**Channels:** Letter / Email / Call opener
**Source:** System AI Realtor OS guide, page 07 / 16

## The problem

Expireds are public the same morning for every agent. Calling in MLS order wastes your best hour on homes that will never relist.

## Copy + paste prompt

```
Pull today's expired and cancelled listings in [farm]. Rank them by likelihood to relist and tell me why for each. For the top 5, draft an outreach that names one likely reason it did not sell and one concrete thing I would do differently. No criticism of the previous agent.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
