# Case 07: Scan local Facebook groups for 'I need an agent' posts

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Daily lead list with links + comment & DM drafts
**Channels:** Post comment / Messenger
**Source:** System AI Realtor OS guide, page 06 / 16

## The problem

Buyers and sellers ask for agent recommendations in neighborhood and mom groups every day. The first helpful comment usually gets the conversation.

## Copy + paste prompt

```
Scan [group names] daily for posts containing: looking for a realtor, recommend an agent, first-time buyer, thinking of selling, relocating, need more space. For each: link, poster name, what they need in one line, a draft comment that answers helpfully first, and a DM draft if they engage. Suggest the right lead magnet for each. Skip agent-to-agent posts.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
