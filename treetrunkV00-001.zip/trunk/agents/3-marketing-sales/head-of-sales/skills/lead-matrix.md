# Build a lead qualification matrix & scoring system

**Department:** Sales & Follow-up  
**Specialist:** Head of Sales  
**Version:** v1.0  
**Last updated:** 2026-10-01  
**Source path:** `sales/head-of-sales/lead-matrix.md`

Categorize incoming leads by motivation, timeline, and financing readiness to prioritize daily outreach.

## Required inputs

- Current lead channels (Zillow, Open House, Farming, Referrals)
- Average deal size
- Agent capacity per month

## Instructions

Categorize leads into Hot (0-30 days), Warm (30-90 days), and Nurture (90+ days). Define required follow-up frequency for each category.

## Example request

> Create a simple 3-tier lead scoring matrix for my team to categorize open house attendees and website leads.
