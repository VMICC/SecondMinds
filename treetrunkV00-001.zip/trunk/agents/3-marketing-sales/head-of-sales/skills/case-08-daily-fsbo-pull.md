# Case 08: Daily FSBO pull, with a first outreach that is not a script from 2011

**Section:** B / Find Sellers & Buyers Daily (Turn useful signals into thoughtful conversations.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Daily FSBO sheet + two drafts per listing
**Channels:** Messenger / SMS / Email
**Source:** System AI Realtor OS guide, page 06 / 16

## The problem

For-sale-by-owner listings appear across Zillow, Facebook Marketplace, and local groups. By the time you find them, three agents have already pitched them.

## Copy + paste prompt

```
Give me today's FSBOs in [farm / zip codes] from [sources]. For each: address, price, days on market, source link, and one specific, helpful observation about their listing. Draft a short first outreach using that observation and a separate follow-up for a price drop. Track who I have contacted.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
