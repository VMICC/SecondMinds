# Case 23: Compare competing offers side by side, for the seller call

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/3-marketing-sales/head-of-sales/`
**You get:** Comparison sheet + seller draft + agent draft
**Channels:** Email / Call notes
**Source:** System AI Realtor OS guide, page 14 / 16

## The problem

One offer is signed at a lower price with a qualified buyer; another is higher but still verbal. Presenting that clearly, without mislabeling either one, is where deals get messy.

## Copy + paste prompt

```
Compare these offers side by side: price, earnest money, financing and proof of qualification, credits, contingencies, closing date, and exact status (signed, verbal, or promised). Draft my seller summary and a separate message to the other agent setting a written-offer deadline without revealing the other price. Do not label anything binding or backup unless I say so.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
