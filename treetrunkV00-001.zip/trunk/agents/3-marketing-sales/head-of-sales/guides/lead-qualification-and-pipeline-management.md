# Lead Qualification and Pipeline Management Training Guide

## Head of Sales Assistant Training Guide: Lead Qualification and Pipeline Management Training Guide

Comprehensive Lead Assessment and Pipeline Optimization Mastery

### Training Guide Overview

This comprehensive training guide transforms AI assistants into world-class lead qualification specialists and pipeline management experts capable of implementing proven qualification methodologies, optimizing pipeline flow, and maximizing conversion rates through systematic lead assessment and pipeline optimization. This guide teaches specific qualification frameworks, detailed implementation processes, and advanced pipeline management techniques that drive predictable revenue generation.

#### Core Philosophy: Scientific Lead Assessment and Pipeline Excellence

Lead qualification is the foundation of sales efficiency and the key to predictable revenue generation. This guide provides detailed methodologies, proven frameworks, and tactical implementation guidance needed to build systematic qualification processes that identify high-probability opportunities, optimize resource allocation, and drive sustainable sales success.

### Section 1: Lead Qualification Methodologies and Frameworks

#### BANT Qualification Framework Implementation

BANT Framework Overview BANT (Budget, Authority, Need, Timeline) is a foundational qualification framework that assesses four critical dimensions of opportunity viability. While sometimes criticized as outdated, BANT remains valuable when properly implemented and adapted for modern selling.

Budget Qualification Methodology

Traditional Budget Questions (Avoid These):

"What's your budget for this project?" (Too direct, often ineffective)

"How much money do you have to spend?" (Creates defensive responses)

Modern Budget Discovery Techniques:

Value-Based Budget Exploration:

Cost of Inaction Approach:

"What's the cost of not solving this problem?"

"How much is this issue costing you monthly/annually?"

"What would happen if you don't address this in the next 6 months?"

Investment Perspective Method:

"How do you typically evaluate investments like this?"

"What kind of return would make this a no-brainer decision?"

"How do you measure success for initiatives like this?"

Range and Comparison Technique:

"Have you looked at solutions in this space before?"

"What range were you considering for addressing this challenge?"

"How does this compare to other investments you're making?"

Budget Qualification Scoring:

A-Level: Confirmed budget allocated, specific amount identified

B-Level: Budget range established, funding source identified

C-Level: Budget likely available, general parameters discussed

D-Level: No budget discussion, unclear funding situation

Authority Qualification Methodology

Decision-Making Process Mapping: Modern B2B decisions involve multiple stakeholders. Map the complete decision-making ecosystem:

Stakeholder Identification Framework:

Economic Buyer: Has budget authority and final decision power

Technical Buyer: Evaluates solution capabilities and fit

User Buyer: Will use the solution daily

Coach/Champion: Internal advocate supporting your solution

Influencer: Impacts decision but doesn't have final authority

Blocker: May oppose or obstruct the decision

Authority Discovery Questions:

"Walk me through how decisions like this typically get made here."

"Who else would be involved in evaluating a solution like this?"

"What's the approval process for investments of this size?"

"Who has the final say on moving forward?"

"What could prevent this decision from moving forward?"

Decision Process Validation:

"How have you made similar decisions in the past?"

"What's different about this decision process?"

"Who would need to sign off on this?"

"What approvals are required?"

Authority Qualification Scoring:

A-Level: Direct access to economic buyer, decision process mapped

B-Level: Champion identified, decision process understood

C-Level: Some stakeholders identified, process partially mapped

D-Level: Limited stakeholder access, unclear decision process

Need Qualification Methodology

Pain Discovery and Development Process: Use systematic questioning to uncover, develop, and amplify customer pain points:

Level 1 - Surface Pain Identification:

"What challenges are you facing with [current situation]?"

"What's working well, and what isn't?"

"What prompted you to look for a solution?"

"What would you change about your current approach?"

Level 2 - Pain Development and Quantification:

"How is this impacting your business/department/team?"

"What's the frequency and severity of these issues?"

"How much time/money/resources is this costing you?"

"Who else is affected by these problems?"

Level 3 - Pain Amplification and Urgency Creation:

"What happens if this problem isn't resolved?"

"How will this impact your goals for this year?"

"What's the cost of waiting another quarter/year?"

"What would solving this problem mean for your organization?"

Need Validation Techniques:

Implication Questions: "If this continues, what impact will it have on...?"

Consequence Exploration: "How does this affect your ability to...?"

Competitive Impact: "How does this put you at a disadvantage compared to...?"

Need Qualification Scoring:

A-Level: Critical business pain identified, quantified impact, urgency confirmed

B-Level: Significant pain identified, some quantification, moderate urgency

C-Level: Pain identified but not quantified, limited urgency

D-Level: Minimal pain or nice-to-have situation

Timeline Qualification Methodology

Timeline Discovery Framework: Understanding timeline involves more than asking "When do you want to implement?" It requires understanding driving factors and constraints.

Timeline Discovery Questions:

"What's driving the timing for this initiative?"

"What happens if you don't have a solution in place by [date]?"

"Are there any external factors influencing your timeline?"

"What other projects or initiatives could impact this timeline?"

"What would cause you to accelerate or delay this decision?"

Compelling Event Identification: Look for events that create urgency and drive decision-making:

Business Events: Fiscal year end, budget cycles, compliance deadlines

Competitive Events: Competitor actions, market changes, customer demands

Internal Events: Leadership changes, strategic initiatives, system upgrades

External Events: Regulatory changes, economic factors, industry trends

Timeline Validation Process:

"Help me understand the consequences of missing this timeline."

"What needs to happen between now and [target date]?"

"Who else needs to be involved in meeting this timeline?"

"What could cause delays in this timeline?"

Timeline Qualification Scoring:

A-Level: Compelling event identified, specific timeline with consequences

B-Level: Clear timeline with business rationale

C-Level: General timeline preference, limited urgency

D-Level: No specific timeline or compelling event

#### MEDDIC Qualification Framework Implementation

MEDDIC Framework Overview MEDDIC (Metrics, Economic Buyer, Decision Criteria, Decision Process, Identify Pain, Champion) is an advanced qualification methodology particularly effective for complex B2B sales.

Metrics Qualification Methodology

Quantified Value Discovery: MEDDIC requires specific, measurable outcomes that the customer expects from your solution.

Metrics Discovery Process:

Current State Measurement:

"How do you currently measure [relevant area]?"

"What are your current numbers for [specific metric]?"

"How does this compare to industry benchmarks?"

Future State Definition:

"What would success look like in measurable terms?"

"What improvement would make this investment worthwhile?"

"How would you measure the ROI of this solution?"

Success Criteria Establishment:

"What specific results would you need to see?"

"How would you know this solution is working?"

"What metrics would you track to measure success?"

Common Metrics Categories:

Financial: Revenue increase, cost reduction, ROI, payback period

Operational: Efficiency gains, time savings, error reduction

Strategic: Market share, competitive advantage, customer satisfaction

Compliance: Risk reduction, regulatory compliance, audit results

Economic Buyer Identification and Engagement

Economic Buyer Characteristics:

Has budget authority for the purchase decision

Can say "yes" when others can only say "no"

Owns the business problem you're solving

Will be held accountable for the solution's success

Economic Buyer Discovery Questions:

"Who owns the budget for this type of initiative?"

"Who would be held accountable if this problem isn't solved?"

"Who has the authority to approve this investment?"

"Who would need to sign the contract?"

Economic Buyer Engagement Strategies:

Value-Based Approach: Focus on business impact and strategic outcomes

Executive Summary: Provide high-level overview with key metrics

Risk Mitigation: Address potential concerns and implementation risks

Competitive Advantage: Highlight strategic benefits and market position

Decision Criteria Discovery and Influence

Decision Criteria Identification:

"What factors will you use to evaluate potential solutions?"

"How will you compare different vendors?"

"What's most important in your selection process?"

"What would cause you to choose one solution over another?"

Criteria Influence Strategies:

Criteria Development: Help customer develop comprehensive evaluation criteria

Weighting Influence: Guide relative importance of different criteria

Specification Setting: Influence technical and functional requirements

Proof Requirements: Shape how solutions will be evaluated and tested

Decision Process Mapping and Navigation

Process Discovery Questions:

"Walk me through your typical evaluation process."

"What steps are involved in making this decision?"

"Who's involved at each stage of the process?"

"What approvals are required?"

"How long do decisions like this typically take?"

Process Navigation Strategies:

Process Coaching: Guide customer through optimal decision process

Milestone Management: Establish clear next steps and timelines

Stakeholder Orchestration: Coordinate with all decision participants

Obstacle Anticipation: Identify and address potential roadblocks

Champion Development and Management

Champion Identification Criteria:

Has credibility and influence within the organization

Believes in your solution and its value

Has access to key stakeholders and decision makers

Is willing to advocate for your solution internally

Champion Development Process:

Value Alignment: Ensure champion understands and believes in solution value

Tool Provision: Provide resources and materials for internal selling

Coaching Support: Guide champion on internal navigation and messaging

Success Planning: Align champion's success with solution implementation

Champion Management Techniques:

Regular check-ins and relationship building

Providing competitive intelligence and market insights

Supporting champion's internal credibility and success

Creating mutual accountability and shared objectives

#### CHAMP Qualification Framework Implementation

CHAMP Framework Overview CHAMP (Challenges, Authority, Money, Prioritization) reorders traditional BANT to focus first on customer challenges, making it more consultative and customer-centric.

Challenges Discovery and Development

Challenge Identification Process:

Current State Analysis:

"What's your biggest challenge in [relevant area]?"

"What's keeping you up at night?"

"What would you change about your current situation?"

Impact Assessment:

"How is this challenge affecting your business?"

"What's the cost of not addressing this?"

"Who else is impacted by this challenge?"

Solution Visioning:

"What would the ideal solution look like?"

"How would you know this challenge is solved?"

"What would success mean for your organization?"

Challenge Development Techniques:

Problem Agitation: Help customer understand full impact of challenges

Consequence Exploration: Explore what happens if challenges aren't addressed

Opportunity Cost: Highlight missed opportunities due to current challenges

Prioritization Assessment and Influence

Priority Discovery Questions:

"How does solving this challenge rank among your priorities?"

"What other initiatives are competing for resources?"

"What would cause this to become a higher priority?"

"What could cause this to be deprioritized?"

Priority Influence Strategies:

Urgency Creation: Highlight time-sensitive factors and consequences

Competitive Pressure: Show how delays impact competitive position

Opportunity Cost: Demonstrate value of acting quickly

Risk Amplification: Emphasize risks of maintaining status quo

#### SPIN Selling Qualification Integration

SPIN Selling Methodology Overview SPIN Selling uses four types of questions to uncover needs and build value: Situation, Problem, Implication, and Need-Payoff questions.

Situation Questions Implementation

Purpose: Gather facts and understand current situation Usage Guidelines: Use sparingly, do research beforehand to minimize

Effective Situation Questions:

"Help me understand your current [process/system/approach]."

"How are you currently handling [relevant area]?"

"What does your current workflow look like?"

"Who's involved in [relevant process]?"

Situation Question Best Practices:

Research beforehand to minimize basic fact-finding

Use to confirm understanding rather than gather basic information

Transition quickly to problem questions

Focus on areas relevant to your solution

Problem Questions Implementation

Purpose: Identify problems, difficulties, and dissatisfactions Usage Guidelines: Uncover explicit needs and pain points

Effective Problem Questions:

"What challenges are you facing with [current situation]?"

"What aspects of [current process] are causing problems?"

"Where are you experiencing difficulties?"

"What's not working as well as you'd like?"

Problem Development Sequence:

Initial Problem Identification: Surface basic problems and challenges

Problem Exploration: Dig deeper into specific issues

Problem Quantification: Understand frequency, severity, and impact

Problem Validation: Confirm problems are worth solving

Implication Questions Implementation

Purpose: Develop problem consequences and create urgency Usage Guidelines: Most powerful question type for creating value

Effective Implication Questions:

"What happens if this problem isn't resolved?"

"How does this affect your ability to [achieve goals]?"

"What impact does this have on [other areas/people]?"

"How does this put you at a disadvantage?"

Implication Development Strategy:

Direct Consequences: Immediate impact of the problem

Indirect Effects: Secondary and tertiary consequences

Future Implications: Long-term impact if problem persists

Competitive Impact: How problem affects competitive position

Need-Payoff Questions Implementation

Purpose: Build value for your solution and gain commitment Usage Guidelines: Help customer articulate benefits of solving problems

Effective Need-Payoff Questions:

"What would it mean if you could solve this problem?"

"How would [solution benefit] help your organization?"

"What value would you get from [specific capability]?"

"How important would it be to achieve [desired outcome]?"

Need-Payoff Question Strategy:

Benefit Articulation: Help customer state solution benefits

Value Quantification: Guide customer to quantify solution value

Commitment Building: Increase customer investment in solution

Objection Prevention: Address concerns before they become objections

### Section 2: Advanced Qualification Techniques and Methodologies

#### Challenger Sale Qualification Approach

Teaching-Led Qualification The Challenger Sale approach uses teaching to uncover needs and create urgency through insight delivery.

Commercial Teaching Framework:

Lead with Insight: Share surprising, relevant insight about customer's business

Connect to Broader Challenge: Link insight to larger business challenge

Introduce Solution: Present your solution as response to challenge

Demonstrate Value: Show quantified impact of addressing challenge

Insight Development Process:

Industry Analysis: Research trends affecting customer's industry

Competitive Intelligence: Understand customer's competitive challenges

Best Practice Research: Identify leading practices in customer's space

Data Analysis: Find compelling statistics and benchmarks

Teaching Conversation Structure:

Hook: Attention-grabbing insight or statistic

Context: Broader industry or market trend

Challenge: Specific problem this creates for customer

Solution: How your offering addresses the challenge

Proof: Evidence and validation of solution effectiveness

#### Consultative Qualification Methodology

Consultative Discovery Process Consultative selling focuses on understanding customer needs before presenting solutions.

Discovery Planning Framework:

Pre-Call Research: Understand customer's business, industry, and challenges

Question Strategy: Plan question sequence and conversation flow

Hypothesis Development: Form preliminary hypotheses about customer needs

Validation Approach: Plan how to test and validate hypotheses

Consultative Question Hierarchy:

Business Questions: Understand overall business context and objectives

Situational Questions: Gather facts about current state and processes

Problem Questions: Identify challenges and pain points

Impact Questions: Understand consequences and implications

Vision Questions: Help customer envision improved future state

Need Development Conversation Flow:

Current State Assessment: Understand how things work today

Problem Identification: Uncover challenges and dissatisfactions

Impact Analysis: Explore consequences of problems

Future State Visioning: Help customer envision ideal solution

Gap Analysis: Identify differences between current and desired state

#### Value-Based Qualification Framework

Value Discovery Methodology Focus qualification on understanding and quantifying business value rather than just identifying needs.

Value Discovery Process:

Business Objective Alignment: Understand customer's strategic goals

Success Metrics Identification: Define how success will be measured

Current Performance Assessment: Establish baseline metrics

Improvement Opportunity Analysis: Identify areas for enhancement

Value Quantification: Calculate potential return on investment

Value Conversation Framework:

Strategic Alignment: "How does this initiative support your strategic objectives?"

Success Definition: "What would success look like in measurable terms?"

Current Performance: "What are your current metrics in this area?"

Improvement Potential: "What improvement would make this worthwhile?"

Investment Justification: "How do you typically evaluate ROI for initiatives like this?"

Value Quantification Techniques:

Cost Savings Analysis: Identify areas where solution reduces costs

Revenue Enhancement: Calculate potential revenue increases

Productivity Gains: Measure efficiency improvements and time savings

Risk Mitigation: Quantify value of reducing business risks

Competitive Advantage: Assess value of strategic positioning

### Section 3: Pipeline Management and Optimization

#### Pipeline Health Assessment and Monitoring

Pipeline Health Metrics Framework Establish comprehensive metrics to monitor pipeline quality and performance:

Volume Metrics:

Pipeline Coverage: Total pipeline value vs. quota (typically 3-5x coverage needed)

Stage Distribution: Percentage of opportunities in each stage

Velocity Trends: Rate of opportunity progression through stages

Conversion Rates: Stage-to-stage advancement percentages

Quality Metrics:

Qualification Score: Average qualification rating of opportunities

Deal Size Distribution: Mix of small, medium, and large opportunities

Win Rate by Stage: Probability of winning from each stage

Competitive Position: Strength vs. competitors in active deals

Pipeline Health Scoring System: Create weighted scoring based on multiple factors:

Volume Score (25%): Pipeline coverage and opportunity count

Quality Score (30%): Average qualification and deal size

Velocity Score (25%): Stage progression and cycle time

Conversion Score (20%): Win rates and advancement rates

Pipeline Health Dashboard:

Green (80-100%): Healthy pipeline with good coverage and quality

Yellow (60-79%): Adequate pipeline with some concerns

Red (Below 60%): Pipeline requires immediate attention and action

#### Opportunity Progression and Stage Management

Stage Advancement Criteria Establish specific, measurable criteria for advancing opportunities between stages:

Discovery to Qualification Stage:

Customer pain/need identified and documented

Basic BANT/MEDDIC qualification completed

Initial stakeholder contact established

Preliminary solution fit confirmed

Qualification to Proposal Stage:

Comprehensive needs analysis completed

Decision-making process mapped

Key stakeholders identified and engaged

Budget parameters established

Timeline and compelling event confirmed

Proposal to Negotiation Stage:

Formal proposal submitted and reviewed

Customer feedback received and addressed

Competitive position assessed and strengthened

Pricing and terms initially discussed

Negotiation to Closing Stage:

Terms and conditions agreed upon

Final approvals in process

Contract review completed

Implementation planning initiated

Stage Gate Review Process:

Opportunity Assessment: Review qualification criteria completion

Risk Analysis: Identify potential obstacles and mitigation strategies

Competitive Evaluation: Assess position vs. competitors

Resource Allocation: Determine appropriate investment level

Action Planning: Define next steps and timeline

#### Pipeline Forecasting and Predictive Analytics

Multi-Method Forecasting Approach Use multiple forecasting methods to improve accuracy and reliability:

Method 1: Stage-Based Forecasting

Apply historical conversion rates to current pipeline

Weight opportunities by stage probability

Account for seasonal variations and market factors

Include confidence intervals and ranges

Method 2: Opportunity-Based Forecasting

Assess individual opportunities using qualification criteria

Apply opportunity-specific probability ratings

Consider competitive position and relationship strength

Factor in deal-specific risks and accelerators

Method 3: Historical Trend Analysis

Analyze historical performance patterns

Identify seasonal trends and cyclical factors

Project future performance based on trends

Adjust for known market or business changes

Method 4: Bottom-Up Sales Rep Forecasting

Gather individual rep forecasts and assessments

Apply historical accuracy adjustments

Consider rep experience and track record

Validate against pipeline data and metrics

Forecast Accuracy Improvement Process:

Baseline Establishment: Measure current forecasting accuracy

Method Comparison: Test different forecasting approaches

Accuracy Tracking: Monitor forecast vs. actual performance

Method Refinement: Improve forecasting based on results

Continuous Improvement: Regularly update and optimize methods

#### Pipeline Optimization Strategies

Velocity Optimization Techniques Systematically improve pipeline velocity through targeted interventions:

Bottleneck Identification Process:

Stage Analysis: Identify stages with longest duration

Conversion Analysis: Find stages with lowest advancement rates

Activity Analysis: Assess effectiveness of stage-specific activities

Resource Analysis: Evaluate resource allocation and utilization

Velocity Improvement Strategies:

1. Process Optimization:

Eliminate unnecessary steps and activities

Streamline approval and decision processes

Improve handoffs between team members

Automate routine tasks and communications

2. Stakeholder Engagement:

Improve stakeholder identification and mapping

Enhance multi-threading and relationship building

Accelerate decision-maker engagement

Strengthen champion development and support

3. Value Communication:

Improve value proposition articulation

Enhance ROI and business case development

Strengthen competitive differentiation

Accelerate proof of concept and validation

4. Urgency Creation:

Identify and leverage compelling events

Create appropriate pressure and momentum

Highlight opportunity costs and risks

Implement scarcity and time-limited offers

Pipeline Quality Improvement Framework:

Lead Quality Enhancement:

Improve lead generation and sourcing

Enhance qualification criteria and processes

Implement lead scoring and prioritization

Strengthen marketing and sales alignment

Opportunity Development:

Improve needs analysis and discovery

Enhance solution development and customization

Strengthen proposal quality and presentation

Improve competitive positioning and differentiation

Relationship Building:

Enhance stakeholder engagement strategies

Improve champion development and management

Strengthen customer relationship management

Implement systematic follow-up and nurturing

### Section 4: Advanced Pipeline Analytics and Optimization

#### Predictive Pipeline Analytics

Machine Learning Applications for Pipeline Management Leverage advanced analytics to predict opportunity outcomes and optimize pipeline performance:

Opportunity Scoring Models: Develop predictive models using historical data and opportunity characteristics:

Input Variables:

Qualification Data: BANT/MEDDIC scores and completion

Engagement Metrics: Email opens, meeting attendance, response rates

Behavioral Indicators: Website activity, content consumption, referrals

Firmographic Data: Company size, industry, growth rate

Relationship Strength: Stakeholder engagement, champion presence

Scoring Algorithm Development:

Data Collection: Gather historical opportunity and outcome data

Feature Engineering: Identify predictive variables and relationships

Model Training: Use machine learning to develop scoring algorithms

Validation Testing: Test model accuracy on historical data

Implementation: Deploy model for real-time opportunity scoring

Predictive Analytics Applications:

Win Probability Prediction: Forecast likelihood of opportunity success

Deal Size Prediction: Estimate final deal value and terms

Timeline Prediction: Forecast deal closure timing

Risk Assessment: Identify opportunities at risk of stalling or loss

#### Advanced Forecasting Methodologies

Monte Carlo Simulation for Pipeline Forecasting Use statistical simulation to improve forecasting accuracy and understand uncertainty:

Simulation Process:

Variable Definition: Identify key variables affecting pipeline outcomes

Distribution Modeling: Define probability distributions for each variable

Simulation Execution: Run thousands of scenarios with random variable values

Result Analysis: Analyze distribution of outcomes and confidence intervals

Decision Support: Use results to inform resource allocation and planning

Scenario Planning and Sensitivity Analysis:

Best Case Scenario: Optimistic assumptions and favorable conditions

Most Likely Scenario: Realistic assumptions based on historical performance

Worst Case Scenario: Conservative assumptions and challenging conditions

Sensitivity Analysis: Understand impact of changing key variables

Time Series Forecasting for Pipeline Trends: Use historical pipeline data to predict future performance:

Trend Analysis Components:

Seasonal Patterns: Identify recurring seasonal variations

Cyclical Trends: Understand longer-term business cycles

Growth Trends: Analyze underlying growth or decline patterns

External Factors: Account for market and economic influences

#### Continuous Improvement and Optimization

A/B Testing for Pipeline Optimization Systematically test and improve pipeline management approaches:

Testing Framework:

Hypothesis Development: Form specific hypotheses about improvements

Test Design: Create controlled experiments with clear success metrics

Implementation: Execute tests with proper controls and measurement

Analysis: Evaluate results and statistical significance

Implementation: Roll out successful improvements organization-wide

Common A/B Testing Applications:

Qualification Criteria: Test different qualification frameworks

Stage Definitions: Compare alternative pipeline stage structures

Forecasting Methods: Test different forecasting approaches

Communication Strategies: Evaluate different customer engagement methods

Performance Benchmarking and Best Practice Development:

Internal Benchmarking: Compare performance across teams and individuals

External Benchmarking: Compare against industry standards and competitors

Best Practice Identification: Identify and document high-performance approaches

Knowledge Sharing: Disseminate best practices across organization

This comprehensive guide provides the detailed methodologies, specific qualification frameworks, and step-by-step implementation processes needed to build world-class lead qualification and pipeline management capabilities. Unlike high-level frameworks, this guide teaches proven methodologies that enable practical application and measurable results.
