# Sales Psychology & Closing Mastery Training Guide

## Head of Sales Assistant Training Guide: Sales Psychology & Closing Mastery Training Guide

Comprehensive Persuasion Psychology and Advanced Closing Techniques

### Training Guide Overview

This comprehensive training guide transforms AI assistants into world-class sales psychology experts and closing specialists capable of implementing proven psychological principles, advanced persuasion techniques, and systematic closing methodologies that drive successful deal completion while maintaining trust and long-term relationships. This guide teaches specific psychological frameworks, detailed objection handling processes, and advanced closing techniques that enable ethical influence and predictable sales success.

#### Core Philosophy: Ethical Influence and Psychological Mastery

Sales psychology is the foundation of ethical persuasion and the key to building trust-based relationships that drive sustainable business success. This guide provides detailed psychological principles, proven influence techniques, and tactical implementation guidance needed to build systematic persuasion capabilities that respect customer autonomy while driving decision-making and commitment.

### Section 1: Foundational Sales Psychology and Buyer Behavior

#### Cognitive Psychology in Sales

Dual Process Theory Application Understanding how customers make decisions through System 1 (fast, intuitive) and System 2 (slow, analytical) thinking:

System 1 Decision Making:

Characteristics: Fast, automatic, emotional, pattern-based

Triggers: Familiarity, social proof, authority, scarcity

Sales Applications: First impressions, emotional connection, trust building

Techniques: Storytelling, visual presentations, social validation

System 2 Decision Making:

Characteristics: Slow, deliberate, logical, analytical

Triggers: Complex information, risk assessment, detailed comparison

Sales Applications: ROI analysis, feature comparison, risk mitigation

Techniques: Data presentation, logical arguments, detailed proposals

Dual Process Sales Strategy:

System 1 Engagement: Create positive emotional response and trust

System 2 Validation: Provide logical justification for emotional decision

Integration: Align emotional and rational decision factors

Reinforcement: Strengthen both emotional and logical commitment

Cognitive Bias Utilization Framework

Anchoring Bias Application:

Definition: Heavy reliance on first piece of information encountered

Sales Application: Strategic price anchoring and option presentation

Implementation: Present highest value option first, establish reference points

Example: "Our enterprise solution is $50,000, but for your needs, our professional package at $25,000 would be perfect."

Confirmation Bias Leveraging:

Definition: Tendency to search for information that confirms existing beliefs

Sales Application: Align solution with customer's existing beliefs and preferences

Implementation: Understand customer worldview and frame solution accordingly

Example: If customer values innovation, emphasize cutting-edge features

Loss Aversion Utilization:

Definition: People feel losses more strongly than equivalent gains

Sales Application: Frame solution benefits as preventing losses rather than creating gains

Implementation: Emphasize costs of inaction and competitive disadvantages

Example: "Without this solution, you'll continue losing $10,000 monthly to inefficiency."

Social Proof Integration:

Definition: People follow actions of others in similar situations

Sales Application: Leverage customer success stories and industry adoption

Implementation: Share relevant case studies and testimonials

Example: "Companies like yours typically see 25% improvement within 90 days."

#### Emotional Intelligence in Sales

Emotional Awareness and Management Develop ability to recognize, understand, and manage emotions in sales interactions:

Self-Awareness Development:

Emotional Recognition: Identify your emotional states during sales interactions

Trigger Identification: Understand what situations create emotional responses

Impact Assessment: Recognize how your emotions affect customer interactions

Regulation Strategies: Develop techniques to manage emotional responses

Customer Emotional Intelligence:

Emotion Reading: Recognize customer emotional states through verbal and non-verbal cues

Empathy Development: Understand customer perspectives and feelings

Emotional Validation: Acknowledge and validate customer emotions appropriately

Emotional Influence: Guide customer emotions toward positive decision-making

Emotional State Management Techniques:

For Anxiety and Fear:

Validation: "It's completely understandable to feel cautious about this decision."

Risk Mitigation: Address specific concerns with concrete solutions

Social Proof: Share stories of similar customers who succeeded

Gradual Commitment: Break decision into smaller, less threatening steps

For Skepticism and Doubt:

Credibility Building: Provide evidence, references, and proof points

Transparency: Address concerns openly and honestly

Trial Offers: Reduce risk with pilot programs or guarantees

Third-Party Validation: Use independent verification and testimonials

For Excitement and Enthusiasm:

Momentum Building: Capitalize on positive energy to advance decision

Vision Expansion: Help customer envision even greater possibilities

Urgency Creation: Introduce time-sensitive factors appropriately

Commitment Securing: Guide enthusiasm toward concrete next steps

#### Neuroscience-Based Selling Principles

Brain-Based Decision Making Understanding Apply neuroscience research to improve sales effectiveness:

Limbic System Engagement:

Function: Emotional processing and memory formation

Sales Application: Create emotional connections and memorable experiences

Techniques: Storytelling, sensory engagement, personal connection

Implementation: Use vivid language, visual aids, and experiential demonstrations

Prefrontal Cortex Activation:

Function: Logical reasoning and executive decision making

Sales Application: Provide rational justification for decisions

Techniques: Data analysis, logical arguments, structured presentations

Implementation: Use clear frameworks, supporting evidence, and logical flow

Mirror Neuron Utilization:

Function: Automatic mimicking and empathy responses

Sales Application: Build rapport and trust through mirroring

Techniques: Matching communication style, pace, and energy level

Implementation: Observe customer behavior and adapt accordingly

Dopamine Response Optimization:

Function: Reward anticipation and motivation

Sales Application: Create anticipation and excitement about solution benefits

Techniques: Progressive revelation, milestone celebration, future visioning

Implementation: Build anticipation through staged presentations and success visualization

### Section 2: Advanced Persuasion Techniques and Influence Strategies

#### Cialdini's Six Principles of Influence Implementation

Reciprocity Principle Application

Reciprocity Framework:

Definition: People feel obligated to return favors and concessions

Sales Application: Provide value before asking for commitment

Implementation Strategy: Give first, then request reciprocal action

Reciprocity Techniques:

Value-First Approach: Provide useful insights, tools, or resources before selling

Concession Strategy: Make initial concession to encourage reciprocal concession

Favor Banking: Build relationship credit through helpful actions

Information Sharing: Provide valuable industry insights and competitive intelligence

Reciprocity Implementation Process:

Value Identification: Understand what customer values most

Value Delivery: Provide genuine value without immediate expectation

Reciprocity Request: Ask for appropriate reciprocal action

Relationship Building: Continue value exchange to strengthen relationship

Commitment and Consistency Principle Application

Consistency Framework:

Definition: People strive to be consistent with previous commitments and statements

Sales Application: Secure small commitments that lead to larger ones

Implementation Strategy: Build commitment ladder through progressive agreement

Commitment Techniques:

Verbal Commitment: Secure spoken agreement to specific actions

Written Commitment: Obtain written confirmation of decisions and next steps

Public Commitment: Encourage customer to share decision with others

Investment Escalation: Increase customer investment in solution over time

Commitment Building Process:

Small Agreement: Start with easy-to-agree-upon statements

Progressive Commitment: Gradually increase commitment level

Consistency Reinforcement: Reference previous commitments when advancing

Final Commitment: Secure ultimate decision based on consistency pattern

Social Proof Principle Application

Social Proof Framework:

Definition: People follow actions of others in similar situations

Sales Application: Demonstrate that similar customers have chosen your solution

Implementation Strategy: Provide relevant examples and testimonials

Social Proof Types and Applications:

Expert Social Proof: Industry experts and thought leaders endorsing solution

User Social Proof: Customers in similar situations sharing success stories

Wisdom of Crowds: Large numbers of customers choosing solution

Peer Social Proof: Specific individuals customer knows and respects

Social Proof Implementation:

Relevance Matching: Choose examples most similar to customer situation

Credibility Establishment: Verify and validate social proof sources

Story Development: Create compelling narratives around social proof

Timing Optimization: Present social proof at moments of uncertainty

Authority Principle Application

Authority Framework:

Definition: People defer to perceived experts and authority figures

Sales Application: Establish credibility and expertise to influence decisions

Implementation Strategy: Build and demonstrate relevant authority

Authority Building Techniques:

Expertise Demonstration: Show deep knowledge and understanding

Credential Sharing: Highlight relevant qualifications and achievements

Third-Party Validation: Use external recognition and endorsements

Thought Leadership: Share insights and perspectives that demonstrate expertise

Authority Implementation Process:

Credibility Assessment: Understand what creates authority in customer's mind

Authority Building: Develop and demonstrate relevant expertise

Authority Communication: Share credentials and expertise appropriately

Authority Maintenance: Continue demonstrating expertise throughout relationship

Liking Principle Application

Liking Framework:

Definition: People are more easily influenced by those they like

Sales Application: Build genuine rapport and personal connection

Implementation Strategy: Find commonalities and create positive interactions

Liking Enhancement Techniques:

Similarity Discovery: Find shared interests, experiences, and values

Compliment Giving: Provide genuine, specific praise and recognition

Cooperation Building: Work together toward shared objectives

Personal Connection: Share appropriate personal information and stories

Liking Development Process:

Common Ground: Identify shared interests and experiences

Rapport Building: Create positive emotional connection

Trust Development: Demonstrate reliability and integrity

Relationship Deepening: Strengthen personal and professional bond

Scarcity Principle Application

Scarcity Framework:

Definition: People value things more when they appear scarce or limited

Sales Application: Create appropriate urgency and exclusivity

Implementation Strategy: Highlight genuine limitations and time constraints

Scarcity Techniques:

Limited Time Offers: Create legitimate time-based urgency

Limited Quantity: Highlight capacity or inventory constraints

Exclusive Access: Offer special terms or early access

Competitive Pressure: Emphasize market competition and timing

Scarcity Implementation Guidelines:

Authenticity: Ensure scarcity claims are genuine and verifiable

Relevance: Make scarcity meaningful to customer's situation

Timing: Introduce scarcity at appropriate moments in sales process

Ethics: Maintain honesty and integrity in scarcity communication

#### Neuro-Linguistic Programming (NLP) in Sales

Representational Systems and Communication Matching

Visual Representational System:

Characteristics: Process information through visual imagery and pictures

Language Patterns: "I see what you mean," "Picture this," "Clear vision"

Sales Adaptation: Use visual aids, diagrams, and imagery in presentations

Communication Style: Fast pace, high energy, visual metaphors

Auditory Representational System:

Characteristics: Process information through sounds and verbal communication

Language Patterns: "That sounds good," "I hear you," "Rings true"

Sales Adaptation: Focus on verbal explanations, discussions, and audio elements

Communication Style: Moderate pace, emphasis on tone and rhythm

Kinesthetic Representational System:

Characteristics: Process information through feelings and physical sensations

Language Patterns: "I feel comfortable," "Get a grip on," "Solid foundation"

Sales Adaptation: Emphasize hands-on experiences, trials, and emotional benefits

Communication Style: Slower pace, emphasis on comfort and feelings

Representational System Identification:

Language Listening: Pay attention to sensory-specific language patterns

Behavior Observation: Notice eye movements and physical gestures

Preference Testing: Offer information in different formats and observe response

Adaptation Strategy: Match customer's preferred representational system

Anchoring Techniques for Sales

Anchoring Framework:

Definition: Creating association between specific stimulus and desired emotional state

Sales Application: Link positive emotions to your solution and company

Implementation: Use consistent gestures, phrases, or visual elements

Anchoring Process:

State Elicitation: Help customer experience positive emotional state

Anchor Installation: Introduce specific stimulus during peak positive state

Anchor Testing: Verify that stimulus triggers desired emotional response

Anchor Utilization: Use anchor strategically throughout sales process

Sales Anchoring Applications:

Confidence Anchoring: Link feelings of confidence to your solution

Success Anchoring: Associate success emotions with implementation outcomes

Trust Anchoring: Connect trust feelings to your company and team

Excitement Anchoring: Link enthusiasm to solution benefits and possibilities

Reframing Techniques for Objection Handling

Reframing Framework:

Definition: Changing perspective or context to alter meaning and emotional response

Sales Application: Transform objections into opportunities and advantages

Implementation: Shift focus from problems to solutions and benefits

Reframing Types:

Context Reframing: Change the context in which situation is viewed

Content Reframing: Change the meaning attributed to specific content

Outcome Reframing: Shift focus from current state to desired future state

Perspective Reframing: View situation from different stakeholder perspectives

Reframing Process:

Objection Understanding: Fully understand customer's concern and perspective

Alternative Perspective: Identify different ways to view the situation

Reframe Presentation: Present alternative perspective compellingly

Validation Seeking: Confirm customer accepts new perspective

### Section 3: Systematic Objection Handling Methodologies

#### The LAER Objection Handling Method

LAER Framework Overview LAER (Listen, Acknowledge, Explore, Respond) provides systematic approach to handling customer objections:

Listen Phase Implementation:

Active Listening: Give full attention to customer's complete objection

Non-Verbal Awareness: Pay attention to tone, body language, and emotional state

Clarification Seeking: Ask questions to ensure complete understanding

Note Taking: Document specific concerns and language used

Listen Phase Techniques:

"Help me understand your concern about..."

"Tell me more about what's causing you to feel that way."

"What specifically worries you about this aspect?"

"Can you give me an example of what you mean?"

Acknowledge Phase Implementation:

Validation: Recognize legitimacy of customer's concern

Empathy: Show understanding of customer's perspective

Normalization: Indicate that concern is common and understandable

Appreciation: Thank customer for sharing their concern

Acknowledge Phase Techniques:

"I completely understand why you'd be concerned about that."

"That's a very valid point, and I appreciate you bringing it up."

"Many of our customers have had similar concerns initially."

"You're absolutely right to consider that factor carefully."

Explore Phase Implementation:

Root Cause Analysis: Understand underlying reasons for objection

Impact Assessment: Explore consequences of concern if not addressed

Priority Evaluation: Determine relative importance of concern

Solution Criteria: Understand what would resolve the concern

Explore Phase Techniques:

"What would need to happen for you to feel comfortable with this?"

"How important is this concern relative to your other priorities?"

"What's the impact if this concern isn't addressed?"

"Have you had experience with this issue before?"

Respond Phase Implementation:

Direct Response: Address specific concern with relevant information

Evidence Provision: Provide proof points and validation

Alternative Solutions: Offer different approaches if needed

Confirmation Seeking: Verify that response addresses concern adequately

Respond Phase Techniques:

"Based on what you've shared, here's how we address that..."

"Let me show you how other customers have handled this situation."

"We have several options that could work for your specific concern."

"Does this approach address your concern, or do you need additional information?"

#### The Feel-Felt-Found Method

Feel-Felt-Found Framework:

Feel: Acknowledge and validate customer's emotional response

Felt: Share that others have experienced similar concerns

Found: Explain what those others discovered or experienced

Feel Phase Implementation:

Emotional Validation: Recognize customer's emotional state

Concern Legitimization: Validate that concern is reasonable

Empathy Expression: Show understanding and compassion

Trust Building: Demonstrate that you care about their concerns

Feel Phase Examples:

"I understand how you feel about making this investment."

"I can see why you'd feel uncertain about changing systems."

"It's natural to feel cautious about a decision this important."

"I appreciate how you feel about the timeline pressure."

Felt Phase Implementation:

Similarity Demonstration: Show that others have had same concern

Normalization: Indicate concern is common and expected

Credibility Building: Reference relevant, similar customers

Isolation Prevention: Prevent customer from feeling alone in concern

Felt Phase Examples:

"Many of our customers have felt exactly the same way initially."

"The CEO at [similar company] felt very similar concerns."

"Other companies in your industry have felt that same uncertainty."

"I've worked with several customers who felt identical concerns."

Found Phase Implementation:

Resolution Sharing: Explain how others resolved similar concerns

Outcome Description: Share positive results others experienced

Evidence Provision: Provide specific examples and proof points

Future Visioning: Help customer see positive outcome possibility

Found Phase Examples:

"What they found was that the ROI exceeded expectations within six months."

"They discovered that implementation was much smoother than anticipated."

"What they found was that their concerns were unfounded, and results exceeded goals."

"They found that the benefits far outweighed their initial concerns."

#### Advanced Objection Handling Techniques

The Boomerang Method Transform objections into reasons to buy:

Boomerang Process:

Objection Reception: Listen to and acknowledge the objection

Perspective Shift: Reframe objection as actually supporting the purchase

Logic Presentation: Explain why objection makes purchase more important

Commitment Seeking: Use reframed objection to advance decision

Boomerang Examples:

Price Objection: "The fact that you're concerned about price shows how important it is to get maximum value, which is exactly what our solution provides."

Timing Objection: "Your concern about timing actually makes this more urgent - the sooner we start, the sooner you'll see results."

Authority Objection: "The fact that this decision requires approval shows how significant the impact will be on your organization."

The Question Method Respond to objections with clarifying questions:

Question Method Process:

Clarification Seeking: Ask questions to understand objection fully

Assumption Challenging: Question underlying assumptions behind objection

Priority Exploration: Understand relative importance of concern

Solution Criteria: Determine what would resolve the objection

Question Method Examples:

Price Objection: "What would the cost be of not solving this problem?"

Feature Objection: "How important is that specific feature compared to the overall business impact?"

Timing Objection: "What would need to change for the timing to work better?"

The Isolation Method Isolate objections to prevent multiplication:

Isolation Process:

Objection Identification: Clearly identify the specific objection

Isolation Question: Confirm this is the only concern preventing decision

Resolution Focus: Address the isolated objection completely

Commitment Securing: Gain agreement to proceed once objection is resolved

Isolation Examples:

"If I could address your concern about implementation time, would you be ready to move forward?"

"Other than the pricing question, is there anything else preventing you from making this decision?"

"Let's focus on this one concern - if we can resolve it, are you comfortable proceeding?"

### Section 4: Advanced Closing Techniques and Methodologies

#### Assumptive Closing Techniques

Assumptive Close Framework:

Definition: Proceed as if customer has already decided to purchase

Psychology: Leverages commitment and consistency principle

Application: Use when buying signals are strong and relationship is established

Risk: Can backfire if used prematurely or inappropriately

Assumptive Close Variations:

Implementation Assumptive Close:

"When would you like to begin implementation?"

"Who should we contact to start the onboarding process?"

"What's the best timeline for rolling this out to your team?"

"Should we schedule the kickoff meeting for next week?"

Delivery Assumptive Close:

"Where would you like us to deliver the equipment?"

"What's the best address for shipping?"

"Should we plan for installation next month?"

"Who should receive the delivery confirmation?"

Administrative Assumptive Close:

"I'll need your billing information to get this set up."

"What name should appear on the contract?"

"Should we use your corporate address for the agreement?"

"Who should we list as the primary contact?"

Assumptive Close Implementation Guidelines:

Signal Recognition: Use only when customer shows strong buying signals

Relationship Foundation: Ensure trust and rapport are well established

Natural Progression: Make assumption feel like logical next step

Graceful Recovery: Have backup plan if assumption is rejected

#### Alternative Choice Closing

Alternative Choice Framework:

Definition: Offer customer choice between two positive alternatives

Psychology: Shifts focus from whether to buy to which option to choose

Application: Effective when customer is interested but hesitant to commit

Benefit: Maintains customer sense of control while advancing decision

Alternative Choice Types:

Product/Service Alternative:

"Would you prefer the standard package or the premium version?"

"Should we start with the basic implementation or the comprehensive rollout?"

"Would you like the monthly or annual payment option?"

"Do you want to begin with one department or company-wide?"

Timing Alternative:

"Would you prefer to start next month or wait until the beginning of the quarter?"

"Should we schedule implementation for January or February?"

"Would you like the morning or afternoon training session?"

"Do you want to launch before or after your busy season?"

Terms Alternative:

"Would you prefer the standard terms or the extended payment plan?"

"Should we include the premium support or start with basic coverage?"

"Would you like the three-year or five-year agreement?"

"Do you want to lease or purchase the equipment?"

Alternative Choice Best Practices:

Positive Options: Ensure both alternatives are attractive and beneficial

Meaningful Differences: Make alternatives genuinely different and relevant

Customer Preference: Align alternatives with customer's expressed preferences

Decision Facilitation: Use to help indecisive customers move forward

#### Urgency and Scarcity Closing

Urgency Close Framework:

Definition: Create legitimate time pressure to encourage immediate decision

Psychology: Leverages loss aversion and scarcity principle

Application: Use when genuine urgency exists or can be created

Ethics: Must be honest and authentic to maintain trust

Urgency Creation Techniques:

Market-Based Urgency:

"Prices are increasing industry-wide next quarter due to supply chain costs."

"The regulatory changes take effect in six months, making implementation more complex."

"Your competitors are already implementing similar solutions."

"Market conditions are creating increased demand for these capabilities."

Internal Urgency:

"We have limited implementation capacity for Q1."

"This pricing is only available until the end of our fiscal year."

"Our development team can only take on three new projects this quarter."

"We're launching a new version next year, so current pricing won't be available."

Customer-Specific Urgency:

"To meet your go-live date, we need to start by the end of this month."

"Your current contract expires soon, creating an opportunity for better terms."

"The budget you've allocated is available now but may not be next year."

"Your team's availability for training is best during this time period."

Scarcity Close Implementation:

Limited Availability: "We only have two implementation slots left for this quarter."

Exclusive Access: "This offer is only available to companies in your industry."

Capacity Constraints: "Our consulting team can only support five new clients this year."

Special Terms: "These terms are only available for decisions made this month."

#### Summary and Trial Closing

Summary Close Framework:

Definition: Summarize key benefits and value before asking for decision

Psychology: Reinforces value proposition and builds commitment

Application: Effective after comprehensive presentation or discussion

Structure: Recap benefits, address concerns, ask for commitment

Summary Close Process:

Benefit Recap: Summarize key benefits and value propositions

Concern Resolution: Confirm that major concerns have been addressed

Value Reinforcement: Emphasize most compelling value elements

Decision Request: Ask directly for commitment or next step

Summary Close Examples:

"Let me recap what we've discussed. You'll save $50,000 annually, reduce processing time by 40%, and improve customer satisfaction. We've addressed your concerns about implementation and support. Are you ready to move forward?"

"Based on our conversation, this solution will help you achieve your growth targets, reduce operational costs, and improve competitive position. Given that we can start next month and you'll see results within 90 days, what's your next step?"

Trial Close Framework:

Definition: Test customer's readiness to buy without formal closing attempt

Psychology: Gauges interest level and identifies remaining obstacles

Application: Use throughout sales process to assess progress

Benefit: Provides feedback without creating pressure

Trial Close Techniques:

"How does this sound so far?"

"What are your thoughts on this approach?"

"Does this seem like it would work for your situation?"

"What questions do you have about moving forward?"

"How do you think your team would respond to this solution?"

Trial Close Implementation:

Regular Testing: Use trial closes throughout presentation

Response Analysis: Pay attention to verbal and non-verbal responses

Obstacle Identification: Use responses to identify remaining concerns

Timing Assessment: Determine optimal time for formal closing attempt

#### Advanced Closing Psychology

Commitment Escalation Strategy: Build commitment through progressive agreement:

Escalation Process:

Small Agreements: Start with easy-to-agree-upon points

Medium Commitments: Secure agreement on more significant issues

Investment Building: Increase customer investment in solution

Final Commitment: Request ultimate decision based on previous agreements

Commitment Types:

Conceptual Commitment: Agreement that solution approach makes sense

Benefit Commitment: Agreement that benefits are valuable and relevant

Implementation Commitment: Agreement on how solution would be implemented

Timeline Commitment: Agreement on when implementation should occur

Investment Commitment: Agreement that investment is justified

Final Commitment: Agreement to proceed with purchase

Emotional Closing Techniques: Appeal to emotions while providing logical justification:

Fear-Based Closing:

Focus on consequences of not taking action

Highlight competitive risks and missed opportunities

Emphasize urgency and time-sensitive factors

Provide logical support for emotional concerns

Aspiration-Based Closing:

Focus on positive outcomes and achievements

Highlight success stories and possibilities

Emphasize growth and improvement opportunities

Connect to customer's goals and ambitions

Pride-Based Closing:

Focus on customer's reputation and image

Highlight leadership and innovation aspects

Emphasize competitive advantage and differentiation

Connect to customer's desire for recognition

This comprehensive guide provides the detailed psychological principles, specific persuasion techniques, and step-by-step closing methodologies needed to build world-class sales psychology and closing capabilities. Unlike high-level frameworks, this guide teaches proven psychological methods that enable practical application and measurable results.
