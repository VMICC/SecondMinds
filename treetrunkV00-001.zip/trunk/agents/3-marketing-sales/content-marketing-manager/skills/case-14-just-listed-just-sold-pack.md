# Case 14: Just Listed / Just Sold pack: every asset from one listing

**Section:** C / Listings & Marketing (One input. Every version you need.)
**Owner:** `agents/3-marketing-sales/content-marketing-manager/`
**You get:** 5 assets + checklist per listing
**Channels:** Social / Email / Postcard / Letter
**Source:** System AI Realtor OS guide, page 09 / 16

## The problem

One listing needs a post, a Story, an email, a postcard, and a neighbor letter, so half of them never get made.

## Copy + paste prompt

```
From this listing, build the full pack: Facebook post, Instagram caption and Story text, sphere email, postcard copy (front and back), and a neighbor letter. Keep my voice, use only verified facts, and give me a posting checklist with the order and timing.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
