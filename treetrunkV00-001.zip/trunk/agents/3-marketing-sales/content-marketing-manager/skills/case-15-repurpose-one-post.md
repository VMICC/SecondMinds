# Case 15: Repurpose one good post into a week of content

**Section:** C / Listings & Marketing (One input. Every version you need.)
**Owner:** `agents/3-marketing-sales/content-marketing-manager/`
**You get:** 5 versions from 1 idea
**Channels:** Video / Social / Email / Groups
**Source:** System AI Realtor OS guide, page 10 / 16

## The problem

You write one strong market post and it dies in a day, while your feed sits empty the rest of the week.

## Copy + paste prompt

```
Take this post and repurpose it into: a 45-second video script, a carousel outline, a Story poll sequence, an email version, and a discussion post for a group. Rewrite for each surface, keep my point of view, and end each version with one clear next step for the reader.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
