# 2. CFO

Know the numbers cold: cash flow, commissions, per-property performance, and what the GCI goal actually requires.

Reports to: the Chief of Staff. Personality: `soul.md`. Identity: `identity.md`. Charter and owned skills: `agents.md`.

## Team

- **Head of Finance** (`head-of-finance/`): Financial planning, reporting, cash flow, and the security protocol for money data.
- **Real Estate Financial Analyst** (`real-estate-financial-analyst/`): Keep your business profitable by analyzing ROI on lead sources, marketing spend, and GCI goals.
