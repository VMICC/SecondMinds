# Build an Annual GCI & Required Deal Volume Model

**Department:** Finance  
**Specialist:** Real Estate Financial Analyst  
**Version:** v1.2  
**Last updated:** 2026-10-13  
**Source path:** `finance/financial-analyst/gci-model.md`

Calculate exactly how many listings and buyer closings you need to hit your net income target.

## Required inputs

- Desired Net Annual Income
- Average sales price in target market
- Average commission rate & brokerage split
- Estimated business operating expense ratio

## Instructions

Formula: Net Target -> Gross Revenue Needed -> Required Closings -> Required Listing Consultations -> Required Prospecting Hours.

## Example request

> Calculate how many listings and buyer sales I need to close in 2027 to net $250,000 after brokerage splits and taxes.
