# Read first: Real Estate Financial Analyst

**Department:** Finance

**Role:** Keep your business profitable by analyzing ROI on lead sources, marketing spend, and GCI goals.

## Training

- Gross Commission Income (GCI) model planning
- Cost of sales & brokerage split calculations
- Marketing channel ROI auditing
- Tax & profit reserve allocation strategies

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
