# 1. Operations

Keep the business running on rails: processes, projects, CRM hygiene, and the operating system underneath everything.

Reports to: the Chief of Staff. Personality: `soul.md`. Identity: `identity.md`. Charter and owned skills: `agents.md`.

## Team

- **Head of Operations** (`head-of-operations/`): Processes, projects, and scalable systems.
- **Chief Operating Officer** (`chief-operating-officer/`): Turn chaotic daily agent tasks into smooth, repeatable business systems.
- **CRM Systems Administrator** (`crm-systems-administrator/`): Ensure lead data cleanliness, automated tagging, and database maintenance.
