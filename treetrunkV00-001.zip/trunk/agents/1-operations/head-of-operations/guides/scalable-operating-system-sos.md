# Scalable Operating System (sOS) Training Guide

## Head of Operations Assistant Training Guide: Scalable Operating System (sOS) Training Guide

For Head of Operations Assistant - ChatGPT Project Implementation

### Overview

This training guide provides comprehensive knowledge of the Scalable Operating System (sOS) methodology developed by Ryan Deiss and Richard Lindner, Co-Founders of The Scalable Company (Scalable.co). The sOS is a proven framework for building businesses that can scale without the founder becoming the bottleneck. As a Head of Operations Assistant, you will use this system to help companies in two primary scenarios:

Installing the sOS: First-time implementation and system setup

Running the company on the sOS: Ongoing operations and optimization of established systems

#### What You'll Learn

Core sOS principles and implementation methodology

Value Engine mapping and optimization (installation and ongoing management)

Company Scorecard system design and management

High-Output Team creation and management

Scalable Planning System execution

Meeting rhythm and decision-making frameworks

#### How to Use This Guide

Before providing assistance, always determine the company's current state:

Ask: "Are you installing the sOS for the first time or running a company that already operates on the sOS?"

Review company context files for existing Value Engines, scorecards, or sOS documentation

Adapt your guidance based on whether they need installation support or operational optimizations

### Section 1: sOS Foundation & Core Principles

#### The Three Components of Any Operating System

Every business operating system consists of three essential components:

##### 1. Algorithms (The Rules)

Definition: The documented processes, procedures, and policies that govern how work gets done

In Practice: Standard Operating Procedures (SOPs), checklists, company policies, workflow documentation

Your Role: Help teams document, optimize, and systematize their processes into repeatable algorithms

##### 2. Common Language (Communication System)

Definition: How different parts of the organization communicate and share information

In Practice: Meetings, scorecards, dashboards, communication tools, shared terminology

Your Role: Design and facilitate communication systems that ensure alignment and information flow

##### 3. Desired Outputs (Goals & Objectives)

Definition: The specific results and outcomes the business is working to achieve

In Practice: Revenue targets, KPIs, strategic objectives, quarterly goals

Your Role: Help translate high-level goals into measurable, trackable outcomes

#### Core sOS Principles

##### Manual Over Automated

Principle: Manual data entry and tracking creates deeper insights than automated systems

Why: Forces human interaction with data, leading to pattern recognition and contextual understanding

Application: Design scorecard systems that require manual weekly input rather than automated dashboards

##### Subjective Over Objective

Principle: Human judgment in interpreting data is more valuable than algorithmic analysis

Why: Humans can factor in context, nuance, and situational factors that algorithms miss

Application: Use color-coding systems where team members make judgment calls on performance status

##### Ownership Mindset

Principle: When people manually interact with their metrics, they take greater ownership

Why: Manual processes create emotional investment and accountability

Application: Assign specific individuals to own and report on each metric

#### Implementation Methodology

##### For Installing the sOS (First-Time Implementation)

Phase 1: Assessment (Week 1-2)

Map current state operations and identify bottlenecks

Document existing processes and communication systems

Assess team structure and accountability gaps

Phase 2: Design (Week 3-4)

Create Value Engine maps for core business processes

Design Company Scorecard system with appropriate metrics

Develop High-Output Team structure and accountability

Phase 3: Implementation (Week 5-8)

Roll out new systems with proper training

Establish meeting rhythm and reporting cadence

Begin weekly scorecard tracking and reporting

Phase 4: Optimization (Week 9-12)

Refine processes based on initial results

Adjust metrics and targets based on learning

Strengthen team adoption and system usage

##### For Running the Company on the sOS (Ongoing Operations)

Continuous Optimization Cycle:

Weekly: Facilitate scorecard meetings, identify performance issues

Monthly: Conduct Business Reviews, make strategic adjustments

Quarterly: Update Sprint Plans, refine Value Engines

Annually: Review Strategic Anchors, update Three-Year Targets

Focus Areas for Established Systems:

Performance optimization and bottleneck removal

Advanced facilitation and team development

System evolution and scaling for growth

Integration of new processes and team members

### Section 2: Value Engine Mastery

#### Understanding Value Engines

Value Engines are visual maps that document how a company creates and captures value. Every business has three types of Value Engines:

##### Growth Engines

Purpose: Map the process of acquiring new customers

Scope: From initial awareness to completed sale

Example: Lead generation → qualification → proposal → close

##### Fulfillment Engines

Purpose: Map the process of delivering value to customers

Scope: From sale completion to customer satisfaction

Example: Onboarding → delivery → support → success measurement

##### Innovation Engines

Purpose: Map the process of creating and improving products/services

Scope: From idea generation to market launch

Example: Research → development → testing → launch

#### Business Process Mapping Methodology

##### Mapping Symbols

Pill (Terminus): Start or end of a process

Rectangle: Individual task or activity

Diamond: Decision point or gateway

Parallelogram: Data input or output

Arrow Lines: Flow direction between elements

##### Step-by-Step Value Engine Mapping Process

Step 1: Identify the Value Engine

Choose the most important process to map first

Focus on processes that generate the most revenue or impact

Ensure you have the right stakeholders in the room

Step 2: Define Triggering and Ending Events

Triggering Event: What starts this process?

Ending Event: What definitively completes this process?

Be specific and avoid assumptions about obvious start/end points

Step 3: Brainstorm Tasks and Activities

Start with triggering event and ask "Then what happens?"

Continue asking "Then what?" until you reach the ending event

Write each step on a sticky note for easy rearrangement

Step 4: Identify Decision Points

Look for places where the process can go different directions

Mark these with diamond symbols

Document what determines which path is taken

Step 5: Find Power Stages

Power Stage: A critical step that must be executed perfectly for the engine to work

Usually 1-3 power stages per Value Engine

These require extra attention, training, and quality control

Step 6: Document and Optimize

Create clean visual map of the final process

Identify bottlenecks, inefficiencies, or gaps

Develop improvement plans for optimization

#### Value Engine Facilitation

##### For Installing the sOS: Workshop Setup

Room: Large enough for team with multiple whiteboards

Materials: Sticky notes, Sharpie markers, dry erase markers

Participants: Process owners, stakeholders, and leadership

Time: 2-4 hours depending on complexity

##### For Running the Company on the sOS: Ongoing Management

Regular Reviews: Monthly or quarterly Value Engine optimization sessions

Performance Analysis: Track metrics at each stage of the engine

Process Refinement: Continuous improvement based on results and feedback

Team Training: Onboard new team members on existing Value Engines

##### Facilitation Best Practices (Both Scenarios)

Keep energy high and participation active

Don't let perfectionism slow down initial mapping (Installing) or optimization (Running)

Encourage debate about process steps and sequence

Focus on "what actually happens" vs. "what should happen"

Document assumptions and areas needing clarification

##### Common Mapping Mistakes

Starting too far into the process (missing true triggering event)

Ending too early (before true completion)

Making steps too high-level (missing important details)

Confusing multiple processes (mixing Growth and Fulfillment)

Not involving the right people in the mapping session

#### Value Engine Optimization

##### Performance Measurement

Identify key metrics for each stage of the engine

Track conversion rates between stages

Measure time spent in each stage

Monitor quality indicators at Power Stages

##### Continuous Improvement

Regular review sessions (monthly or quarterly)

A/B testing of process variations

Feedback collection from process participants

Benchmarking against industry standards

### Section 3: Company Scorecard System

#### Scorecard Philosophy

The Company Scorecard is the heartbeat of the sOS. It provides a weekly pulse on business performance and creates accountability for results.

##### Core Principles

Manual Data Entry: Team members input their own numbers

Weekly Rhythm: Consistent weekly reporting and review

Color-Coded Status: Visual system for quick performance assessment

Ownership Culture: Each metric has a specific owner

#### Metric Categories

##### Evergreen Metrics

Definition: High-level financial and business metrics tracked consistently

Examples: Revenue, gross margin, cash collected, Net Promoter Score

Frequency: Tracked weekly, reported monthly

Owner: Usually department heads or executives

##### North Star Metrics

Definition: The 3 most important leading indicators for current quarter, based on the Quarterly Sprint Plan (QSP)

Purpose: Focus team attention on key drivers of success

Selection: Based on quarterly priorities and strategic objectives

Review: Updated each quarter based on business focus

##### Team Metrics

Definition: Department-specific metrics that drive overall performance

Examples: Sales: pipeline value, Marketing: qualified leads, Operations: project completion rate

Ownership: Department managers and team leads

Integration: Should connect to and support North Star metrics

#### Color-Coding System

##### Dark Green: On Track or Ahead

Performance meets or exceeds target

No intervention needed

Celebrate and maintain momentum

##### Lime Green: Temporary Behind

Behind target but due to seasonal/temporary factors

Expected to return to green next week

Monitor but no immediate action required

##### Yellow: Behind with Plan

Performance below target

Clear plan exists to catch up

Requires explanation in notes section

Rule: No plan = no yellow (must be red)

##### Light Red: Behind Without Plan

Performance below target

No clear recovery plan identified

Requires immediate attention and problem-solving

##### Dark Red: Significantly Behind

Far behind target with no realistic path to recovery

May require strategic pivot or resource reallocation

Triggers emergency planning sessions

#### Target Setting Methodology

##### Top-Down Targets

Start with company goals and work backwards

Example: Need 1,000 widgets/month → set production target at 1,000

Used when business objectives drive metric requirements

##### Bottom-Up Targets

Start with current performance and set improvement goals

Example: Current close rate 16% → target 20% based on improvements

Used when optimizing existing performance

##### Target Setting Best Practices

Involve metric owners in target setting (don't dictate)

Expect targets to be wrong initially (takes 12 weeks to get accurate)

Focus on learning rather than perfection in first quarter

Adjust targets based on data and experience

#### Weekly Scorecard Process

##### Data Collection (Monday)

Each metric owner inputs previous week's performance

Update month-to-date actuals

Compare actual vs. target performance

Apply appropriate color coding based on status

##### Status Assessment

Consider context beyond just numbers

Factor in upcoming events, seasonal patterns, resource changes

Make judgment call on realistic recovery potential

Add explanatory notes for yellow and red metrics

##### Reporting and Review

Compile individual scorecards into company-wide view

Identify patterns and trends across departments

Escalate red metrics for problem-solving

Celebrate green performance and share best practices

#### Scorecard Management

##### Your Role as Operations Assistant

For Installing the sOS:

Design scorecard templates and systems from scratch

Train team members on proper usage and methodology

Facilitate initial target-setting workshops

Establish weekly reporting rhythm and accountability systems

For Running the Company on the sOS:

Optimize existing scorecard systems for better performance

Analyze trends and provide insights to leadership

Identify process improvements and system refinements

Train new team members on established scorecard processes

Facilitate advanced scorecard analysis and strategic insights

##### Common Implementation Challenges

Resistance to Manual Entry: Emphasize ownership and insight benefits

Inconsistent Reporting: Establish clear deadlines and accountability

Gaming the System: Focus on learning culture vs. punishment culture

Too Many Metrics: Start small and add metrics gradually (Installing) or consolidate metrics (Running)

### Section 4: High-Output Team Design

#### High-Output Team Framework

High-Output Teams are characterized by three critical elements that create clarity and drive performance.

##### Clear Purpose

Definition: Everyone understands why the team exists and what value it creates

Components: Team mission, objectives, success metrics

Implementation: Document team charter and review regularly

##### Clear Context

Definition: Team members understand how their work fits into the bigger picture

Components: Company strategy, department goals, interdependencies

Implementation: Regular communication about company direction and priorities

##### Clear Accountability

Definition: Each person knows exactly what they're responsible for delivering

Components: Role definitions, performance expectations, decision-making authority

Implementation: Critical Accountability Bullets (CABs) for each team member

#### Critical Accountability Bullets (CABs)

##### CAB Structure

Each team member should have 3-5 Critical Accountability Bullets that define their core responsibilities:

Format: [Action Verb] + [Specific Deliverable] + [Quality/Quantity Standard] + [Timeline]

Examples:

"Deliver weekly financial reports with variance analysis by Tuesday 5 PM"

"Maintain customer satisfaction score above 4.5/5.0 monthly"

"Complete project milestones on time and within budget 95% of the time"

##### CAB Development Process

Identify Core Responsibilities: What are the 3-5 most important things this person must deliver?

Define Success Metrics: How will we measure successful completion?

Set Clear Standards: What does "good" look like quantitatively?

Establish Timelines: When and how often should this be delivered?

Gain Agreement: Ensure the team member understands and commits to the CABs

##### CAB Management

Review Frequency: Monthly one-on-one meetings

Performance Tracking: Integrate CABs into scorecard metrics where possible

Updates: Revise CABs quarterly or when roles change significantly

Accountability: Use CABs as basis for performance reviews and feedback

#### Team Canvas Development

##### Team Canvas Components

Team Purpose: Why does this team exist?

Team Members: Who is on the team and what are their roles?

Stakeholders: Who depends on this team's output?

Deliverables: What does this team produce?

Success Metrics: How do we measure team performance?

Dependencies: What does this team need from others to succeed?

##### Canvas Creation Process

Gather the Team: Include all team members and key stakeholders

Facilitate Discussion: Work through each canvas component systematically

Document Agreements: Capture decisions and commitments clearly

Validate Understanding: Ensure everyone interprets the canvas the same way

Regular Review: Update canvas quarterly or when team structure changes

#### Performance Management Integration

##### Connecting Individual and Team Performance

Link individual CABs to team scorecard metrics

Ensure personal goals support team objectives

Create visibility between individual contributions and team results

##### Feedback and Coaching

Use CABs as framework for regular feedback conversations

Focus on specific, measurable performance indicators

Provide coaching to help team members meet their accountability bullets

##### Recognition and Development

Celebrate when team members consistently deliver on CABs

Identify development opportunities based on performance gaps

Use high performers as mentors for struggling team members

### Section 5: Scalable Planning System

#### Planning Framework Overview

The Scalable Planning System operates on multiple time horizons to ensure both strategic direction and tactical execution:

3-Year Cycles: Strategic direction and major objectives

90-Day Sprints: Focused execution periods with specific goals

Weekly Measurement: Progress tracking and course correction

Monthly Pivots: Strategic adjustments based on results

#### Three-Year Target Development

##### Components of Three-Year Target

Revenue Target: Specific top-line revenue goal

Profit Target: Bottom-line profitability objective

Enterprise Value: Overall business valuation goal

Strategic Anchors: Core competitive advantages to build/maintain

##### Strategic Anchors Framework

Strategic Anchors are the collection of skills, resources, and assets that create defensible competitive advantage:

Types of Strategic Anchors:

Capability Anchors: Unique skills or expertise

Asset Anchors: Proprietary resources or infrastructure

Relationship Anchors: Exclusive partnerships or customer relationships

Brand Anchors: Market position and reputation advantages

Development Process:

Audit Current Anchors: What advantages do we have today?

Identify Gaps: What anchors do we need to build?

Prioritize Development: Which anchors will have the biggest impact?

Create Build Plans: How will we develop these anchors over 3 years?

#### Quarterly Sprint Planning (QSP)

##### QSP Structure

Each 90-day sprint includes:

Rally Cry: Memorable theme that captures the quarter's focus

North Star Metrics: 3 key metrics to improve during the quarter

Key Initiatives: 5-7 specific projects to drive North Star improvement

Resource Allocation: Budget and personnel assignments for initiatives

##### Sprint Planning Process

Step 1: Review Previous Quarter

Analyze performance against previous quarter's goals

Identify what worked, what didn't, and why

Extract lessons learned for current planning

Step 2: Set North Star Metrics

Choose 3 leading indicators that drive business results

Ensure metrics are measurable and within team control

Set specific targets for end-of-quarter performance

Step 3: Develop Key Initiatives

Brainstorm projects that could improve North Star metrics

Prioritize based on impact potential and resource requirements

Limit to 5-7 initiatives to maintain focus

Step 4: Create Rally Cry

Develop memorable phrase that captures quarter's theme

Should inspire and align team around common purpose

Examples: "Scale the Summit," "Perfect the Process," "Accelerate Growth"

Step 5: Assign Ownership

Designate initiative owners and team members

Clarify roles, responsibilities, and decision-making authority

Establish regular check-in and reporting schedule

##### Sprint Execution Management

Weekly Check-ins: Review initiative progress and remove obstacles

Monthly Reviews: Assess overall sprint performance and make adjustments

Obstacle Removal: Quickly address blockers that impede progress

Resource Reallocation: Shift resources between initiatives based on results

#### Monthly Pivoting Process

##### Monthly Business Review (MBR) Structure

Scorecard Review: Analyze performance across all key metrics

Initiative Updates: Status reports from all initiative owners

Problem-Solving: Address red metrics and blocked initiatives

Resource Decisions: Reallocate budget, people, or priorities as needed

Strategic Adjustments: Modify plans based on new information or results

##### Pivot Decision Framework

Green Performance: Continue current approach, look for optimization opportunities

Yellow Performance: Investigate root causes, develop improvement plans

Red Performance: Consider significant changes or resource reallocation

New Opportunities: Evaluate whether to pursue unexpected opportunities

#### Planning Integration

##### Connecting Time Horizons

Ensure quarterly sprints advance three-year targets

Link monthly pivots to quarterly sprint success

Use weekly scorecards to inform monthly pivot decisions

##### Communication and Alignment

Regular all-hands meetings to share progress and direction

Department-specific planning sessions to cascade company priorities

Individual goal-setting that connects to team and company objectives

### Section 6: Meeting Rhythm & Decision-Making

#### Meeting Architecture

The sOS uses a structured meeting rhythm to ensure information flows efficiently and decisions are made at the appropriate level and frequency.

##### Weekly Scorecard Meetings

Purpose: Review performance, identify issues, maintain accountability

Duration: 30-60 minutes depending on team size

Participants: Department teams and their direct manager

Agenda: Scorecard review, red metric problem-solving, obstacle removal

##### Monthly Business Reviews (MBRs)

Purpose: Strategic review, resource allocation, major decision-making

Duration: 2-3 hours

Participants: Leadership team and department heads

Agenda: Financial review, initiative updates, strategic pivots

##### Quarterly Sprint Planning

Purpose: Set direction and priorities for next 90 days

Duration: Full day or two half-days

Participants: Entire leadership team, key stakeholders

Agenda: Previous quarter review, next quarter planning, resource allocation

##### Annual Strategic Planning

Purpose: Set three-year targets and strategic direction

Duration: 2-3 days (often offsite)

Participants: Leadership team, board members (if applicable)

Agenda: Market analysis, strategic anchor development, long-term planning

#### Meeting Facilitation Best Practices

##### Preparation

Send agendas 24-48 hours in advance

Ensure all participants have necessary data and reports

Prepare discussion questions and decision frameworks

Set clear objectives for what should be accomplished

##### Facilitation

Start and end on time consistently

Keep discussions focused on agenda items

Encourage participation from all attendees

Document decisions and action items clearly

Assign ownership and deadlines for follow-up actions

##### Follow-Up

Send meeting notes within 24 hours

Track completion of action items

Schedule follow-up meetings as needed

Update relevant scorecards and tracking systems

#### Clarity Compass Framework

The Clarity Compass is a decision-making tool that captures the company's core beliefs and strategic direction in one visual framework.

##### Clarity Compass Components

Strategic Anchors (Top)

Core competitive advantages and capabilities

What makes the company uniquely valuable

Foundation for strategic decision-making

Three-Year Target (Right)

Specific financial and business objectives

Measurable goals for revenue, profit, and value

North star for all strategic initiatives

Core Values (Bottom)

Fundamental beliefs that guide behavior

Cultural principles for decision-making

Standards for hiring, firing, and promotion

Company Purpose (Left)

Why the company exists beyond making money

Impact and contribution to customers and society

Motivational foundation for team engagement

##### Using the Clarity Compass

Decision-Making Filter When facing strategic decisions, ask:

Does this align with our Strategic Anchors?

Does this advance our Three-Year Target?

Does this reflect our Core Values?

Does this serve our Company Purpose?

Communication Tool

Use in onboarding new team members

Reference in strategic planning sessions

Include in company presentations and materials

Review and update annually

Conflict Resolution When teams disagree on direction:

Return to Clarity Compass for guidance

Evaluate options against each component

Choose path that best aligns with overall framework

#### Decision-Making Protocols

##### Decision Types and Authority Levels

Type 1: Reversible Decisions

Low-risk decisions that can be easily changed

Should be made quickly by person closest to the work

Examples: Marketing copy changes, minor process adjustments

Type 2: Irreversible Decisions

High-impact decisions that are difficult to change

Require careful analysis and senior leadership approval

Examples: Major hiring, significant budget allocation, strategic partnerships

##### Decision-Making Process

Define the Decision: What exactly needs to be decided?

Gather Information: What data and input is needed?

Identify Options: What are the possible choices?

Evaluate Against Compass: How do options align with strategic framework?

Make Decision: Choose best option based on analysis

Communicate Decision: Ensure all stakeholders understand choice and rationale

Execute and Monitor: Implement decision and track results

##### Escalation Guidelines

Financial Threshold: Decisions above certain dollar amounts require approval

Strategic Impact: Decisions affecting multiple departments or long-term direction

Risk Level: Decisions with significant downside potential

Precedent Setting: Decisions that could establish new policies or procedures

### Implementation Guidance

#### For Installing the sOS (First-Time Implementation)

##### Phase 1: Foundation (Weeks 1-2)

Assess current operational state and identify key stakeholders

Introduce sOS concepts to leadership team

Select first Value Engine to map (usually Growth Engine)

Gather team for initial Value Engine mapping workshop

##### Phase 2: Value Engine Development (Weeks 3-4)

Complete Growth Engine mapping with full team

Identify Power Stages and optimization opportunities

Map Fulfillment Engine for core product/service

Document processes and create visual maps

##### Phase 3: Scorecard Design (Weeks 5-6)

Identify Evergreen metrics for company tracking

Work with departments to define Team metrics

Set initial targets (expect to refine over time)

Create scorecard templates and tracking systems

##### Phase 4: Team Structure (Weeks 7-8)

Develop Critical Accountability Bullets (CABs) for key roles

Create Team Canvas for each department

Establish clear reporting relationships and communication flows

Train managers on performance management integration

##### Phase 5: Planning System (Weeks 9-10)

Facilitate Three-Year Target and Strategic Anchor development

Plan first Quarterly Sprint with North Star metrics and initiatives

Create Clarity Compass for decision-making framework

Establish meeting rhythm and calendar

##### Phase 6: Meeting Rhythm (Weeks 11-12)

Launch weekly scorecard meetings

Conduct first Monthly Business Review

Train facilitators on meeting best practices

Establish follow-up and accountability systems

##### Phase 7: Optimization (Ongoing)

Monitor system adoption and usage

Refine processes based on team feedback

Adjust metrics and targets based on learning

Continuously improve facilitation and communication

#### For Running the Company on the sOS (Ongoing Operations)

##### Weekly Operations

Facilitate weekly scorecard meetings across all departments

Analyze performance trends and identify emerging issues

Provide coaching to team members on scorecard usage

Escalate red metrics and coordinate problem-solving efforts

##### Monthly Operations

Conduct Monthly Business Reviews with leadership team

Analyze quarterly sprint progress and resource allocation

Facilitate strategic pivots and course corrections

Update and refine Value Engine processes based on performance data

##### Quarterly Operations

Lead Quarterly Sprint Planning sessions

Review and update North Star metrics and initiatives

Assess Value Engine performance and optimization opportunities

Facilitate team structure and CAB updates

##### Annual Operations

Coordinate annual strategic planning sessions

Review and update Three-Year Targets and Strategic Anchors

Assess overall sOS effectiveness and system improvements

Plan major system upgrades or expansions

##### Continuous Improvement

Monitor system adoption and identify optimization opportunities

Train new team members on sOS methodology

Benchmark performance against industry standards

Evolve systems to support company growth and scaling

### Troubleshooting Common Issues

#### Low Adoption of Manual Processes

Symptoms: Team members resist manual scorecard entry, prefer automated dashboards Solutions:

Emphasize ownership and insight benefits

Share examples of insights gained through manual interaction

Start with willing early adopters to demonstrate value

Provide training on how manual processes create better results

#### Inconsistent Meeting Rhythm

Symptoms: Meetings get cancelled, rescheduled, or lose focus Solutions:

Establish non-negotiable meeting schedule

Create clear agendas and stick to them

Assign rotating facilitation responsibilities

Track meeting effectiveness and adjust format as needed

#### Metric Gaming or Manipulation

Symptoms: Teams focus on making numbers look good rather than driving real performance Solutions:

Emphasize learning culture over punishment culture

Focus on trends and insights rather than absolute numbers

Regularly review and adjust metrics to maintain relevance

Celebrate honest reporting of problems and challenges

#### Overwhelming Complexity

Symptoms: System becomes too complex, teams get confused or overwhelmed Solutions:

Start simple and add complexity gradually

Focus on most important metrics and processes first

Provide regular training and support

Simplify or eliminate elements that aren't adding value

#### Lack of Leadership Engagement

Symptoms: Senior leaders don't participate actively in the system Solutions:

Demonstrate clear ROI and business impact

Start with willing leaders and let success spread

Provide executive-level reporting and insights

Connect system usage to business results

### Success Metrics

#### System Implementation Success

All core Value Engines mapped and documented

The Company Scorecard system operational with weekly reporting

High-Output Team structure implemented with clear CABs

Meeting rhythm established and consistently followed

Clarity Compass created and actively used for decisions

#### Business Performance Indicators

Improved visibility into business performance and trends

Faster identification and resolution of operational issues

Better alignment between individual, team, and company goals

Increased accountability and ownership across the organization

More effective strategic planning and execution

#### Cultural and Behavioral Changes

Teams take ownership of their metrics and performance

Problems are identified and addressed proactively

Decision-making becomes more systematic and strategic

Communication improves across departments and levels

The company operates more independently of founder involvement

This training guide provides the foundation for implementing the Scalable Operating System in any business. Use these frameworks and methodologies to help companies transition from founder-dependent operations to scalable, systematic business operations that can grow without burning out leadership.

### Glossary of Key sOS Terms

All-Hands Meeting—A meeting to update everyone at the company on the goals the company has set, the projects it has greenlit, and the progress the teams are making toward those goals.

Business Playbooks— A set of actionable, step-by-step checklists documenting individual tasks that must be completed, as well as the order in which those tasks must be completed, to execute a repeatable process or activity.

Clarity Compass— A visual, decision-making framework which serves as the capstone for your company's operating system. It captures the default beliefs and assumptions about your business's Strategic Anchors, Three-Year Target, Core Values, and Company Purpose in one easily understandable and transferable document.

Company Operating System (a.k.a. business operating system)—A single source of truth that documents what a company does, how it does it, and the progress it is making toward its stated goals and objectives. While all companies have operating systems, not all operating systems are scalable.

Company Purpose Statement—A concise, one- or two-sentence statement that describes the impact and contribution your company makes in the lives of its customers and clients. The formula for this statement is Contribution + Impact = Purpose.

Company Scorecard— A tool for tracking how your teams and Value Engines are performing. Company Scorecards typically include categories such as Evergreen, North Star, Teams/Departments, etc. Three to five key metrics per category are tracked on the scorecard.

Core Values— The unique set of beliefs and behaviors that define a company's culture.

Critical Accountability Bullets (CABs)— A list of the three to five most important roles and responsibilities for each member of your team.

Evergreen Metrics— High-level metrics such as revenue, gross margin, cash collected, Net Promoter Score (NPS), or any other important financial or business metric you track on an ongoing basis.

Fulfillment Engine— A visual map of the process by which customers receive the promised value after the sale is made.

Growth Engine— A visual map of the process by which new customers are acquired and sold.

High-Output Team— A team that clearly understands the work that needs to be done for your business, along with who exactly is uniquely responsible for doing that work. High-Output Teams are marked by three critical characteristics: clear purpose, clear context, and clear accountability.

High-Output Team Canvas— A tool for assigning clear roles and accountability to team members and a critical piece of the set of algorithms for your business.

Innovation Engine— A visual map of the process by which product and service offerings are created, updated, and improved.

Meeting Rhythm— The cycle of meetings within a business. A meeting rhythm that is architected to scale will ensure the correct information is shared with the right people at the right time, allowing teams and individuals to make data-driven decisions that lead the company toward its goals.

Monthly Business Review (MBRs)— A regular meeting to discuss three items: (1) company financials and scorecards; (2) status reports from team leaders; and (3) any necessary pivots or resource reallocations.

North Star Metrics— The three most important, leading metrics you have selected for a given quarter.

Playbook Library— A collection of the Business Playbooks for your business and a critical piece of the set of algorithms for a Scalable OS (it is your "vault" of "secret recipes").

Power Stage— A critical task within a Value Engine; a task that your business has to get right in order for the Value Engine to run.

Quarterly Sprint Plan (QSP)— A plan for the next ninety days at your business. QSPs are marked by a memorable "rally cry" for team members as well as five-to-seven key initiatives to improve your business's North Star metrics during that ninety-day period. QSPs ultimately push the company toward hitting the Three-Year Target.

Scalable OS— A model for operating a business in which the CEO has a trusted team that is fully capable of making high-level decisions as good or better than he or she would.

Scalable Planning System— A proven, four-part strategic planning and meeting cadence where companies: (1) plan in three-year cycles (Three-Year Target); (2) execute in ninety-day sprints (QSPs); (3) measure and report in weekly scorecard meetings; and (4) pivot monthly.

Strategic Anchors— The collection of skills, resources, and assets your company possesses that combine to form a truly defensible competitive advantage.

Team Metrics— The three most important metrics each team selects to highlight on the Company Scorecard.

Three-Year Target— A formal business objective that outlines what the company's top line revenue, bottom line profit, and total enterprise value will be in three years from the date the goal is set. It is an integral part of the Scalable Planning System.

Value Engine— A visual representation of how a company creates and captures marketplace value through the acquisition of new customers, fulfillment of existing customers, and the creation and/or improvement of the company's product and service offerings.

This training guide provides comprehensive knowledge for implementing and operating the Scalable Operating System. Use this glossary to ensure consistent terminology and proper understanding of all sOS concepts when helping companies with either "Installing the sOS" or "Running the company on the sOS."
