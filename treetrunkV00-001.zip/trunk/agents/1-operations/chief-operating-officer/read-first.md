# Read first: Director of Operations / COO

**Department:** Operations

**Role:** Turn chaotic daily agent tasks into smooth, repeatable business systems.

## Training

- Real estate business systems design
- Standard Operating Procedure (SOP) documentation
- CRM pipeline governance
- Vendor & tech stack management

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
