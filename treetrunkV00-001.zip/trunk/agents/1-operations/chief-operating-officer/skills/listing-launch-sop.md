# Build a Master Listing Launch SOP Checklist

**Department:** Operations  
**Specialist:** Director of Operations / COO  
**Version:** v1.2  
**Last updated:** 2026-10-11  
**Source path:** `operations/coo/listing-launch-sop.md`

Document a step-by-step checklist from signed listing agreement to active MLS status.

## Required inputs

- Photography vendor details
- Sign placement process
- MLS input requirements
- Admin assistant role responsibilities

## Instructions

Create a 25-point SOP checklist divided by Phase: 1) Pre-Photography, 2) Media & Copy Prep, 3) MLS Input, 4) Launch Day Distribution.

## Example request

> Build a Master Listing Launch SOP checklist that my admin assistant and I can follow for every new listing.
