# Read first: CRM & Systems Administrator

**Department:** Operations

**Role:** Ensure lead data cleanliness, automated tagging, and database maintenance.

## Training

- Database contact segmentation
- Tagging conventions & smart lists
- Drip campaign automation triggers
- Data deduplication & cleanup

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
