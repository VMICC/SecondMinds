# Case 20: Clean the CRM: find the duplicates before they embarrass you

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/1-operations/crm-systems-administrator/`
**You get:** Approval-first merge list + gaps list
**Channels:** CRM
**Source:** System AI Realtor OS guide, page 12 / 16

## The problem

The same client exists three times (phone only, email only, and under a spouse's name), so they get two postcards and no birthday message.

## Copy + paste prompt

```
Review this CRM export for duplicates by phone, email, address, and name variation, including spouses. Give me a merge list showing the record you would keep and what merges into it. Change nothing until I approve. Also list contacts missing a birthday, address, or closing date.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
