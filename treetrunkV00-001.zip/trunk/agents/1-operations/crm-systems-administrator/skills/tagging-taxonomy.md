# Design a clean CRM Tagging & Smart List Taxonomy

**Department:** Operations  
**Specialist:** CRM & Systems Administrator  
**Version:** v1.1  
**Last updated:** 2026-10-04  
**Source path:** `operations/crm-admin/tagging-taxonomy.md`

Establish strict rules for contact tags (Source, Pipeline Stage, Niche, City) to ensure clean segmentation.

## Required inputs

- Current CRM platform name
- Total contact count in database
- Main lead sources

## Instructions

Define standard tag syntax [Type: Value], e.g., [Source: Open House], [Stage: Warm Seller], [Location: Westside].

## Example request

> Draft a clean CRM tagging guide for my 1,200 database contacts so we can segment farm homeowners vs sphere easily.
