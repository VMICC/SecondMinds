# Draft weekly escrow milestone update emails

**Department:** Client Care  
**Specialist:** Transaction Experience Coordinator  
**Version:** v1.1  
**Last updated:** 2026-10-05  
**Source path:** `client-care/transaction-coordinator/escrow-milestone-templates.md`

Keep clients proactive and calm during key escrow milestones (Inspection, Appraisal, Loan Commitment).

## Required inputs

- Current escrow milestone reached
- Next upcoming deadline date
- Key task client needs to complete

## Instructions

Use clear, reassuring tone. Structure: What Happened, What Is Happening Now, What Is Next, What We Need From You.

## Example request

> Draft an email updating my seller clients that inspection is complete and outlining our strategy for the repair request list.
