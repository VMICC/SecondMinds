# Case 21: Transaction deadline tracker: earnest money, inspection, radon, closing

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/4-client-experience/transaction-experience-coordinator/`
**You get:** One deadline sheet per deal + chase drafts
**Channels:** Email / SMS
**Source:** System AI Realtor OS guide, page 13 / 16

## The problem

Every deal has 6-10 dates in different emails and contracts. The missed one (earnest money due, inspection notice, pickup time) is the expensive one.

## Copy + paste prompt

```
For this transaction, build a deadline sheet from the contract and emails: earnest money, inspection and notice dates, any test pickup windows, appraisal, and closing, with who owes what to whom. Flag anything unconfirmed 48 hours out and draft the chase message to the right person.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
