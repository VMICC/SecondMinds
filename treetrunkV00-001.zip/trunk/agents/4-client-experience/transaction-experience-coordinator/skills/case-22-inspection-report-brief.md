# Case 22: Turn a 40-page inspection report into a one-page plain-English brief

**Section:** D / Inbox, Deals & Daily Control (Bring the details into one daily view.)
**Owner:** `agents/4-client-experience/transaction-experience-coordinator/`
**You get:** 1-page brief + decision frame
**Channels:** Email to client / Attorney
**Source:** System AI Realtor OS guide, page 13 / 16

## The problem

Inspection reports are 40+ pages of photos and codes. Your buyer is anxious, the notice deadline is today, and nobody has time to read it properly.

## Copy + paste prompt

```
Summarize this inspection report in plain English: safety items first, then real repairs, then what belongs to the HOA or others, then what is normal for a home this age. End with the 2-3 strongest items for an inspection notice and note today's notice deadline. Keep the inspector's findings separate from your summary.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
