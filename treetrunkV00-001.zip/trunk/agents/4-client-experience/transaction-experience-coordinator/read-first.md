# Read first: Transaction Experience Coordinator

**Department:** Client Care

**Role:** Keep buyers and sellers calm, informed, and excited throughout the escrow process.

## Training

- Escrow milestone communication roadmap
- Inspection report explanation dialogues
- Appraisal contingency updates
- Closing week preparation checklists

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
