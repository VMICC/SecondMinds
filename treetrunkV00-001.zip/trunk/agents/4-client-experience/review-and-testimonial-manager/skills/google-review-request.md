# Draft a frictionless 2-step Google Review request email/text

**Department:** Client Care  
**Specialist:** Review & Testimonial Manager  
**Version:** v1.1  
**Last updated:** 2026-10-09  
**Source path:** `client-care/review-manager/google-review-request.md`

Ask for reviews at the moment of highest excitement (closing week) with direct links.

## Required inputs

- Google Business review link
- Client name & transaction milestone
- Specific win highlight (e.g., sold over list price)

## Instructions

Provide a short 3-sentence text message and a follow-up email providing 2 suggested prompt questions to make writing easy for the client.

## Example request

> Draft a warm text message asking my buyer clients for a Google review 3 days after they moved into their new home.
