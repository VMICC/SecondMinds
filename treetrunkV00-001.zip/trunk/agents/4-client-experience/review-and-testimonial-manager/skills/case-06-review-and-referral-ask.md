# Case 06: Ask for the review and the referral, at the moment they are happiest

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/review-and-testimonial-manager/`
**You get:** Timed reminder + two staged drafts
**Channels:** SMS / Email
**Source:** System AI Realtor OS guide, page 05 / 16

## The problem

The best review window is the week after closing or after you solved a problem. By the time you remember to ask, the glow is gone.

## Copy + paste prompt

```
When a client closes, remind me on day 7 to ask for a review. Draft the ask naming one specific thing that went well in their deal, include my review link, and keep it to 3 sentences. If they reply warmly, draft a separate, soft referral ask, do not combine them.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
