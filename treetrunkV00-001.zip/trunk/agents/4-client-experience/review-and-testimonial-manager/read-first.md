# Read first: Review & Testimonial Manager

**Department:** Client Care

**Role:** Capture glowing 5-star Google and Zillow reviews and transform them into marketing assets.

## Training

- Review request timing & scripts
- Google Business Profile review optimization
- Video testimonial prompt scripts
- Transforming reviews into social graphic quotes

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
