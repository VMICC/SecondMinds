# 4. Client-Experience

Make every client feel taken care of before, during, and after the deal: the touches, the milestones, the reviews, the care moments.

Reports to: the Chief of Staff. Personality: `soul.md`. Identity: `identity.md`. Charter and owned skills: `agents.md`.

## Team

- **Head of Customer Success** (`head-of-customer-success/`): Past-client care: anniversaries, check-ins, retention, referrals.
- **Transaction Experience Coordinator** (`transaction-experience-coordinator/`): Keep buyers and sellers calm, informed, and excited throughout the escrow process.
- **VIP Client Concierge** (`vip-client-concierge/`): Design closing gift experiences, client appreciation events, and annual home anniversary touches.
- **Review and Testimonial Manager** (`review-and-testimonial-manager/`): Capture glowing 5-star Google and Zillow reviews and transform them into marketing assets.
