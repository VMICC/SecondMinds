# Plan an Annual Client Appreciation Event roadmap

**Department:** Client Care  
**Specialist:** VIP Client Concierge  
**Version:** v1.3  
**Last updated:** 2026-10-16  
**Source path:** `client-care/vip-concierge/client-appreciation-event.md`

Build a complete event budget, invitation timeline, and vendor sponsorship strategy.

## Required inputs

- Target event date & season
- Expected guest count (past clients + families)
- Budget or lender co-sponsor availability

## Instructions

Provide 8-week event rollout timeline: Venue booking, Save the Date email, Personal phone calls, Final RSVPs, Event day checklist, Post-event photo recap.

## Example request

> Create an 8-week launch plan for a 'Fall Pumpkin Patch & Family Portraits' client appreciation event in October.
