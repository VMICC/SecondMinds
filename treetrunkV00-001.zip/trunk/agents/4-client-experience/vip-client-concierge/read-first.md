# Read first: VIP Client Concierge

**Department:** Client Care

**Role:** Design closing gift experiences, client appreciation events, and annual home anniversary touches.

## Training

- Memorable closing gift curation
- Client event planning (Pie Day, Summer BBQ, Shred Event)
- Local vendor recommendation directory
- Surprise & delight touchpoints

_Profile generated from the System AI Team site. This role has no folder in the C-Suite zip template._
