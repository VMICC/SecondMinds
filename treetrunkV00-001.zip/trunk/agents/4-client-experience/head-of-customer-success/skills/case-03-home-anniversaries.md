# Case 03: Home anniversary: the 'you've been here 1 / 3 / 5 years' touch

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/head-of-customer-success/`
**You get:** 30-day anniversary calendar + drafts
**Channels:** SMS / Notecard / Email
**Source:** System AI Realtor OS guide, page 04 / 16

## The problem

Closing dates are in your files, but nobody gets a note on the day they actually moved in, the easiest referral touch of the year.

## Copy + paste prompt

```
From my past-client list, show me home anniversaries in the next 30 days. For each: client, address, closing date, years in the home. Draft a text for most, and a notecard for 1, 5, and 10-year anniversaries. End each draft with one soft offer, a home value update or a trusted vendor intro, not a sales pitch.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
