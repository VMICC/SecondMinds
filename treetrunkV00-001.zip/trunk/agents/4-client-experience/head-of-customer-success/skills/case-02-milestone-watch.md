# Case 02: Watch your friends list for milestones: baby, job, engagement, anniversary

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/head-of-customer-success/`
**You get:** Daily milestone list with links + drafts
**Channels:** Messenger / Notecard / SMS
**Source:** System AI Realtor OS guide, page 03 / 16

## The problem

A past client posts 'we're expecting!' or 'new job, new city' and you see it three weeks late, or never.

## Copy + paste prompt

```
Scan my Facebook friends and past clients daily for life milestones: baby, pregnancy, new job, promotion, engagement, wedding, anniversary, retirement, graduation. For each one, give me the person, the milestone, the post link, and a draft personal message for Messenger plus a notecard version for past clients. Flag any milestone that could mean a move, separately, do not pitch in the congrats.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
