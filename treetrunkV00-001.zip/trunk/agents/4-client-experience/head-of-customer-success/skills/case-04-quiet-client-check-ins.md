# Case 04: The no-reason check-in for past clients who have gone quiet

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/head-of-customer-success/`
**You get:** 10 names/week + individual drafts
**Channels:** SMS / Messenger
**Source:** System AI Realtor OS guide, page 04 / 16

## The problem

You have 80+ past clients you have not contacted in 6 months. A generic 'just checking in' feels salesy, so you send nothing.

## Copy + paste prompt

```
Give me 10 past clients I have not contacted in 6+ months, longest gap first. For each, draft a short text that opens with one specific detail about them or their neighborhood, never 'just checking in' and never mention the market unless their street had a recent sale. Keep it under 3 sentences.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
