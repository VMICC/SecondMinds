# Case 05: Sympathy and hard-moment messages, drafted fast, in your voice

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/head-of-customer-success/`
**You get:** Separate care list + careful drafts
**Channels:** Notecard first / Messenger
**Source:** System AI Realtor OS guide, page 05 / 16

## The problem

Someone in your sphere posts about a loss, an illness, or a parent moving to care. You want to say the right thing and you freeze, so you say nothing.

## Copy + paste prompt

```
If you find a loss, illness, or difficult family post in my sphere, put it in a separate 'care' list. Draft a brief, warm message with zero business in it, plus a notecard version. Do not suggest any follow-up or offer. I will review every word before sending.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
