# Case 01: Find every client birthday this week, and draft the message

**Section:** A / Sphere & Client Care (Never miss the personal moment.)
**Owner:** `agents/4-client-experience/head-of-customer-success/`
**You get:** Monday list + ready-to-send drafts
**Channels:** Messenger / SMS / Notecard
**Source:** System AI Realtor OS guide, page 03 / 16

## The problem

Birthdays sit in three places at once (Facebook, your CRM, and old closing files), so half your past clients never hear from you.

## Copy + paste prompt

```
Every Monday, give me everyone in my sphere with a birthday in the next 7 days. For each person: name, date, how I know them, and one personal detail from my notes. Draft a Messenger version (warm, 2 sentences), a text version (shorter), and a notecard version (handwritten length). Flag anyone I have no birthday for so I can ask.
```

_Rules that apply to every case: draft before sending, show the source, protect client files, verify the details. See `wiki/business/ai-realtor-os.md`._
