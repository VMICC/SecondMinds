AI-managed knowledge, written clean and kept current.
