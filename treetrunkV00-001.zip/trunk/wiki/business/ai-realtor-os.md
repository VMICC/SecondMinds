# AI Realtor OS (System)

24 workflows. Your AI. Your business. Built around your business, powered by your preferred AI: sphere, prospecting, listings, daily control.

Source: System AI Realtor OS guide (16 pages, PDF). Full extracted text: `raw/ai-realtor-os-full-text.md`. The 24 cases live as skills in the owning role's folder under `agents/` (file names start with `case-`), except Case 13, which is merged into the canonical `listing-description.md` skill of the Direct Response Copywriter.

## The big idea

Let the system remember. Keep the relationship human. Use AI as a daily watching-and-drafting system: it surfaces a birthday, a lead signal, a promise or a deadline, then prepares the draft and the next step. You stay the human.

## How to use this guide

1. Pick one job: start with the task most likely to slip through the cracks.
2. Make it yours: copy the prompt and fill in your farm, CRM and voice notes.
3. Check the output: confirm names, dates and tone; correct the first draft.
4. Build the rhythm: schedule the useful jobs daily, weekly or per listing.

## Four rules to keep

- **Draft before sending.** Approve every post, DM, text and email.
- **Show the source.** Ask for a link or screenshot reference.
- **Protect client files.** Share only what the job needs.
- **Verify the details.** Confirm dates, prices and anything a client will rely on.

These are workflow templates, not built-in features. Connect authorized tools or provide exports, screenshots and files. Confirm access and scheduling support before relying on scans or reminders. Never claim to have reviewed data that is unavailable.

## Workflow map

| Section | Theme | Cases |
| --- | --- | --- |
| A / Sphere & Client Care | Never miss the personal moment | 01-06 |
| B / Find Sellers & Buyers Daily | Turn useful signals into thoughtful conversations | 07-12 |
| C / Listings & Marketing | One input. Every version you need | 13-18 |
| D / Inbox, Deals & Daily Control | Bring the details into one daily view | 19-24 |

## Start small, build momentum

Install four jobs this week. Pick the job that costs you the most time or goodwill, then put it on a schedule.

- **Day 1:** Birthdays + milestones (Cases 01 + 02). Fastest goodwill, easiest to verify.
- **Day 2:** Local group lead scan (Case 07). One focused list for your farm.
- **Day 3:** Inbox triage with drafts (Case 19). Feel the difference the same morning.
- **Day 4:** One morning trigger brief (Case 24). Pull the first three jobs into a single view.
- **Week 2:** Add a listing job (13 or 14) and a deal job (21 or 22).
- **Week 3:** Add CRM cleanup (20) and a prospecting job (08 or 09).

## A simple operating rhythm

- **Daily:** 24, 02, 07, 19
- **Monday:** 01, 03, 04
- **Weekly:** 11, 12, 15
- **Monthly:** 20
- **Per listing:** 13, 14, 17
- **Per contract:** 21, 22, 23

The master starter prompt that installs the first four jobs is in `prompts/master-starter-prompt.md`.
