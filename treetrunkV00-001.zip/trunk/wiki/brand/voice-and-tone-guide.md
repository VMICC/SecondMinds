# Voice & Tone Guide (System template)

## Voice & Tone Guide

[Your Name] – [Your Team or Group Name], [Your Brokerage Name]

### 1. Brand/Persona Identity

Name / Persona: [Your Name or Brand Persona]

Core Characteristics: [Describe your core traits — confident, approachable, professional, etc.]

Purpose or Mission: [Explain your mission in real estate — e.g., “To help clients make confident real estate moves with strategy and simplicity.”]

### 2. Audience & Relationship

Primary Audience:
 [Who you serve — homeowners, buyers, sellers, investors, etc. Include what they value most.]

Relationship With Audience:
 [How you want clients to see you — trusted advisor, local expert, friendly professional, etc.]

Communication Context:
 [Where and how you communicate — social media, newsletters, emails, listing copy, etc.]

### 3. Tone & Mood

Overall Tone: [Describe tone — e.g., Direct, confident, warm, conversational.]

Mood Conveyed: [E.g., Positive, grounded, reassuring, professional.]

Range of Emotional Expression: [When to be serious, lighthearted, empathetic, etc.]

### 4. Language & Style Preferences

Preferred Vocabulary: [Examples of words/phrases you use often — “local expertise,” “smart strategy,” “market insights.”]

Discouraged or Prohibited Words: [Words or phrases you avoid — e.g., “dream home,” “exclusive,” “once-in-a-lifetime.”]

Level of Formality: [Formal / Semi-formal / Casual — describe your balance.]

Sentence Length & Complexity: [Short, clear, and conversational, or detailed and descriptive?]

Pronoun & Person Usage: [Do you say “I,” “we,” or “our team”? When do you speak directly to “you”?]

### 5. Key Phrases, Taglines, & Signature Expressions

Common Phrases / Catchphrases:

[List a few signature phrases or taglines you naturally say or want to be known for.]

Taglines / Mottos (Suggested):

[Add a few options — e.g., “Real estate made simple.” “Your neighborhood expert.”]

Verbal Tics or Quirks:
 [Examples of your natural expressions — humor, sarcasm, rhetorical questions, etc.]
 [Optional sign-offs — e.g., “Talk soon,” “Let’s find your next move.”]

### 6. Stylistic & Rhetorical Devices

Use of Metaphors & Analogies: [Describe your use — “Occasionally, tied to real-world examples.”]

Use of Storytelling: [Describe approach — “Client stories over sales pitches.”]

Humor or Wit: [Explain when and how you use it — “Light humor to stay relatable.”]

Emphasis Methods: [Examples — bold statements, bullet lists, confident phrasing.]

### 7. Grammar, Syntax & Formatting

Grammar Conventions: [Professional, conversational, flexible — describe your comfort level.]

Use of Contractions: [Yes/No — e.g., “Always use contractions to sound natural.”]

Capitalization & Punctuation Preferences: [E.g., Title Case for headings, minimal exclamation points.]

Structure (Bullets, Lists, Paragraphs): [Short paragraphs, bullets for clarity, spacing for readability.]

### 8. Examples of “In-Voice” Content

Sample 1 (Social Post):
 “[Write a short example of how you’d speak on social media — about the market, a listing, or client advice.]”

Sample 2 (Newsletter or Email):
 “[Write an example of how you’d speak in an email — calm, reassuring, informative.]”

Sample 3 (Listing Description):
 “[Write a short sample listing paragraph that shows your tone — descriptive, clear, inviting.]”

### 9. Special Instructions / Edge Cases

Adapting Tone in Different Contexts:
 • Listings & ads = [Describe tone, e.g., descriptive and confident.]
 • Newsletters or updates = [Warm, informative, friendly.]
 • Tough topics (market shifts, stress) = [Empathetic, calm, factual.]

Handling Sensitive Topics: [Describe your approach — honest but reassuring, transparent but professional.]

Cultural or Community References: [Mention how you tie in your local area — neighborhoods, events, landmarks.]

Do’s & Don’ts:
 ✅ [List what to do — e.g., Be clear, stay authentic, add value.]
 ❌ [List what not to do — e.g., Avoid hype, don’t oversell, no jargon.]
