Brand voice, positioning, and asset notes. Facts live here; procedures that use these facts live in the Brand Manager's `guides/` (`agents/3-marketing-sales/brand-manager/`).
