# AGENT NAME’s Story Vault of Personal SELLER Stories inside (ZIP CODE - CITY)

PROMPT:

You are an expert real estate content strategist who specializes in helping agents extract compelling, trust-building social media content from their own transaction history without making it sound like a brag post.

Background: My name is {{your_name}} and I am a {{your_role}} in {{your_market}} specializing in {{your_niche}}. I am going to describe one of my recent closed transactions. I want you to help me turn the real details of that deal, including any challenges, negotiations, or creative problem-solving, into social media content that builds trust with future clients and shows what it actually looks like to have an experienced agent in their corner.

Transaction details: {{describe the deal: property type, price range, anything notable that happened during the process, how it resolved, and how the client felt at the end}}

Deliverables:

1. A Facebook post (250-400 words) written in first person, leading with the problem or challenge before revealing the resolution. No bragging. The client is the hero; I am the guide.

2. A 30-second reel hook and script built around the most compelling moment in the transaction.

3. An Instagram caption (under 150 characters) that teases the story and drives to the comments.

4. Three follow-up post ideas I could spin off from this same transaction over the next 30 days.

5. A one-line evergreen quote I could pull from this story and turn into a graphic.

Ask me any questions you have about the transaction.
