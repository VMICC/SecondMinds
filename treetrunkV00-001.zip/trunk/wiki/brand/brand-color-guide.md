# Copy of HLA - Brand Color Guide Template - A4

Web link from the template: https://www.canva.com/design/DAHWtvGWEdE/Il4TlcUpq9wyZYYU_vP75g/edit
