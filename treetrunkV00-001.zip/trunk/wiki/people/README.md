One file per person: clients, vendors, referral partners.
