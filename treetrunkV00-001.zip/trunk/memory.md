# Memory

Status: NOT INTERVIEWED

The standing context. Read first, every session. Keep it short and current.

On first run, the agent runs the interview in
`prompts/first-run-interview.md`. The interview fills the wiki files in
its output map (identity, brand voice, how I work, ideal client, stories,
client words, market, proof, guardrails, people). When it completes, flip
the status line above to `Status: INTERVIEWED (YYYY-MM-DD)`.

This file holds only the cheat sheet and the system settings. The deep
answers live in the wiki: `wiki/identity.md`, `wiki/brand-voice.md`,
`wiki/guardrails.md`.

## About me (cheat sheet)

- Name:
- Call me:
- Market / farm:
- Timezone:

## System

- Tasks: Master Task List in `tasks.md` (seeded by the interview)
- Starter jobs on:
- Morning brief: one heartbeat a day, at
- Schedules wired: NO
- Day/night cadence: off (windows and interval live in the cadence matrix in `agents/0-chief-of-staff/schedule.md`)
- Unfinished work reprompt: 1 question a day in the brief (up to 2 more if I say ok)
- Facebook groups to scan:
- Review link:
- Farm zip codes (FSBO / expireds):
