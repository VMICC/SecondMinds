# Agent instructions

You work in this repo for the owner. This is a knowledge system, not a code project: your job is to keep the wiki current, useful, and well-organized from the raw material the owner captures. Follow these standing orders.

## First, every session

**Schedule check (first, and it never goes away until it passes):** if
`memory.md` says `Schedules wired: NO`, the two scheduled jobs (the
translate sweep and the morning brief) are not wired yet, and this
system is not live: nothing runs on its own. Say so once, at the start
of the session, and offer to wire them now. Wiring means creating the
two jobs in the owner's scheduler from the job cards in
`agents/0-chief-of-staff/schedule.md`, at the brief time in
`memory.md`, then setting the line to
`Schedules wired: YES (YYYY-MM-DD)`. If the owner says no, leave the
line at NO and do not ask again that session. The line is never
deleted and the check runs again at the next startup: it does not go
away until the jobs exist. This check runs before the first-run check
on purpose. The first scheduled run reads this file and hits the
first-run check below, so a repo wired before its interview still
interviews before it ever briefs.

**First-run check (second):** if `memory.md` says
`Status: NOT INTERVIEWED`, stop and run the interview in
`prompts/first-run-interview.md` before any other work. Only the
schedule check above outranks it.
The interview's flow is fixed, in this order: (1) **Import first.**
Before any question, the owner drops their memory exports from ChatGPT,
Claude, Gemini, or any other AI tool (plus any bio, testimonials, and
presentations they have) into `raw/`, or says "none". (2) **Ingest.** Run
`prompts/translate.md` over `raw/`, then scan the whole repo and silently
pre-fill every interview question as Found, Partial, or Missing.
(3) **Verify, do not re-ask.** Show found answers back short ("I found
this, is it still right?") for confirm, correct, or skip. (4) **Ask only
what is missing,** one question at a time, writing each answer down as
you go. A don't-know is tagged UNFINISHEDWORK and registered in
`unfinished-work.md`, never pressed or guessed. The interview finishes
by seeding `tasks.md` and filling `memory.md`. When the interview's Finish step completes, set the status line in
`memory.md` to `Status: INTERVIEWED (YYYY-MM-DD)` with the actual date.

1. Read `readme.md` and `memory.md` before doing anything.
2. Know the org: five chiefs under `agents/` (0 Chief of Staff coordinates 1 Operations, 2 CFO, 3 Marketing-Sales, 4 Client-Experience). Each chief follows its own `agents.md` charter. Skills and playbooks belong to exactly one chief and are never shared.

## Common tasks

- **Translate raw**: run the prompt in `prompts/translate.md` against `raw/`.
- **Project digest**: summarize a `projects/` folder into its README.
- **Task forwarding**: at rollover, run `sops/agent/task-forwarding.md`. Mark yesterday's tasks in `today.md` (✓ X → ←), rewrite → items with their forward counts, move ← items to `tasks.md` (the Master Task List), and flag (→×3) items in the brief.
- **Answer questions**: read `wiki/` and `archive/` to answer from the owner's own past thinking and records.
- **Before improvising**, check `sops/` for an approved business practice and the owning chief's `skills/` for a ready playbook.

## Instruction order

When files disagree, the higher one wins:

1. This file (root `AGENTS.md`) wins over everything.
2. A chief's charter (`agents/<chief>/agents.md`) wins over specialist files.
3. A specialist's `instructions.md` and `read-first.md` come last.

Follow the higher file and log the conflict in `today.md`.

## Hard rules

1. **Never delete.** The agent permanently deletes nothing in this repo. If something has to be removed from where it is, move it to `trash/` with a date prefix (`YYYY-MM-DD-name`); only the owner empties `trash/`. Processed originals still go to `archive/`, which is the permanent record, not a trash bucket.
2. **Never overwrite a `wiki/` entry blindly.** Always read it first, then merge.
3. **Never modify `archive/`** after a file lands there. It is a permanent record.
4. **Commit after meaningful changes** with a clear message (for example, `translate: 4 inbox files processed`).
5. **When uncertain, log it in the entry** rather than guessing.
6. **Never quote or copy anything out of `CONFIDENTIAL/`** into other files.
7. **A don't-know never evaporates.** When the owner cannot answer something, in the interview or any session, tag the gap where the answer belongs `[UNFINISHEDWORK: NOT KNOWN]` (they need to find or decide it) or `[UNFINISHEDWORK: NEED TO CREATE]` (it does not exist yet) and register it in `unfinished-work.md`. The Chief of Staff resurfaces one per day in the morning brief, up to 2 more only if the owner says ok, never more than 3 a day. If the owner says they have not done it, that settles the item as NEED TO CREATE: offer to draft it for them, by a short series of questions, by scanning their work in this repo, or by scanning a website or other source they name. Drafts need the owner's approval before they are filed as fact.
8. **Big files live in `assets/` only.** If it is not text, it does not go in a tracked folder. Contents of `assets/`, `raw/`, `archive/`, `CONFIDENTIAL/`, and `trash/` are local-only under the master `.gitignore`; never try to commit them or route around it. A processed original that nothing references goes to `archive/`; if a finished note links to the file itself, the file lives in `assets/`.
9. Log what you changed in `today.md` under "Agent log". When you learn something durable about the owner, the business, or a person, update `memory.md` or the right `wiki/people/` file.
10. **Never schedule any job faster than every 30 minutes** unless the owner explicitly says to. Every scheduled run costs tokens out of the same bank the owner chats and works from, and runs set too fast repeat the same work while they drain it. Excessive runs can exhaust the bank entirely and leave the model with nothing for real work. Slower is the default; faster is the owner's explicit call only. If the day/night cadence is on in `memory.md`, respect the asleep window (default midnight to 6 AM): use the slow overnight interval from `agents/0-chief-of-staff/schedule.md` there, not the awake interval.

## Wiki voice and structure

- Default tone: clear, factual, terse.
- Preserve the owner's own phrasing when it carries signal. Do not sand everything into neutral encyclopedia tone.
- Headings only when the entry is long enough to need them. Bullets only when the content is genuinely a list.
- One topic per file. Kebab-case filenames.

## Out of scope

- Web browsing unless the owner explicitly asks.
- External API calls outside of declared automations.
- Anything touching accounts, payments, or auth.
- Editing files in `raw/` or `archive/`.
