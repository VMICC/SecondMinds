# Gemini

Work in this repo follows `AGENTS.md`. Read `memory.md` first.
When instructions conflict, `AGENTS.md` wins.
