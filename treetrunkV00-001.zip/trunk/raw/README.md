Incoming data, unprocessed. Drop anything here. The agent files it.
