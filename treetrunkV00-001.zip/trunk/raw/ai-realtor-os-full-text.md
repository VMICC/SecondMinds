# System AI Realtor OS: full extracted text

Source: the AI Realtor OS guide PDF (16 pages), extracted 2026-10-20. Page 1 is a cover image.

```
System
THE SYSTEM-POWERED AGENT

AI Realtor
OS
24 workflows. Your AI. Your business.

BUILT AROUND YOUR BUSINESS. POWERED BY YOUR PREFERRED AI.
SPHERE / PROSPECTING / LISTINGS / DAILY CONTROL

System

AI REALTOR OS

THE BIG IDEA

Let the system remember.
Keep the relationship human.
Use AI as a daily watching-and-drafting system: it surfaces a birthday, a lead signal, a
promise or a deadline, then prepares the draft and the next step. You stay the human.

HOW TO USE THIS GUIDE
01 Pick one job. Start with the task most likely to slip through the cracks.
02 Make it yours. Copy the prompt and fill in your farm, CRM and voice notes.
03 Check the output. Confirm names, dates and tone; correct the first draft.
04 Build the rhythm. Schedule the useful jobs daily, weekly or per listing.
YOUR WORKFLOW MAP

A

Sphere & client care

Pages 03-05

Cases 01-06

B

Find sellers & buyers daily

Pages 06-08

Cases 07-12

C

Listings & marketing

Pages 09-11

Cases 13-18

D

Inbox, deals & daily control

Pages 12-14

Cases 19-24

FOUR RULES TO KEEP

Draft before sending. Approve every post, DM, text and email. Show the source. Ask for a link or
screenshot reference. Protect client files. Share only what the job needs. Verify the details. Confirm
dates, prices and anything a client will rely on.

Use ChatGPT, Claude or your preferred AI. These are workflow templates, not built-in features. Connect authorized tools or
provide exports, screenshots and files. Confirm access and scheduling support before relying on scans or reminders. Never
claim to have reviewed data that is unavailable.

System / The AI Realtor OS guide

02 / 16

System

AI REALTOR OS

A / SPHERE & CLIENT CARE
Never miss the personal moment.

01

Find every client birthday this week - and draft the message

THE PROBLEM Birthdays sit in three places at once - Facebook, your CRM, and old closing files - so half your
past clients never hear from you.
WHAT AI CAN DO Cross-checks your Facebook friends list, CRM contacts, and past-client list for birthdays in
the next 7 days. Flags anyone with no birthday on file. For each person, drafts three versions: a short Messenger
message, an SMS version, and 2-3 lines you can copy onto a handwritten notecard. It notes one personal detail
per person (kids, neighborhood, closing year) so it does not sound mass-sent.
COPY + PASTE PROMPT

Every Monday, give me everyone in my sphere with a birthday in the next 7 days. For each person: name,
date, how I know them, and one personal detail from my notes. Draft a Messenger version (warm, 2
sentences), a text version (shorter), and a notecard version (handwritten length). Flag anyone I have no
birthday for so I can ask.

YOU GET Monday list + ready-to-send drafts
CHANNELS Messenger / SMS / Notecard

02

Watch your friends list for milestones - baby, job, engagement,
anniversary

THE PROBLEM A past client posts “we’re expecting!” or “new job, new city” and you see it three weeks late - or
never.
WHAT AI CAN DO Scans your friends’ and past clients’ recent posts for specific signals: new baby /
pregnancy, new job or promotion, engagement or wedding, work anniversary, retirement, graduation, and “we
moved” posts. It ignores reshares and memes. For each real milestone it drafts a personal message that
references the actual news - not “congrats!” - plus a notecard version for clients. If the milestone hints at a move
(new job in another city, growing family, empty nest), it flags that separately, without turning the congrats into a
pitch.
COPY + PASTE PROMPT

Scan my Facebook friends and past clients daily for life milestones: baby, pregnancy, new job, promotion,
engagement, wedding, anniversary, retirement, graduation. For each one, give me the person, the
milestone, the post link, and a draft personal message for Messenger plus a notecard version for past
clients. Flag any milestone that could mean a move - separately, do not pitch in the congrats.

YOU GET Daily milestone list with links + drafts
CHANNELS Messenger / Notecard / SMS

System / The AI Realtor OS guide

03 / 16

System

AI REALTOR OS

A / SPHERE & CLIENT CARE
Never miss the personal moment.

03

Home anniversary: the “you’ve been here 1 / 3 / 5 years” touch

THE PROBLEM Closing dates are in your files, but nobody gets a note on the day they actually moved in - the
easiest referral touch of the year.
WHAT AI CAN DO Pulls closing dates from your past-client list and builds a rolling 30-day calendar of home
anniversaries. For each one it drafts a message with the street name, the year they bought, and one useful
add-on: a current home-value range prompt (“want me to run what it is worth now?”), a vendor reminder, or a
neighborhood update. Marks 1-year, 5- year, and 10-year anniversaries for a notecard or small gift instead of a
text.
COPY + PASTE PROMPT

From my past-client list, show me home anniversaries in the next 30 days. For each: client, address,
closing date, years in the home. Draft a text for most, and a notecard for 1, 5, and 10-year anniversaries.
End each draft with one soft offer - a home value update or a trusted vendor intro - not a sales pitch.

YOU GET 30-day anniversary calendar + drafts
CHANNELS SMS / Notecard / Email

04

The no-reason check-in for past clients who have gone quiet

THE PROBLEM You have 80+ past clients you have not contacted in 6 months. A generic “just checking in”
feels salesy, so you send nothing.
WHAT AI CAN DO Sorts past clients by last contact date and drafts a different, specific opener for each
person based on their file: their neighborhood, their street, a local opening or sale nearby, their kids’ school
area, or the home feature they loved. Rotates 10 people per week so the list actually gets worked. Tracks who
replied so nobody gets the same touch twice.
COPY + PASTE PROMPT

Give me 10 past clients I have not contacted in 6+ months, longest gap first. For each, draft a short text
that opens with one specific detail about them or their neighborhood - never ‘just checking in’ and never
mention the market unless their street had a recent sale. Keep it under 3 sentences.

YOU GET 10 names/week + individual drafts
CHANNELS SMS / Messenger

System / The AI Realtor OS guide

04 / 16

System

AI REALTOR OS

A / SPHERE & CLIENT CARE
Never miss the personal moment.

05

Sympathy and hard-moment messages - drafted fast, in your voice

THE PROBLEM Someone in your sphere posts about a loss, an illness, or a parent moving to care. You want to
say the right thing and you freeze - so you say nothing.
WHAT AI CAN DO When the milestone scan (Case 02) finds a hard moment, it separates it from the
celebrations and drafts a short, non-business message: no real estate, no offer, no follow-up ask. Offers a
notecard version, because a card lands differently than a DM here. You review the tone before anything goes out
- always.
COPY + PASTE PROMPT

If you find a loss, illness, or difficult family post in my sphere, put it in a separate ‘care’ list. Draft a brief,
warm message with zero business in it, plus a notecard version. Do not suggest any follow-up or offer. I
will review every word before sending.

YOU GET Separate care list + careful drafts
CHANNELS Notecard first / Messenger

06

Ask for the review and the referral - at the moment they are
happiest

THE PROBLEM The best review window is the week after closing or after you solved a problem. By the time you
remember to ask, the glow is gone.
WHAT AI CAN DO Watches for trigger moments: 7 days post-closing, a closed inspection issue, a milestone
reply, a home-anniversary reply. Drafts the ask with the specific good outcome named (“so glad the radon retest
came back clean”), includes the direct review link, and drafts the separate referral version for when they reply
with thanks. Never sends both asks in one message.
COPY + PASTE PROMPT

When a client closes, remind me on day 7 to ask for a review. Draft the ask naming one specific thing that
went well in their deal, include my review link, and keep it to 3 sentences. If they reply warmly, draft a
separate, soft referral ask - do not combine them.

YOU GET Timed reminder + two staged drafts
CHANNELS SMS / Email

System / The AI Realtor OS guide

05 / 16

System

AI REALTOR OS

B / FIND SELLERS & BUYERS DAILY
Turn useful signals into thoughtful conversations.

07

Scan local Facebook groups for “I need an agent” posts

THE PROBLEM Buyers and sellers ask for agent recommendations in neighborhood and mom groups every day.
The first helpful comment usually gets the conversation.
WHAT AI CAN DO Scans your named local groups for exact signal phrases: “looking for a realtor,”
“recommend an agent,” “first-time buyer,” “thinking of selling,” “need a bigger house,” “relocating to [town].”
Returns each post with the link, what they actually need, a draft public comment in your voice (helpful first, pitch
last), and a follow-up DM draft for if they reply - plus which lead magnet fits (buyer guide, home-value check,
farm report).
COPY + PASTE PROMPT

Scan [group names] daily for posts containing: looking for a realtor, recommend an agent, first-time
buyer, thinking of selling, relocating, need more space. For each: link, poster name, what they need in
one line, a draft comment that answers helpfully first, and a DM draft if they engage. Suggest the right
lead magnet for each. Skip agent-to-agent posts.

YOU GET Daily lead list with links + comment & DM drafts
CHANNELS Post comment / Messenger

08

Daily FSBO pull - with a first outreach that is not a script from
2011

THE PROBLEM For-sale-by-owner listings appear across Zillow, Facebook Marketplace, and local groups. By the
time you find them, three agents have already pitched them.
WHAT AI CAN DO Builds a daily FSBO list for your farm: address, asking price, days listed, where it was found,
and any price drop. Drafts a first touch that leads with help - a specific observation about their listing (missing
detail, photo order, pricing vs. a recent nearby sale) - and a day-7 follow-up if the price drops or the listing goes
stale. Logs who you have already contacted so you never double-pitch.
COPY + PASTE PROMPT

Give me today’s FSBOs in [farm / zip codes] from [sources]. For each: address, price, days on market,
source link, and one specific, helpful observation about their listing. Draft a short first outreach using that
observation and a separate follow-up for a price drop. Track who I have contacted.

YOU GET Daily FSBO sheet + two drafts per listing
CHANNELS Messenger / SMS / Email

System / The AI Realtor OS guide

06 / 16

System

AI REALTOR OS

B / FIND SELLERS & BUYERS DAILY
Turn useful signals into thoughtful conversations.

09

Daily expired listings - sorted by “likely to relist”

THE PROBLEM Expireds are public the same morning for every agent. Calling in MLS order wastes your best
hour on homes that will never relist.
WHAT AI CAN DO Pulls the day’s expired and cancelled listings in your farm and ranks them: equity likely,
only one listing period, no price reduction history (priced wrong, not unwanted), and not already relisted. For the
top tier, drafts a letter / email / call opener that names the likely reason it did not sell - price, photos, showing
access - without trashing the prior agent.
COPY + PASTE PROMPT

Pull today’s expired and cancelled listings in [farm]. Rank them by likelihood to relist and tell me why for
each. For the top 5, draft an outreach that names one likely reason it did not sell and one concrete thing I
would do differently. No criticism of the previous agent.

YOU GET Ranked expired list + top-5 drafts
CHANNELS Letter / Email / Call opener

10

Spot the “we have outgrown this house” posts in your own feed

THE PROBLEM Your existing friends post the real signals - twins on the way, working from home in the kitchen,
in-laws moving in - weeks before they ever search for an agent.
WHAT AI CAN DO Watches your friends feed (separate from Case 02 milestones) for space and life-change
language: outgrowing, bursting at the seams, need a home office, parents moving in, kids leaving for college,
divorce mentioned by the person themselves. Returns the post link and a human-first draft: react to the life
news first. Only if they reply about housing does it draft a second, separate follow-up.
COPY + PASTE PROMPT

Watch my friends feed for posts suggesting a housing change: outgrowing the house, new baby,
work-from-home space, parents moving in, empty nest. Give me the link and a draft that responds to the
life news only. Draft a housing follow-up separately, for me to use only if they bring up moving.

YOU GET Early-signal list + two-stage drafts
CHANNELS Messenger / Comment

System / The AI Realtor OS guide

07 / 16

System

AI REALTOR OS

B / FIND SELLERS & BUYERS DAILY
Turn useful signals into thoughtful conversations.

11

New movers in your farm - welcome them before anyone else does

THE PROBLEM New homeowners in your farm need vendors, schools info, and a local agent to know - and the
first agent to be useful usually becomes their agent.
WHAT AI CAN DO From recent closings / new-listing-sold data in your farm, builds a weekly new-mover list.
Drafts a welcome notecard that is pure local value: trash day, best coffee, one seasonal tip, and your vendor list
offer. No listing pitch. Also drafts the 60-day follow-up (“settled in? here is what neighbors ask me most”).
COPY + PASTE PROMPT

Build a weekly list of homes that closed in [farm] in the last 7 days where I was not the agent. Draft a
welcome notecard for each: one local tip, one seasonal tip, and an offer to share my vendor list. No
sales pitch. Also draft a 60-day check-in version.

YOU GET Weekly mover list + welcome & 60-day drafts
CHANNELS Notecard / Door drop

12

Turn your Instagram engagers into a follow-up list

THE PROBLEM People save your market posts, watch every Story, and ask questions in comments - and you
never turn that attention into a conversation list.
WHAT AI CAN DO Reviews your recent posts and Stories for repeated engagers: saves, shares, poll votes, and
housing questions. Ranks them by frequency, separates real local accounts from brands and bots, and drafts a
DM opener tied to the exact post they engaged with. Also gives you a daily shortlist of 3 local accounts worth
following back (builders, lenders, local businesses, active buyers) with the reason for each.
COPY + PASTE PROMPT

Review my last 14 days on Instagram. List people who engaged more than once, what they engaged with,
and whether they look local and real. Draft a DM for the top 5 that references the exact post. Separately,
suggest 3 accounts to follow today and why each is strategic.

YOU GET Ranked engager list + DM drafts + 3 follows/day
CHANNELS Instagram DM

System / The AI Realtor OS guide

08 / 16

System

AI REALTOR OS

C / LISTINGS & MARKETING
One input. Every version you need.

13

Write the listing description from the MLS sheet + photos without inventing facts

THE PROBLEM Listing copy takes an hour, drifts into cliches, and risks claiming a feature the home does not
have.
WHAT AI CAN DO Takes the MLS fact sheet and the photo set and writes three lengths: full MLS description, a
short version for portals, and a social caption. It may only use facts on the sheet or visible in photos - it must flag
anything it is unsure about instead of guessing. Leads with the buyer’s life in the home (light, layout, yard,
commute) and names the street and neighborhood specifics.
COPY + PASTE PROMPT

Using only this MLS fact sheet and these photos, write my listing copy in 3 lengths: MLS, portal-short, and
social. Do not invent any feature, finish, or measurement - flag anything unclear with [VERIFY]. Lead with
how the home lives, not a room-by-room list.

YOU GET 3 copy lengths + [VERIFY] flags
CHANNELS MLS / Portals / Social

14

Just Listed / Just Sold pack - every asset from one listing

THE PROBLEM One listing needs a post, a Story, an email, a postcard, and a neighbor letter - so half of them
never get made.
WHAT AI CAN DO From one listing, produces the full pack in your voice: Facebook post, Instagram caption +
Story text, email to your sphere, postcard front/back copy, and a “your neighbor just listed/sold” letter for the
surrounding streets. For Just Sold, it drafts the seller thank-you post (with permission) and the “what this sale
means for your value” version for neighbors.
COPY + PASTE PROMPT

From this listing, build the full pack: Facebook post, Instagram caption and Story text, sphere email,
postcard copy (front and back), and a neighbor letter. Keep my voice, use only verified facts, and give me
a posting checklist with the order and timing.

YOU GET 5 assets + checklist per listing
CHANNELS Social / Email / Postcard / Letter

System / The AI Realtor OS guide

09 / 16

System

AI REALTOR OS

C / LISTINGS & MARKETING
One input. Every version you need.

15

Repurpose one good post into a week of content

THE PROBLEM You write one strong market post and it dies in a day, while your feed sits empty the rest of the
week.
WHAT AI CAN DO Takes your best-performing post (or a listing, a closing story, or a client question) and
breaks it into: a short video script (hook + 3 points + close), a carousel outline, a Story poll sequence, an email
version, and a group-discussion version written to start comments in agent or community groups. Each version is
rewritten for its surface - not copy-pasted.
COPY + PASTE PROMPT

Take this post and repurpose it into: a 45-second video script, a carousel outline, a Story poll sequence,
an email version, and a discussion post for a group. Rewrite for each surface, keep my point of view, and
end each version with one clear next step for the reader.

YOU GET 5 versions from 1 idea
CHANNELS Video / Social / Email / Groups

16

Open house follow-up - every sign-in gets a personal note within
24 hours

THE PROBLEM Sign-in sheets sit in your bag for three days. A generic “thanks for coming” to 20 people
converts nobody.
WHAT AI CAN DO Takes a photo of the sign-in sheet (or the list) and sorts visitors into buyers without an
agent, neighbors, and browsers from what they wrote or said. Drafts a personal follow-up for each group
referencing one detail from the open house (“you asked about the basement finish”), plus a seller recap: traffic
count, best comments, objections heard, and recommended next step.
COPY + PASTE PROMPT

From this open house sign-in sheet and my notes, sort visitors into unrepresented buyers, neighbors, and
browsers. Draft a personal follow-up for each person using one detail they mentioned. Then draft my
seller recap: traffic, top positive comments, top objections, and your recommended next move.

YOU GET Sorted list + per-person drafts + seller recap
CHANNELS SMS / Email

System / The AI Realtor OS guide

10 / 16

System

AI REALTOR OS

C / LISTINGS & MARKETING
One input. Every version you need.

17

Chase showing feedback - so sellers hear it from you, not silence

THE PROBLEM Showing agents do not return feedback unless chased twice, and sellers interpret silence as
failure.
WHAT AI CAN DO Tracks every showing on your listings, notes which agents owe feedback after 24 hours,
and drafts the chase: a short text, then a second, warmer nudge, then a call opener. As feedback lands, it
compiles it into a seller-ready summary that groups comments into price, condition, and layout - with the exact
quotes separated from the interpretation, so you can have the price conversation with evidence.
COPY + PASTE PROMPT

Track showings on my listings. At 24 hours with no feedback, draft a short chase text to the showing
agent; at 48 hours, draft a second nudge. Compile all feedback into a seller summary grouped by price,
condition, and layout, with direct quotes kept separate from your summary.

YOU GET Chase drafts + grouped seller summary
CHANNELS SMS to agents / Email to seller

18

Build the ad campaign brief - copy, audience, and budget in one
pass

THE PROBLEM Running an ad means writing copy, picking photos, defining the audience, and setting the
follow-up - four jobs, so the ad never launches.
WHAT AI CAN DO From a listing or a lead magnet, drafts the complete campaign brief: 3 headline options,
primary text in 2 tones, photo order, audience definition (geo + life-stage signals), daily budget split, and - most
important - the follow-up sequence for anyone who clicks or comments: first DM, day-2 value add, day-5
check-in. You still launch it in Ads Manager yourself and approve every follow-up.
COPY + PASTE PROMPT

Build a campaign brief for this [listing / lead magnet]: 3 headlines, 2 versions of ad text, photo order,
audience definition for [farm], a starter budget, and a 3-step follow-up sequence for commenters and
clickers. Draft the follow-ups, do not send them.

YOU GET Launch-ready brief + follow-up drafts
CHANNELS Meta ads / Messenger

System / The AI Realtor OS guide

11 / 16

System

AI REALTOR OS

D / INBOX, DEALS & DAILY CONTROL
Bring the details into one daily view.

19

Triage the inbox into “urgent / today / file it” - with drafts
attached

THE PROBLEM 100+ emails hide the three that matter: a new offer, a buyer inquiry on a cancelled listing, a
title company that cannot match a check.
WHAT AI CAN DO Sorts new mail into Urgent (offers, counters, deadlines, transaction problems, new
buyer/seller inquiries), Today (scheduling, showing confirmations, client questions), and File (MLS copies,
promos, newsletters). Every Urgent and Today item comes with a draft reply you can approve or edit, addressed
to the correct person - including the classic trap: when the listing contact is out of the country and the
coordinator is the one who actually needs the document.
COPY + PASTE PROMPT

Triage my inbox into Urgent, Today, and File. Urgent means: offers, counters, deadlines, transaction
issues, and new buyer or seller inquiries. For every Urgent and Today item, draft my reply and name the
exact recipient it should go to. File the rest by listing or buyer. Never send without my approval.

YOU GET 3-bucket digest + reply drafts
CHANNELS Email

20

Clean the CRM: find the duplicates before they embarrass you

THE PROBLEM The same client exists three times - phone only, email only, and under a spouse’s name - so
they get two postcards and no birthday message.
WHAT AI CAN DO Scans your CRM export for likely duplicates: same phone, same email, same address, name
variations, and spouse pairs. Returns a merge proposal list showing exactly what will be kept and what will be
combined - and changes nothing until you approve the list. Also flags contacts missing a birthday, a home
anniversary, or an address, as a fill-in list you can work 10 at a time.
COPY + PASTE PROMPT

Review this CRM export for duplicates by phone, email, address, and name variation, including spouses.
Give me a merge list showing the record you would keep and what merges into it. Change nothing until I
approve. Also list contacts missing a birthday, address, or closing date.

YOU GET Approval-first merge list + gaps list
CHANNELS CRM

System / The AI Realtor OS guide

12 / 16

System

AI REALTOR OS

D / INBOX, DEALS & DAILY CONTROL
Bring the details into one daily view.

21

Transaction deadline tracker - earnest money, inspection, radon,
closing

THE PROBLEM Every deal has 6-10 dates in different emails and contracts. The missed one - earnest money
due, inspection notice, pickup time - is the expensive one.
WHAT AI CAN DO From the contract and the email thread, builds one deadline sheet per deal: earnest money
due (counting business days correctly), inspection and notice deadline, radon / test pickup windows, appraisal,
closing date, and who owes what to whom (receipt photo to the listing agent, signed form back to title,
document resent directly to the coordinator). Flags anything unconfirmed within 48 hours of its deadline and
drafts the chase message for that exact person.
COPY + PASTE PROMPT

For this transaction, build a deadline sheet from the contract and emails: earnest money, inspection and
notice dates, any test pickup windows, appraisal, and closing - with who owes what to whom. Flag
anything unconfirmed 48 hours out and draft the chase message to the right person.

YOU GET One deadline sheet per deal + chase drafts
CHANNELS Email / SMS

22

Turn a 40-page inspection report into a one-page plain-English
brief

THE PROBLEM Inspection reports are 40+ pages of photos and codes. Your buyer is anxious, the notice
deadline is today, and nobody has time to read it properly.
WHAT AI CAN DO Reads the full report and returns: (1) Safety items (electrical, GFCI, detectors, egress,
water-heater venting) in plain words, (2) Real repairs worth knowing, (3) What is the HOA / seller / shared
responsibility, and (4) What is normal for the age of the home. Ends with the decision framed clearly: which 2-3
items are the strongest inspection-notice asks, and what happens if the deadline passes. It summarizes - it does
not give legal advice, and it keeps the inspector’s findings separate from its plain-English translation.
COPY + PASTE PROMPT

Summarize this inspection report in plain English: safety items first, then real repairs, then what belongs
to the HOA or others, then what is normal for a home this age. End with the 2-3 strongest items for an
inspection notice and note today’s notice deadline. Keep the inspector’s findings separate from your
summary.

YOU GET 1-page brief + decision frame
CHANNELS Email to client / Attorney

System / The AI Realtor OS guide

13 / 16

System

AI REALTOR OS

D / INBOX, DEALS & DAILY CONTROL
Bring the details into one daily view.

23

Compare competing offers side by side - for the seller call

THE PROBLEM One offer is signed at a lower price with a qualified buyer; another is higher but still verbal.
Presenting that clearly - without mislabeling either one - is where deals get messy.
WHAT AI CAN DO Builds a clean comparison from the actual documents: price, earnest money, financing type
and qualification evidence, credits / buydowns, contingencies, closing date, and status stated exactly - signed
vs. verbal vs. promised. Drafts your seller presentation message and, if you need it, a fair “best and final by
[time]” message to the other buyer’s agent that does not disclose the other offer’s price. Never calls an
unsigned offer binding or a backup unless you say it is.
COPY + PASTE PROMPT

Compare these offers side by side: price, earnest money, financing and proof of qualification, credits,
contingencies, closing date, and exact status (signed, verbal, or promised). Draft my seller summary and
a separate message to the other agent setting a written-offer deadline without revealing the other price.
Do not label anything binding or backup unless I say so.

YOU GET Comparison sheet + seller draft + agent draft
CHANNELS Email / Call notes

24

The morning trigger brief + commitment capture

THE PROBLEM Your day starts scattered: a DM promise here, a showing there, a lead from last night, a
deadline today - and two of them fall through the cracks by noon.
WHAT AI CAN DO Every morning, one brief: (1) Triggers from the last 24 hours - comments on your posts,
group mentions, DMs, milestone hits (Cases 01-02, 07, 10) each with a draft reply; (2) Deals needing you today
(Case 21 deadlines); (3) Commitments captured - anything you said you would do in any conversation, turned
into a task with a date. If a category is empty, it says so plainly instead of padding the brief. This is the job that
runs all the others.
COPY + PASTE PROMPT

Every morning, brief me in one message: (1) conversation triggers from the last 24 hours with a draft
reply for each, (2) transaction deadlines due today or unconfirmed, (3) every commitment I made in
messages or email, turned into a dated task. If a section is empty, say ‘nothing new’ - do not fill it.

YOU GET One morning brief + task list
CHANNELS Chat / Email digest

System / The AI Realtor OS guide

14 / 16

System

AI REALTOR OS

START SMALL. BUILD MOMENTUM.

Install four jobs this week.
Pick the job that costs you the most time or goodwill, then put it on a schedule.

Birthdays + milestones
DAY 1

Cases 01 + 02. Fastest goodwill, easiest to verify.

Local group lead scan
DAY 2

Case 07. One focused list for your farm.

Inbox triage with drafts
DAY 3

Case 19. Feel the difference the same morning.

One morning trigger brief
DAY 4

Case 24. Pull the first three jobs into a single view.

Week 2: Add a listing job (13 or 14) and a deal job (21 or 22).
Week 3: Add CRM cleanup (20) and a prospecting job (08 or 09).

A SIMPLE OPERATING RHYTHM

Daily: 24, 02, 07, 19 Monday: 01, 03, 04
Per listing: 13, 14, 17 Per contract: 21, 22, 23
Weekly: 11, 12, 15 Monthly: 20

System / The AI Realtor OS guide

15 / 16

System

AI REALTOR OS

COPY. CUSTOMIZE. START.

Your master starter prompt
THE MASTER STARTER PROMPT

First confirm your available tools, data access and scheduling support. If a source is
unavailable, ask me for an export or file; never claim you scanned it. Build my Realtor OS as a
daily watching-and-drafting system, not one-off tasks. Goal: no birthday, milestone, lead
signal, or transaction deadline depends on my memory. Start with these four jobs in order: (1)
a Monday birthday and daily milestone scan of my sphere with a drafted message for
Messenger, text, and notecard; (2) a daily scan of my local Facebook groups for people who
need an agent, each with the link and a draft comment; (3) inbox triage into Urgent / Today /
File with a draft reply for every Urgent and Today item; (4) a single morning brief that
combines the first three plus today’s transaction deadlines. Draft everything for my approval never post, message, or email as me without my exact go-ahead, keep client information
confidential, and show me the source link for every item you surface.

Keep approval built in.
The source thread describes agents who regretted letting AI post, message or access client documents
without limits. Keep the approval gate on everything for the first month. The point is to catch the moment in
your own voice.

YOUR NEXT STEP

Need a system that runs your geographic
farming and past client retention?
The System brings your CRM, direct mail and follow-up together, so you can stay visible in your farm
and stay connected with past clients. From birthday and home-anniversary touches to ongoing
nurture, build a business that keeps showing up when you get busy.

See how the System works

System / The AI Realtor OS guide

the System site

16 / 16
```
