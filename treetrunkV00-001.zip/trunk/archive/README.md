Processed originals. Nothing here is deleted, ever.
