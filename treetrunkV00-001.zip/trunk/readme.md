# trunk

One folder, everything in its place. This is my AI brain: a single folder
tree that I and my AI agent keep current together.

## First run

Open this repo with your AI and it interviews you:
`prompts/first-run-interview.md`. It does not start with questions. First
it imports what your other AI tools already remember: drop the exports in
`raw/` (or say "none" and skip straight to questions). It runs the
translate prompt over them, silently pre-fills every question as found,
partial, or missing, verifies the found answers with you instead of
re-asking them, and then asks only what is missing: 37 questions across who you
are, your voice, what makes you different, your ideal client, your real
stories, your clients' exact words, your market, your proof, and your
guardrails. Answers land in named wiki files (identity, brand voice, how
I work, ideal client, story bank, client words, market, proof,
guardrails, people). Anything you do not know is registered as
UNFINISHEDWORK and comes back one per day in the morning brief, and the
interview finishes by seeding your Master Task List (`tasks.md`) with
the projects and open loops you named. At startup, before the
interview, the agent offers to wire the two schedules (the translate
sweep and the morning brief), and offers again at every startup until
they exist; wiring them flips `Schedules wired` to YES in `memory.md`.
It can be re-run any time; confirmed answers are
never asked twice. After that, the loop below is the whole system.

## The flow

1. Everything new lands in `raw/`: notes, screenshots, exports, transcripts.
2. The agent runs the prompt in `prompts/translate.md`: raw material becomes clean, permanent notes in `wiki/`.
3. Processed originals move to `archive/`. Nothing is ever deleted.

The whole folder is a git repo, so nothing is ever lost.

## The rules

- One file per thing: one listing, one client, one project.
- Filenames start with the date when time matters: `2026-10-20-topic.md`.
- `memory.md` is read first, every session. Keep it short and current.
- Procedures live in `sops/`, one page each.
- Money lives in `money/`. Restricted material lives in `CONFIDENTIAL/`
  and nowhere else.
- Big files go in `assets/`. Unprocessed files stay in `raw/` and never upload.
- Answers the owner does not know yet are never skipped and forgotten: they are tagged UNFINISHEDWORK and listed in `unfinished-work.md`, and one comes back per day in the morning brief.
- Tasks live in exactly two places: today's ranked ABC list in `today.md`, and everything else in the Master Task List, `tasks.md`. Tasks move between them by forwarding symbols (✓ X → ←), never by deletion. Method: `sops/agent/task-forwarding.md`.

## One source of truth

`AGENTS.md` is the canonical instruction file. Every major AI tool reads it
(Codex/GPT, Muse, Grok, Cursor), so the real rules live there and only there.

Tools that insist on their own filename get a pointer stub instead of a copy:
`CLAUDE.md` for Claude Code, `GEMINI.md` for Gemini. Each stub is two lines
("follow agents.md") so there is nothing in them to go stale. Never copy the
full instructions into a second file; parallel versions drift.

Why stubs and not symlinks: symlinks are cleaner, but they break when the
repo is zipped and a student unzips it on Windows. For a hand-out repo,
stubs win.

## Local-only, by design

Git carries text. One master `.gitignore` at this root keeps everything
heavy or restricted on this machine only: the contents of `assets/`,
`raw/`, `archive/`, and `CONFIDENTIAL/` never upload (each folder's README
does, so the folder explains itself in the repo), and neither do heavy file
types anywhere else (PDF, video, audio, Office files, zips). Unprocessed
files in `raw/` especially never go up. Your AI tools read your local disk,
not GitHub, so ignored files work exactly like tracked ones locally. If it
is not text, it belongs in `assets/`. Files a finished note points at live
in `assets/`; processed originals that nothing references live in `archive/`.

## Back up the local-only folders (owner: do this once)

Git never sees `assets/`, `raw/`, `archive/`, `CONFIDENTIAL/`, or `trash/`, so git is
not their backup. (`trash/` is deliberately left out of the backup itself: it is trash.) Before you put anything real in them, point a backup at
the trunk folder: the dumbest way is your normal computer backup (Time
Machine on a Mac, File History or Backblaze on Windows) with trunk
included, or sync the trunk folder with Google Drive, iCloud, or Dropbox.
Then check once that the four folders are actually in the backup. If this
machine dies, git rebuilds the text; only your backup rebuilds the
originals.

## Layout

- `manifest.md` (root) the inventory: every root file and folder, one line each. New parts get a line there when they are created.

- `agents/` the AI team: five chiefs (0 Chief of Staff, 1 Operations, 2 CFO, 3 Marketing-Sales, 4 Client-Experience), each with `soul.md`, `identity.md`, a charter `agents.md`, and its own specialists, guides, and skills. Skills and playbooks belong to exactly one chief and are never shared. Full catalog: `agents/README.md`.
- `assets/` large files (images, PDFs, media, originals). Local only.
- `raw/` incoming data, unprocessed. Contents local only.
- `wiki/` AI-managed knowledge (brand, people, business)
- `sops/` approved procedures (buyer, seller, agent, prospecting, social-media)
- `projects/` active work
- `prompts/` reusable AI instructions (including `translate.md`, the raw-to-wiki loop, and the Master Starter Prompt)
- `skills/` empty on purpose: skills live with their owning chief under `agents/`
- `archive/` processed originals. Contents local only.
- `money/` income, expenses, property
- `CONFIDENTIAL/` restricted information. Contents local only.
- `trash/` the bucket for removed files, date-prefixed. Contents local only; only the owner empties it.
