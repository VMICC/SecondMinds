# Tasks: Master Task List

Everything not scheduled today lives here. Today's ranked list lives
in `today.md`. Method: `sops/agent/task-forwarding.md`.

Symbols: ✓ done · X canceled · → forwarded to tomorrow · ← deferred
back to this list or a future month.

Line format: `- [ ] Task · role or chief · horizon · added YYYY-MM-DD`

## This week (top priorities by role)

_Nothing scheduled yet._

## Master list (not scheduled)

_Nothing here yet. New tasks land here first, then get scheduled into
a week or a day._

## Later (parked by month)

_Nothing parked. Deferred items land here under their month heading,
for example `### November 2026`._

## Closed this month

_✓ and X items are logged here with their dates at rollover. The log
moves to `archive/monthly/` at the month rollover._
