Restricted information. Do not copy contents into other folders.
