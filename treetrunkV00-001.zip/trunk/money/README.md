The money, all in one place. Records live here; the CFO chief (`agents/2-cfo/`) does the work on them.
