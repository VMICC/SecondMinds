Per-property numbers: flips, rentals, listings with costs.
