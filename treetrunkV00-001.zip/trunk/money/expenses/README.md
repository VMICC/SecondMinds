Business expenses, for taxes and tracking.
