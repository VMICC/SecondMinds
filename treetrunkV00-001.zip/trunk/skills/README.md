Skills live with their owning chief under `agents/` and are never shared between chiefs. This folder stays empty on purpose: if a skill does not belong to one chief, it does not belong here either.
