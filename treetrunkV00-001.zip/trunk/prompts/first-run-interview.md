# First-Run Interview

For a licensed real estate agent in the United States setting up a Memory-Tree.
Generic by design: no state, no brokerage, and no firm is assumed. The agent
specifies all of that in their own answers.

## What this does

This interview turns a blank Memory-Tree into this agent's brain.

It does not start with questions. It starts with what the agent already has.
Material they exported from other AI tools usually answers half of this
interview before a single question is asked. So the order is fixed:

1. **Import first.** The agent drops their exported files into `raw/`.
2. **Ingest.** The AI runs the prompt in `translate.md` over `raw/`.
3. **Scan.** The AI checks the whole repository for answers that are already there.
4. **Verify.** Found answers are shown back to the agent for confirmation, not asked again from scratch.
5. **Ask only what is missing.** One question at a time.

## Running this again later

**This interview can be run again at any time. It will not ask questions that are already confirmed and answered.**

Every answer the AI writes down carries one tag:

- `[confirmed YYYY-MM-DD]` the agent said it and confirmed it
- `[imported, not yet verified]` it came from a file, the agent has not confirmed it yet
- `[skipped]` the agent chose to skip it
- `[open]` not asked yet, or no usable answer yet

A gap the agent cannot fill gets a different kind of tag. It is not an
answer state and it is never treated as one:

- `[UNFINISHEDWORK: NOT KNOWN]` the agent does not know yet; it needs
  finding, checking, or deciding
- `[UNFINISHEDWORK: NEED TO CREATE]` it does not exist yet; it has to
  be made

Every unfinished item is also registered in `unfinished-work.md` at
the repo root. From there it comes back one per day in the morning
brief (up to 2 more only if the agent says ok), until it is answered
and re-tagged `[confirmed]`. `[skipped]` means the agent chose not
to. Unfinished means they want it and cannot answer it yet.

On a re-run, the AI:

1. Scans the repository for those tags before asking anything.
2. **Skips every `[confirmed]` question entirely.** It does not re-ask it, rephrase it, or ask it in a different section.
3. Works only on what is `[open]`, `[skipped]` if the agent wants to revisit it, or `[imported, not yet verified]`.
4. If the agent says something has changed, it shows the old confirmed answer, asks for the new one, and re-tags it with the new date. The old answer is replaced only after the agent confirms the new one.
5. Ends with a short list of what changed in that run. If nothing was open, it says so and stops.

## Rules for the AI running this interview

- One question at a time. Wait for the answer before asking the next one.
- Write each answer down as you go, with its tag and date, so nothing is lost if the session ends early.
- Never ask for anything already confirmed in the repository. Check first.
- Imported material outranks asking. If a file already answers it, verify it instead of asking it.
- Never treat imported or inferred material as fact. It stays `[imported, not yet verified]` until the agent confirms it.
- "Skip" is always a valid answer. Tag it `[skipped]` and move on.
- "I don't know" is always a valid answer too. Tag the gap `[UNFINISHEDWORK: NOT KNOWN]` or `[UNFINISHEDWORK: NEED TO CREATE]`, register it in `unfinished-work.md`, and move on. Do not press, do not guess, and do not fill it in from imported material without verification.
- If the answer is "I haven't done that," the item is NEED TO CREATE. Offer to draft it for them later, three ways: a short series of questions, a scan of their work in this repo, or a scan of a website they name. The offer rides along when the item resurfaces in the morning brief; it is not a separate conversation during the interview. A draft is saved only after the agent approves it, and anything the scan could not support stays a marked gap.
- Never invent: stories, testimonials, client quotes, sales numbers, results, years of experience, credentials, awards, transaction details, or anything about competitors. If it does not exist yet, write the placeholder: **Add real material here later.**
- A short real answer beats a long polished one. Three real stories beat five made-up ones.
- If the agent is new, do not make them sound inexperienced or apologetic, and do not invent experience for them. Position what is true: availability, responsiveness, preparation, current market knowledge, and direct attention.
- Do not ask for passwords or account access. Do not give legal or compliance advice. Brokerage policy and state rules come from the agent and their brokerage.
- Anything the agent marks private does not go into the shared wiki files. Put it in `CONFIDENTIAL/` if that folder exists, and note only that it exists.
- Keep brand voice and compliance as two separate things. Compliance is a filter you check work against. It is not the voice.

## Writing defaults (confirm in Section C, then follow everywhere)

Write like you are talking to one person, not an audience.

- Normal language. Contractions. Mixed sentence lengths. Direct statements.
- Simple words a busy person gets on the first read.
- Say it once, clearly, and move on. Do not over-explain or repeat an idea three ways.
- Do not use: leverage, utilize, unlock, transformative, cutting-edge, seamless, robust, optimize.
- Do not use stiff openers such as: "In conclusion," "Let's explore," "It's important to note," "The reality is," "Here's the truth."
- No em dashes. Use a period, a comma, a colon, or parentheses.
- Final check on anything client-facing: would this person actually say this out loud to a client or a friend? If not, rewrite it.

---

## Step 1: Import your existing AI memory

**AI: do not ask any interview questions before this step is offered.**

Say this to the agent, in plain words:

> Before we start, let's not make you repeat yourself. If you have used
> ChatGPT, Claude, Gemini, or any other AI tool, export or copy what it
> remembers about you and your business, and drop those files into the
> `raw/` folder in this project. Good things to include:
>
> - Memory or "about me" exports from any AI tool
> - A bio, resume, or About page you already wrote
> - Past listing presentations, buyer or seller guides, or marketing pieces
> - Testimonials and reviews you already collected
> - Notes about your clients, your market, or how you work
> - Anything else that already describes you or your business
>
> Tell me when the files are in `raw/`, or say "none" and we will go
> straight to the questions.

If the agent says "none," tag Step 1 `[skipped]` and go to Step 3, Section A.

When files are in `raw/`, go to Step 2.

## Step 2: Run translate.md, then scan

1. Run the prompt in `translate.md` over everything in `raw/`, following that file's rules. Processed files move out of `raw/` the way `translate.md` directs. Never delete anything.
2. Then scan the whole repository (`wiki/`, project files, and anything `translate.md` just created) and build a **pre-fill list** for every question below. For each question, record one of these:
   - **Found:** the answer is in the repository. Note which file it came from.
   - **Partial:** part of the answer is there. Note what is still missing.
   - **Missing:** nothing usable is there.
3. Do not show the agent the whole pre-fill list at once. Use it silently in Step 3.
4. Tag everything found in this step `[imported, not yet verified]` until the agent confirms it in Step 3.

## Step 3: Verify first, then ask what is missing

Go section by section, in the order below. For each question:

- **If it was Found:** do not ask the question. Show the found answer in a short form and ask one thing: "I found this, is it still right?" The agent can confirm, correct it, or skip it. Confirmed answers get tagged `[confirmed]` with today's date and written to the file listed in the table at the end.
- **If it was Partial:** show what was found, confirm that part, then ask only for the missing part.
- **If it was Missing:** ask the question, one at a time.

That is the whole method for every section below. The questions are the
checklist, not a form to fill in from the top.

---

### Section A: You and your license (5 questions)

1. What is your full name, and what should I call you?
2. What market do you serve? Name the cities, towns, neighborhoods, counties, or farm areas you work. Be as specific as you actually work, not as wide as you could.
3. What state or states are you licensed in, what brokerage are you with, and are you solo, on a team, or leading a team? (You supply this. Nothing is assumed.)
4. What is your timezone?
5. How long have you been in real estate, and what did you do before that, if it is relevant to how you work now? If you are new, say new. That is a complete answer.

### Section B: Your business today (4 questions)

6. Who do you mainly help: buyers, sellers, or both? And what are your specialties, if any? For example: listings, first-time buyers, move-up buyers, downsizing, probate or inherited homes, expired listings, for sale by owner, investors, relocation, new construction. Name only what you actually do.
7. Where do your leads mostly come from now, and what tools do you already use day to day? For example: your CRM, your email, the MLS you belong to, any lead or marketing tools. Name the ones you use, skip the rest.
8. What price ranges and property types do you handle most? For example: single-family, condos, multi-family, land, luxury, waterfront, rural.
9. Optional: are there any goals or targets you want this system to remember, such as deals, listings, or income? Skip is fine. Anything you mark private goes to `CONFIDENTIAL/`, not the wiki.

### Section C: Your voice (5 questions)

10. How do you naturally talk to clients? Pick the closest: teacher who explains, advisor who guides, peer who keeps it casual, straight shooter who keeps it short, or describe your own style.
11. Give me real examples of how you sound. Paste a few texts, emails, posts, or lines you actually say to clients. Real examples teach voice better than adjectives like "warm" or "professional," so this one matters more than question 10.
12. What do you never want to sound like, and are there words or phrases you never want used in your messages or posts? Push on this one. What a person hates usually defines their voice faster than what they like.
13. How do you usually sign off in messages and email?
14. Confirm the writing defaults at the top of this file: keep them as they are, or change what? Note any change as this agent's personal version of those rules.

### Section D: What makes you different (3 questions, no more)

Do not split this into a long list of small questions. Ask these three, and
pull everything else out of the answers.

15. Walk me through exactly how you handle a client, buyer or seller, from start to finish. Focus on anything you do differently that affects exposure, speed, price, negotiating power, or how the client feels during the process.
16. What do you do better than most agents, or what parts of the process do you personally control that most agents leave to chance?
17. When someone chooses you, what actually happens differently compared with a typical agent experience?

Follow-up rule: if an answer is vague ("great communication," "I care about my clients," "I market the home"), ask **one** sharpening question only: is it faster, more targeted, more controlled, or something most agents do not even attempt? Then stop asking and build from what you have.

After these three answers, draft the following and show it to the agent for approval before saving any of it:

- Your process in plain steps: a seller process of 3 to 5 steps, and a buyer process of 3 to 5 steps. Only steps the answers actually support.
- Whether your process has a name, or you want one. Optional. Do not force a flashy name on someone whose style is understated. Any name proposed here is created in this session for this agent.
- 2 or 3 honest contrast lines in this shape: "Most agents do X. I do Y." Credible only, no claims you cannot support, nothing disparaging about a named person or firm.
- Your strongest specific differences, with generic claims rewritten into specifics. Example of the move: not "great communication," but "clients know what is happening, what happens next, and what decision they need to make before a deadline becomes a problem."

### Section E: Your ideal client (6 questions, one client at a time)

Profile **one** best-fit client first, deeply, instead of a shallow list of
types. More profiles can be added later as separate sections in the same
file, one at a time, using these same questions.

18. Which one client do you most want more of: a buyer, a seller, or a specific situation? For example: first purchase, growing family moving up, downsizing, relocating, selling an inherited home, divorce, investor, luxury. Pick one for now.
19. What is their situation? Life stage, the event that triggered the move, and their timing. What have they already tried, and why are they still stuck?
20. What is their money picture, in ranges, only as far as you actually know it? For example: income range, equity, down payment limits, monthly payment comfort, rate sensitivity, fear of losing money. If you do not know, say so. Do not guess, and the AI will not guess either.
21. What keeps them up at night? Rank their top fears. Common ones: making the wrong decision, losing money, looking uninformed, regret, family judgment, missing out, being taken advantage of, losing control, buying too much house, selling too cheap, moving too early, waiting too long.
22. What do they say out loud, and what would they never admit? Give me both. For example, what they say: "We are just waiting for the right time." What may be underneath: they are scared of making a costly mistake everyone will see. Include any conflict between how they see themselves and what this move asks of them.
23. What finally makes them act, and what do they need to believe before they will move forward?

AI, after these answers: give this profile a short descriptive label made
of the client's situation plus their main pressure, such as
"Move-up buyer, growing family, space pressure." That is the standard
Memory-Tree label format for a profile. Avoid plain labels
like "Home Buyer" or "Seller," they carry no useful information.

Special case to cover when it fits the profile, not as an extra section:
for clients 55 and older, downsizers, and empty nesters, ask inside
questions 21 and 22 about independence, not wanting to be a burden on
adult children, reluctance to ask family for help, attachment to the family
home, and fear of making an irreversible late-life mistake. That material
belongs in the answers, not in a separate interview.

### Section F: Your stories (1 prompt, up to 5 stories)

24. Tell me your real stories. Answer any of these you have, skip any you do not. One story is enough to start, and you can add more later.
   - Why you got into real estate
   - A deal that nearly fell apart, and what you did
   - A frightened or uncertain client, and how it ended
   - An early mistake you now protect clients from
   - A moment when you realized you were good at this work

For each story, capture it in this shape, in the agent's own words:

- **What happened:** the moment, plainly
- **How it felt:** their language, not cleaned up
- **What it proves:** the belief this story gives a future client
- **Use it for:** video, post, email, presentation, objection handling, About page

Keep the imperfections. Fear, mistakes, and frustration are what make a
story believable. Do not polish them out.

### Section G: Your clients' exact words (2 questions)

Build this from Section E first. Pull every real phrase already captured
there before asking anything new.

25. Paste real wording from your clients: lines from reviews, texts, emails, or things clients say to you word for word. Do not rewrite it into nicer marketing language. Raw wording is the valuable part. Where you do not have real wording yet, the file keeps the placeholder: **Add real wording here later.**
26. What are the top objections you hear from buyers, and from sellers, in their words, not yours?

### Section H: Your market and your alternatives (3 questions)

Use the market areas from question 2. Do not ask for them again.

27. How do you describe your market right now, in your own words? What is moving, what is sitting, which segments matter most, and what do buyers and sellers keep getting wrong about it?
28. When a client does not choose you, what do they usually do instead? For example: another agent, a discount option, selling on their own, waiting, or doing nothing. Describe those alternatives factually, from what you actually see. The AI will not invent information about any competitor, and nothing disparaging goes in this file.
29. In that honest comparison, where are you actually different? Tie it back to Section D instead of inventing a new claim.

### Section I: Your proof (2 questions)

30. What proof can you actually document? Paste testimonials, reviews, and real client outcomes. Include numbers only when they are real and yours. Nothing is invented to make this section look stronger.
31. If your proof is still thin, what is true today that builds trust? For example: your experience and training, your process from Section D, your stories from Section F, how you communicate, how available you are. This section stays open and grows. It keeps the line **Add more here.** at the end.

### Section J: Your guardrails (3 questions)

This section is a filter for everything this brain later writes in public.
It is not legal advice, and it does not replace your brokerage's review or
your state's rules.

32. What rules do you already have to follow? Name any brokerage policies, state requirements, or phrases your brokerage prohibits, in your own words. You and your brokerage supply this. The AI does not fill it in from general knowledge.
33. What will you never claim, promise, or post about? While the agent answers, flag common risky wording for them to check with their brokerage, without deciding it for them. Examples that often need a brokerage check: describing a neighborhood by who lives there, calling an area "safe," claims about school quality, "walking distance," and any guarantee of a result, a price, or a timeline.
34. Approval rule for this brain: everything it drafts is held for your approval before it is sent or posted. Keep that rule for everything, or loosen it for anything specific? Name what, if anything, can go out without a check.

### Section K: People and how this system runs (3 questions)

35. Who are the first few people I should know? For each: name, who they are to you, and one line to remember. Each person becomes their own file, listed in the table below.
36. Is there anything an AI working in this brain must never do? For example: never send without approval, never quote a price, never contact a client directly. Write it here, plainly.
37. What content do you actually use, or want to use? For example: short video, social posts, email, listing presentations. The AI builds your topic list for you from Sections D, E, F, G, and I (your difference, your client, your stories, their words, your proof), so no separate content interview is needed. This question only sets the formats.

---

## Where answers go

This table is the Memory-Tree output map.
One topic per file, in `wiki/`, following the Memory-Tree rule.

| Interview section | Saved to | Notes |
|---|---|---|
| A. You and your license | `wiki/identity.md` | Name, market, license, brokerage, team status, timezone |
| B. Your business today | `wiki/identity.md` | Specialties, lead sources, tools, property types. Goals also go here unless marked private |
| C. Your voice | `wiki/brand-voice.md` | Style, real example phrases, never-say list, sign-off, writing defaults as confirmed |
| D. What makes you different | `wiki/how-i-work.md` | Process steps for sellers and buyers, contrast lines, specific differences. Draft first, save only after approval |
| E. Your ideal client | `wiki/ideal-client.md` | One profile per section in this file, each with its label |
| F. Your stories | `wiki/my-stories.md` ("Story Bank") | One entry per story, in the 4-part shape in Section F |
| G. Your clients' exact words | `wiki/client-words.md` ("Client Words") | Seller wording, buyer wording, objections, ready-to-move wording. Never rewritten |
| H. Your market | `wiki/my-market.md` | Market description, alternatives clients choose, honest differences |
| I. Your proof | `wiki/proof.md` | Testimonials, wins, outcomes, trust builders. Ends with "Add more here." |
| J. Your guardrails | `wiki/guardrails.md` ("Guardrails") | Brokerage and state rules as supplied, never-claim list, approval rule |
| K. People and system rules | One file per person in `wiki/people/`, and never-do rules at the top of `wiki/guardrails.md` | Content formats noted in `wiki/identity.md` |

Derived, no interview needed: a starter topic list built from Sections D,
E, F, G, and I goes at the end of `wiki/how-i-work.md` as "Topics I can
speak to," grouped by format from question 37.

Private items, if any: `CONFIDENTIAL/` if the folder exists. Log only that
an item exists there, never its contents, in the wiki.

## Finish

1. Show the agent a summary, section by section: what was confirmed, what was corrected during verification, what was skipped, what is still `[imported, not yet verified]` or `[open]`, and what is UNFINISHEDWORK, listed as its own category with each item's state (NOT KNOWN or NEED TO CREATE).
2. Show the gap list in plain words: which sections are strong, and which ones need more real material later (usually exact client wording and proof). A gap does not block finishing.
3. Confirm every draft from Section D was approved before it was saved. Unapproved drafts are not saved.
4. Create the `wiki/people/` file for each person named in question 35.
5. Check the saved files against Section J one last time. Nothing saved in this interview should break the guardrails the agent just set.
6. Log the run: date, sections completed, sections skipped, and that the interview is done for now. If the project keeps a daily or memory file, log it there. Otherwise, log it at the bottom of `wiki/identity.md` under "Interview log."
7. Seed the task list. Every current project, commitment, or open loop the agent named during the interview goes into `tasks.md`, the Master Task List: live now under This week, everything else on the master list. Then ask once: "What else is open right now that I should keep track of?" Items from that answer that are not known or not done yet go to `unfinished-work.md`, never into `tasks.md` as facts. Method: `sops/agent/task-forwarding.md`.
8. Fill `memory.md`. The cheat sheet takes the confirmed basics (name, what to call them, market, timezone). Cover the system settings this interview did not ask about (morning brief time, starter jobs on or off, review link, farm zip codes, Facebook groups to scan) by asking once, briefly, now, or registering each one as UNFINISHEDWORK. Also ask the six cadence questions in `agents/0-chief-of-staff/schedule.md` (brief time, heartbeat or once a day, awake hours, asleep hours, weekend evenings, overnight check or none) and write the answers into that file's cadence matrix. `memory.md` keeps only the cadence on/off switch; the windows and interval live in the matrix, nowhere else. `Schedules wired` is not the interview's line to change; wiring happens through the startup schedule check in `AGENTS.md`, which runs before the interview at startup. Then set the status line to `Status: INTERVIEWED (YYYY-MM-DD)` with today's date.
9. Suggest the obvious next step: drop the first real working item into `raw/` and run `translate.md` on it.

## Quick checklist for the AI (before saying "done")

- [ ] Step 1 import was offered before any question was asked
- [ ] `translate.md` was run on anything imported, and nothing was deleted
- [ ] Every found answer was verified, not silently trusted
- [ ] No `[confirmed]` question was asked twice, in this run or a past run
- [ ] No story, quote, number, credential, award, or competitor claim was invented
- [ ] Section D drafts were shown and approved before saving
- [ ] Private items went to `CONFIDENTIAL/`, not the wiki
- [ ] The summary lists confirmed, skipped, and still-open items honestly
- [ ] Every don't-know was tagged UNFINISHEDWORK and registered in `unfinished-work.md`; none was pressed, guessed, or silently dropped
- [ ] `tasks.md` was seeded from what the agent named, `memory.md` was filled, and its status line was flipped to INTERVIEWED

