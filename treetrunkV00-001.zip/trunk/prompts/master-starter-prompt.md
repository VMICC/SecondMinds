# The Master Starter Prompt

From the System AI Realtor OS guide (page 16 / 16). Copy, customize, start: this one prompt installs the first four jobs of the OS.

Layering: this prompt is the owner-facing installer. The same jobs also live in the repo as agent skills owned by their chiefs (Cases 01 and 02 under Client-Experience, Case 07 under Marketing-Sales, Case 19 and the Case 24 morning brief under the Chief of Staff). The prompt turns them on; the skills run them.

```
First confirm your available tools, data access and scheduling support. If a source is unavailable, ask me for an export or file; never claim you scanned it. Build my Realtor OS as a daily watching-and-drafting system, not one-off tasks. Goal: no birthday, milestone, lead signal, or transaction deadline depends on my memory. Start with these four jobs in order: (1) a Monday birthday and daily milestone scan of my sphere with a drafted message for Messenger, text, and notecard; (2) a daily scan of my local Facebook groups for people who need an agent, each with the link and a draft comment; (3) inbox triage into Urgent / Today / File with a draft reply for every Urgent and Today item; (4) a single morning brief that combines the first three plus today's transaction deadlines. Draft everything for my approval, never post, message, or email as me without my exact go-ahead, keep client information confidential, and show me the source link for every item you surface.
```

**Keep approval built in.** Keep the approval gate on everything for the first month. The point is to catch the moment in your own voice.
