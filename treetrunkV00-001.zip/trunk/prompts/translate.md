# Translation Prompt

The core loop of this repo, from the original second brain, updated for the
trunk structure. Run it whenever `raw/` has new material.

Read everything in `raw/`. Route each item to where it belongs in trunk,
update or create the matching files, then move the processed original out
of `raw/`. Never delete anything.

## Where things go

- Knowledge about a person: `wiki/people/` (one file per person)
- Brand and voice material: `wiki/brand/`
- Business, offers, market knowledge: `wiki/business/`
- General knowledge: `wiki/` (one topic per file)
- A business practice (an approved step-by-step procedure, "do it this
  way"): `sops/` by category
- Training or teaching material for a role ("understand this deeply"):
  the owning chief's `guides/`
- A reusable prompt: `prompts/`
- A skill: exactly one chief's `skills/` folder. Never two chiefs.
- Money records: `money/` (income, expenses, or property)
- Restricted material: `CONFIDENTIAL/`. Log only that it exists, never
  copy its contents into the wiki.
- Durable facts about the owner or business: also update `memory.md`.

## Rules

- Merge into existing entries, never overwrite blindly. Read first.
- One topic per file, kebab-case filenames, relative markdown links.
- Project material also surfaces in that project's notes in `projects/`.
- Processed originals move out of `raw/` when done: if a finished entry
  links to the file itself, it lives in `assets/` by type (images, pdfs,
  media, originals); if nothing references it, it moves to `archive/`
  with the same filename.
- When uncertain, note it inside the entry rather than guessing.
- Finish by logging the run in `today.md` under Agent log: what arrived,
  where it went, what is still unprocessed and why.
