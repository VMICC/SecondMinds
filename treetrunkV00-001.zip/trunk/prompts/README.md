Reusable AI instructions, saved once and run often.
