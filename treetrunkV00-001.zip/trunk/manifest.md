# Manifest

Every moving part of this system, one line each. This file describes;
it does not instruct. The rules live in `AGENTS.md` and nowhere else.

When a new system file or folder is created, add one line here. That
is what keeps this list complete.

## Root files

- `readme.md` the owner's guide to the system.
- `AGENTS.md` the canonical instructions. Every rule lives here.
- `CLAUDE.md`, `GEMINI.md` two-line pointer stubs to `AGENTS.md`.
- `memory.md` the cheat sheet: who the owner is, system settings,
  first-run interview status.
- `today.md` the daily page: today's ABC task list, on-my-mind notes,
  agent log. Archived each morning to `archive/daily/`.
- `tasks.md` the Master Task List: this week's top priorities, the
  unscheduled master list, items parked by month, the closed log.
- `unfinished-work.md` the don't-know register (NOT KNOWN /
  NEED TO CREATE), resurfaced one per day in the morning brief.
- `manifest.md` this file.

## Folders

- `agents/` the AI team: five chiefs, catalog in `agents/README.md`.
- `raw/` incoming, unprocessed. Local only.
- `wiki/` managed knowledge: brand, people, business.
- `sops/` approved practices by area (buyer, seller, agent,
  prospecting, social-media).
- `projects/` active work.
- `prompts/` reusable instructions: `translate.md`,
  `first-run-interview.md`, `master-starter-prompt.md`.
- `skills/` empty on purpose; skills live with their owning chief.
- `money/` income, expenses, property records.
- `assets/` large files. Local only.
- `archive/` processed originals, daily pages, monthly logs. Local
  only.
- `CONFIDENTIAL/` restricted material. Local only.
- `trash/` the bucket: anything removed lands here, date-prefixed.
  Local only. Only the owner empties it.

## Methods worth naming

- Task forwarding and the Master Task List:
  `sops/agent/task-forwarding.md`
- The raw-to-wiki loop: `prompts/translate.md`
- The first-run interview: `prompts/first-run-interview.md`
