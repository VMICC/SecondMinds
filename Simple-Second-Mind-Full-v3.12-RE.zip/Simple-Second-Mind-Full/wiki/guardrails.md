# Guardrails

The rules that keep this agent's marketing and client work out of trouble. The first-run interview (Block 7) installs the starters below and adds the agent's own rules to this file. From that block onward, the assistant checks anything public-facing against this file before showing it to the agent.

> This is not legal advice and the assistant is not a compliance officer. These are the common guardrails that keep most agents out of trouble. Your state, your brokerage, and your licensing body may be stricter. Before you run paid ads or publish anything public, have the right person look at it once.

## Fair housing starters

Fair housing law says a home or a neighborhood may not be treated or described differently based on who someone is: race, color, religion, sex, national origin, disability, or family status, plus anything your state adds. Steering means nudging a buyer toward or away from an area based on who they are instead of what they asked for. Language can steer even when nobody meant it to.

Watch these, and say the checkable fact instead:

- **"Perfect for families"** and similar who-it-is-for language. It can imply a preference about family status. Describe the home: beds, baths, yard, layout.
- **"Safe neighborhood."** Safety language can read as a coded signal about who belongs there. Give the fact instead: a crime statistic from a public source, a lighting or patrol detail, or nothing.
- **"Great schools"** used as a signal. School talk can act as a proxy for steering. Name the assigned schools and let the buyer judge, or point to the district's own published data.
- **"Walking distance."** Usually fine on its own, but paired with the phrases above it can reinforce a pattern that reads as steering, and it can exclude buyers with mobility limits. Give the distance instead: "0.4 miles to the trail entrance."

The standing fix: describe the property and the area with facts anyone can check, never with language that signals who you think belongs there.

## Agent claim starters

- Never guarantee a sale price, a timeline, a number of offers, or a result, in writing or out loud in a recorded format.
- Never publish a number (homes sold, list-to-sale ratio, days on market, volume) that cannot be backed up from the MLS or a closing record.
- Market statistics in content carry their source and their period (for example: MetroMLS, September 2026). A number without a source does not ship.
- A client's name, photo, story, or result in public material needs that client's permission first. Getting it is the agent's job, not the assistant's.
- Follow the brokerage's advertising, signage, and logo rules wherever they are stricter than the general ones. If those rules are not known yet, that check is registered as unfinished work, not guessed at.

## The accountability rule

An AI drafting something does not move responsibility for it. The agent's name and license are what the public sees, and the agent owns everything published under them. "The AI wrote it" is never a defense, so nothing public leaves this system without the agent's approval, through `/queue`, like everything else outbound.

## The agent's own rules

Filled in by the first-run interview (Block 7) and added to whenever a new rule shows up in real work:

- Never do without asking first:
- Private, belongs only in `/CONFIDENTIAL` (existence noted here, content never copied here):
