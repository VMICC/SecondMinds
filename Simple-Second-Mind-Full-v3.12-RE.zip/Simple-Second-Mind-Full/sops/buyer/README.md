Buyer-side procedures. One procedure per file. Start from `../sop-template.md`.
