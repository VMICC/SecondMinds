# First-Run Interview: Real Estate Agent Edition

The setup interview for this second brain, written for a licensed real estate agent. Every question, proof metric, client type, and compliance starter in it assumes a Realtor®. This is the v3.12-RE interview: fewer questions asked flat, more generated from the answers and shown back for one correction.

## What this does

This interview turns a blank folder into an agent's second brain. It does not start with questions. It starts with what the agent already has. Material exported from other AI tools, an old bio, or an earlier version of this brain usually answers half of this interview before a single question is asked. So the order is fixed:

1. **Ask for the prefill handoff first.** Before any question, the assistant asks whether the agent has a filled prefill handoff (Step 1): the file an AI that already knows them filled in from its memory, usually named `interview-prefill.md`. If it is in `/raw`, it is ingested before anything is asked, and the assistant keeps checking `/raw` for one at every session until this interview is finished.
2. **Import the rest.** Drop exported files into `/raw`, or say "none".
3. **Ingest.** The assistant runs `prompts/translate.md` over `/raw`.
4. **Scan and grade.** The assistant checks the whole folder, and any earlier brain the agent points to, and grades every foundation Real, Thin, or Empty (see Step 2).
5. **Verify.** Found answers are shown back for confirmation, not asked again from scratch.
6. **Ask only what is missing.** One question at a time. Facts are tapped, stories are told, and whole sections are generated from earlier answers instead of asked.

## Running this again later

This interview can be run again at any time. It will not ask questions that are already confirmed.

Every answer carries one tag:

- `[confirmed YYYY-MM-DD]` the agent said it and confirmed it
- `[imported, not yet verified]` it came from a file, the agent has not confirmed it yet
- `[skipped]` the agent chose to skip it
- `[open]` not asked yet, or no usable answer yet

A gap the agent cannot fill gets a different tag. It is not an answer state:

- `[UNFINISHEDWORK: NOT KNOWN]` the agent does not know yet; it needs finding, checking, or deciding
- `[UNFINISHEDWORK: NEED TO CREATE]` it does not exist yet; it has to be made

Every unfinished item is also registered in `unfinished-work.md`. From there it comes back one per day in the morning brief, until it is answered and re-tagged `[confirmed]`.

On a re-run, the assistant skips every `[confirmed]` question, works only on what is `[open]`, `[skipped]` if the agent wants to revisit it, or `[imported, not yet verified]`, and ends with a short list of what changed. Foundations graded Thin (Step 2) get one thickening follow-up, never a rebuild. Skipped questions are offered again on a re-run at the start of their block, named one by one, not buried inside it; keeping a skip is always a complete answer.

## Rules for the assistant running this interview

- One question at a time. Wait for the answer before asking the next one.
- **Tap or Talk, marked on every question below.** Tap questions offer 2 to 4 likely answers as choices, plus a free-text escape, because facts and categories should never cost typing. Talk questions are answered in the agent's own words, dictated if they prefer, and never get canned options: a tapped story is an invented story. Questions with both parts go tap first for the shape, then talk for the substance.
- Write each answer down as you go, with its tag and date, so nothing is lost if the session ends early.
- Never ask for anything already confirmed in this folder, or said earlier in this session. Check first. If the agent already described their client during the voice questions, say it back and ask them to confirm it in the client block instead of asking fresh.
- Imported material outranks asking. If a file already answers it, verify it instead of asking it.
- **The prefill handoff outranks every other import, and confirmed answers outrank the prefill.** A prefill answer is imported material with a head start, nothing more: it is verified like everything else. If a prefill answer conflicts with an answer already `[confirmed]`, the confirmed answer stands and the conflict is shown at verification, never silently merged.
- **A prefill can arrive mid-interview.** If one lands in `/raw` at any point before the Finish, pause, ingest it, re-grade, and continue from the new gaps. Never restart a block that is already confirmed.
- **Two prefills can disagree.** The agent may run the handoff through more than one AI. Ingest all of them. Where they disagree, verification shows both versions and the agent picks; conflicting facts (numbers above all) are never averaged or silently merged.
- Never treat imported or inferred material as fact. It stays `[imported, not yet verified]` until the agent confirms it. Generated profiles and positioning are labelled proposed until the agent confirms them.
- "Skip" is always a valid answer. Tag it `[skipped]` and move on. A whole block can be skipped the same way.
- "I don't know" is always valid too. Tag the gap, register it in `unfinished-work.md`, and move on. Do not press, do not guess.
- **Push once on a weak answer, then move on.** "I care about my clients" gets one sharpening choice (faster, markets harder, more targeted, or something other agents do not attempt), never a loop of follow-ups.
- **Generate, do not ask,** wherever a block below says so. Drafting the one-liner, the client profile, and the content angles is the assistant's job. The agent's job is one correction pass.
- **Answer the question under the question.** "Can I change this later?" usually means "I am afraid of getting it wrong." Answer both, briefly, then continue.
- **Invite questions out loud three times:** after Block 1, halfway through, and before the Finish. Silence usually means stuck, not satisfied.
- **Warn before long stretches of file work,** and report anything fixed as fixed. A repair reported without its result reads as a fault.
- **Offer voice dictation twice:** once at the start, and again at the stories block, where it pays off most. Nowhere else.
- **Running behind: compress, never stall.** Take the shortest usable answer, tag the section Thin, and move on. A finished thin file beats an unfinished session.
- Never invent facts, stories, numbers, credentials, designations, or results. If something does not exist yet, write the placeholder: **Add real material here later.**
- Do not ask for passwords or account access.
- Anything the agent marks private goes in `/CONFIDENTIAL`, and only its existence is noted anywhere else.

## Writing defaults (confirm in Block 2, then follow everywhere)

- Write like you are talking to one person, not an audience. Normal language, contractions, mixed sentence lengths, direct statements.
- Simple words a busy person gets on the first read.
- Say it once, clearly, and move on.
- No em dashes. Use a period, a comma, a colon, or parentheses.

---

## Step 1: The prefill handoff, then your other material

Assistant: do not ask any interview questions before this step is offered. Say this, in plain words:

> Before we start, the fastest version first. There is a handoff file made for this, the prefill handoff: you paste it into an AI you have worked with for a long time, and that AI fills in this whole interview from what it already knows about you. If you already ran it, drop the file it gave you (it usually comes back named `interview-prefill.md`) into the `raw/` folder and tell me it is there. If you have not run it, that is fine too: until this interview is finished I will check `raw/` at the start of every session, so you can run it whenever it suits you and I will pick it up before asking anything it answers. If you want the handoff file, say the word and I will get it for you. And if you would rather not use one at all, say "no prefill" and we go the regular way.
>
> Before we start, let's not make you repeat yourself. If you have used any AI tool before, export or copy what it remembers about you and your business, and drop those files into the `raw/` folder. Good things to include: memory or "about me" exports, a bio or resume you already wrote, your current marketing pieces, and anything else that already describes you and your clients. If you built an earlier version of this brain, tell me where that folder lives too, and I will carry what is in it instead of asking it again. Tell me when the files are in `raw/`, or say "none" and we will go straight to the questions.

If the agent says "no prefill" and "none" for the other material, tag Step 1 `[skipped]` and go to Step 3.

## Step 2: Run translate, scan, and grade

1. Run the prompt in `prompts/translate.md` over everything in `/raw`. Processed files move out of `/raw` the way that prompt directs. Never delete anything.
2. Scan the whole folder, plus any earlier brain folder the agent named, and build a pre-fill list for every block below: which foundations have material, and where it came from. Prefill files are scanned first: their answers are the pre-fill list's first source, and an entry the other AI tagged [from memory] still lands here as `[imported, not yet verified]`. Do not show the agent the whole list at once. Use it silently in Step 3.
3. **Grade each foundation:**

   - **Real:** it has the agent's actual content. Carry it. After the agent verifies it, tag it `[confirmed]` and never ask it again.
   - **Thin:** a heading, one vague line, or filler that could describe any agent. Carry what is there, then ask the one follow-up that thickens it.
   - **Empty:** placeholder text, an unanswered prompt, or nothing. Treat it as never answered. Ask normally.

   When torn between Thin and Real, call it Thin and ask. One extra question is cheap; a hollow answer filed as fact makes every later draft sound generic.
4. **Carry-over confirmation.** If an earlier brain was found, confirm it is theirs before carrying anything, by quoting one concrete detail from it (a client type, a town, a phrase) and asking one tap: yours, or not yours. Not theirs means carry nothing and run the interview normally.
5. An earlier brain folder is never moved, renamed, edited, or deleted. It stays as the agent's backup, and the carry-over (source folder, date, which foundations carried) is logged in `today.md`.

## Step 3: Verify first, then ask what is missing

For each question: if the answer was found, show it back short ("I found this, is it still right?") for confirm, correct, or skip. If it is missing, ask it. One at a time.

### Block 1: Identity and agent proof

1. **[Talk]** What is your name, and what should the assistant call you?
2. **[Talk]** What brokerage are you with, and what state are you licensed in?
3. **[Talk]** What timezone are you in?
4. **[Tap]** How long have you been licensed? (Under 2 years / 2 to 5 years / 5 to 10 years / 10 years or more)
5. **[Talk]** How many homes have you sold? Your own number, in your own words. Never rounded, never estimated by the assistant.
6. **[Tap, then Talk]** Where do you work? Tap the shape first (One town or city / A few towns near each other / A whole county or region / Specific neighborhoods), then name the actual places. The names have to be the agent's.
7. **[Tap]** Do you hold any designations? Multiple picks allowed, and "None of these" is a complete answer. No designations is not a gap: proof gets built on numbers and results instead.
8. **[Tap, then Talk]** What have you actually done that you are proud of? Tap a doorway first (Volume / One specific result for one client / Recognition / Staying power), then tell the detail in your own words.
9. **[Talk]** What topics do you think about most? (The subjects this brain should be organized around.)

Answers go to the cheat sheet in `memory.md`. Homes sold, designations, and the proud-of detail also seed the proof file (Block 8 reads them from here, it does not ask again).

### Block 2: Voice

10. **[Tap]** How do you naturally talk? Multiple picks allowed (Direct / Warm / High energy / Calm).
11. **[Tap]** When you are helping a client, which one are you? (The teacher / The advisor / The peer / Depends on the client)
12. **[Tap]** What do you never want to sound like? Multiple picks allowed (Salesy / Corporate / Hyped / Generic).
13. **[Talk]** What words or phrases do you never want used in anything written for you? (This is the banned-words question from `/wiki/brand/banned-words.md`. Ask it once, here, and never again in later sessions. A short answer is fine, even 3 to 5 items. If the agent cannot think of any, ask "What do other agents say that makes you cringe?" If there is still nothing, write "none yet": the starter list in that file stays on. Write the answer in the Personal Bans section of `/wiki/brand/banned-words.md`, not in the voice file.)
14. **[Talk]** Is there a piece of your own writing that sounds like you? (Drop it in `/raw` if so. It becomes the voice reference in `/wiki/brand/voice.md`.)
15. **[Talk]** What do you not want in the wiki? (For example: no motivational filler, no summaries on short entries, no emojis.)

The voice file is built from 10 to 15 plus the agent's example phrases in their actual words. The example phrases matter most: without them the file does nothing.

### Block 3: Clients and differentiator (generated, not asked flat)

Before asking anything here, re-read Blocks 1 and 2. If the agent already described a client, say it back and ask for confirmation instead of asking fresh.

16. **[Tap]** How many kinds of clients do you serve? (Just one / Two / Three or more / Let me explain)

Then, **for each client type, one at a time:**

17. **[Tap, then Talk]** Who do you serve? Tap the type (First-time buyers / Move-up families / Downsizers and seniors / Probate and estate sales / Relocators / Investors), then one talk follow-up only: what kind of shape are they usually in when they come to you?
18. **[Tap]** What do you actually do for them? Not "I sell homes," the thing they walk away with. Multiple picks allowed (A result they could not get alone / The stress and guesswork taken off them / It gets done faster, or for more money / They learn the process as we go), plus their own words if none of these fit.
19. **[Generate, then Tap to confirm]** The assistant drafts the "I help [who] with [problem]" line from 17 and 18, shows it, and asks one tap: that is it, or close, let me adjust it. The agent never has to compose this sentence out loud.

**Then generate the full client profile** for each type, from these answers plus everything already in the folder, across: who they are, what they have already tried, their biggest fears, what they actually want, what blocks them, and why this agent. Label it proposed until the agent confirms it. Show it in full, then ask one question: "Anything in there wrong?" Fix what they name and move on. Never walk it section by section. Never average two client types into one profile.

**Then the differentiator, three combined questions:**

20. **[Tap, then Talk]** Walk me through how you handle a client from start to finish. Tap where to start (Marketing and getting seen / The process after they hire me / Negotiation / After the close), then talk it through. Build the seller process and the buyer process separately: they are different jobs.
21. **[Tap, then Talk]** What do you do better than most agents in your market, or control in the process that other agents hand off? Multiple tap picks allowed (I am faster / I market harder / I control a step others hand off / I stay involved longer / I know something the others do not), then one talk follow-up on what they picked.
22. **[Tap]** When somebody chooses you, what happens differently for them? Multiple picks allowed (A better number / It moves faster / They stop worrying / They always know what is happening / They come back and send people).

Never ask what mistakes other agents make. Infer the contrast, or state it in the output.

**Then generate the differentiator file:** two or three name options for the agent's way of working (a real name, never a task list with a label), its steps for sellers and for buyers, two or three "most agents / me" contrast lines, why it works in plain terms, three or four lines the agent can say out loud at a listing appointment or a buyer consult, and the one-liner. Rewrite anything generic before showing it: a line that could sit on any agent's website is not finished. If the agent is new, position on speed, availability, current marketing, and follow-through, never on invented experience.

23. **[Tap]** Should this sound more high-end, more direct, plainer, or is it right? One rewrite pass on their answer, then stop.

Client profiles go to `/wiki/brand/ideal-client.md`, one labelled section per client type. The differentiator goes to `/wiki/brand/differentiator.md`.

### Block 4: Stories

24. **[Tap]** Which of these do you have a real story for? Multiple picks allowed (Why I got into real estate / A deal that almost died / A scared buyer or seller / A mistake I learned from / The moment I knew I was good at this).

Remind the agent here to talk instead of type. Then take only the picks, **one at a time, all Talk:**

25. Why did you get into real estate? What were you doing before?
26. Tell me about a deal that almost died, and what you did.
27. Tell me about a buyer or seller who was scared or overwhelmed. What changed for them?
28. What is a mistake you made early on that you now protect clients from?
29. Tell me about a moment when you knew you were actually good at this.

Rules: keep the agent's exact words, and keep the hard parts, because the fear and the mistake are what make a story believable. One follow-up at most per story ("What did that feel like at the time?"), then move on. Skip is fine. Three real stories beat five padded ones. Never write a story the agent did not tell, and never add a detail they did not give. File each story in four parts: what happened, in their words, what it shows, where to use it. Stories go to `/wiki/brand/stories.md`.

### Block 5: Client words (pull first, ask only the gaps)

Do not open this block with questions. Read `/wiki/brand/ideal-client.md` and `/wiki/brand/stories.md` first, pull every line of real client language already there, and show it back with where it came from. If that covers the buckets below, say so and ask nothing.

Ask only for genuine gaps, one at a time, all **[Talk]**:

30. What does a seller say to you, in their exact words, early on?
31. What does a buyer say when they are frustrated with the search?
32. What is the objection you hear most, in their exact words?
33. What is the sentence you hear that means someone is actually ready to move?

Collect it raw. Do not clean it up and do not turn it into marketing copy. An empty bucket gets the placeholder and an unfinished-work tag, never an invented quote. Client words go to `/wiki/brand/client-words.md`.

### Block 6: Market and competitors

34. **[Confirm, do not ask]** "You told me your market is [from Block 1]. Still right?" A change here updates Block 1's answer, it does not create a second one.
35. **[Tap]** What price ranges and property types do you mostly work? Multiple picks allowed (Starter homes / Move-up family homes / Luxury / Condos and townhomes / Land).
36. **[Talk]** Who are the two or three agents you lose listings to most, and what do they do well?

Competitor rule: never state a fact about a named competitor that the agent did not supply, and describe what they do well, never what is wrong with them. If the agent does not know, do not guess and do not research it inside the interview: register it `[UNFINISHEDWORK: NOT KNOWN]` and move on. Market goes to `/wiki/business/market.md`.

### Block 7: Guardrails and compliance

No questions to open this block. Install the starters from `/wiki/guardrails.md` (they ship with this file: the fair housing starters and the agent claim starters, each with its plain-language why), and read the agent that file's opening line: this is not legal advice, and their state, brokerage, and licensing body may be stricter.

37. **[Tap]** Do you know your brokerage's advertising rules? (Yes, I know them / Yes, but not the details / No / Not sure) Anything but the first answer registers a check as unfinished work.
38. **[Talk]** Is there anything you should never do without being asked first, and anything private that belongs only in `/CONFIDENTIAL`? (Two answers, one question: the never-do list goes in `/wiki/guardrails.md`, private material goes in `/CONFIDENTIAL` with only its existence noted.)

From this block onward, check anything public-facing against `/wiki/guardrails.md` before showing it to the agent.

### Block 8: Proof

39. **[Tap]** Do you have testimonials, reviews, or results you can share? (Yes, I can paste some in / Yes, but they are not written down / Numbers but no quotes / Not yet)

- Written down: paste them in, and the assistant structures them with the real numbers and the real quotes.
- Not written down: the agent says one out loud and the assistant writes it down for them. That is the most common real answer, and it is not a no.
- Numbers but no quotes, or not yet: build the proof file on process, standards, and the Block 1 numbers instead. Do not treat it as a failure.

Block 1 already supplied homes sold, years, and designations: this block reads them, it does not re-ask them. Never invent a number, a result, or a testimonial. Leave an "add as it comes in" section at the bottom, and note in the file that naming a client publicly needs that client's permission, which is the agent's call to make. Proof goes to `/wiki/business/proof.md`.

### Block 9: Content angles (ask nothing)

Generate this block from Blocks 3 to 8, asking zero questions: client questions buyers ask and sellers ask, the ten objections in the client's exact words each with a reframe and one proof idea, myth-busting topics, and five to seven messaging pillars (for each: what the agent believes, what the audience believes instead, three content angles, five hooks, three calls to action that are not salesy). Organize by awareness level and by format (video, post, email). Content angles go to `/wiki/business/content-angles.md`.

### Block 10: The system

40. **[Talk]** What time do you want the morning brief? (Goes in `memory.md`.)
41. **[Tap]** Scheduling: work through the six cadence questions in `schedule.md` now, or take the defaults (once a day, brief only) and change them later?

## Where answers go

- Name, call-me, brokerage, license state, topics, timezone, voice preference: the cheat sheet in `memory.md`
- People named along the way: one file each in `/wiki/people`
- Voice from Block 2: `/wiki/brand/voice.md`
- Banned words from question 13: the Personal Bans section of `/wiki/brand/banned-words.md` (the starter list in that file is already on)
- Client profiles from Block 3: `/wiki/brand/ideal-client.md`, one labelled section per client type
- Differentiator from Block 3: `/wiki/brand/differentiator.md`
- Stories from Block 4: `/wiki/brand/stories.md`
- Client words from Block 5: `/wiki/brand/client-words.md`
- Market and competitors from Block 6: `/wiki/business/market.md`
- Guardrails from Block 7: `/wiki/guardrails.md` (ships with the agent starters installed; this block adds the agent's own rules to it)
- Proof from Block 8: `/wiki/business/proof.md`
- Content angles from Block 9: `/wiki/business/content-angles.md`
- Projects named along the way: `tasks.md` (seeded) and one folder each in `/projects`
- Private material: `/CONFIDENTIAL` (existence logged only)
- Brief time and cadence answers: `memory.md` and the matrix in `schedule.md`

## Finish

1. **The read-back, before anything else in this section.** Say: "Your brain is built. Let's prove it works. Type this exactly: **Read my folder. Who am I, who do I serve, and what makes me different?**" The agent types it, not the assistant. Answer from the files only, in the agent's voice, with their market, their clients, and their differentiator. If the answer comes out generic, a file is thin: say so, tag it, and thicken it rather than pretending. Do not add a content request on top of the read-back.
2. **Generate the portable context file** at `/wiki/ai-context.md` from the answers already given, asking nothing new: identity, clients, differentiator, voice rules, proof, guardrails, and one short paragraph the agent can paste into any other AI tool to set the whole context at once.
3. Flip `memory.md` to `Status: INTERVIEWED (YYYY-MM-DD)`.
4. If the two jobs were wired at startup, confirm `Schedules wired: YES (YYYY-MM-DD)` in `memory.md`. If not, leave it NO; the offer returns next session.
5. Seed `tasks.md` with the projects and open loops named in the interview.
6. **Final pass over skipped questions.** List every question tagged `[skipped]` in this run and offer one last pass over them now: 'You skipped these. Answer any of them before we close, or keep them skipped?' A kept skip is final for this run. Skipped is a choice, not a gap: skipped questions never go in `unfinished-work.md` and never resurface in the brief (that path belongs to don't-know items only). Kept skips stay in the summary below and are offered again, by name, at the start of their block if the interview is ever re-run.
7. List every `[UNFINISHEDWORK]` item created, and confirm each one is registered in `unfinished-work.md`.
8. End with a short list of what was filled, what was skipped, and what is still open or Thin. Never report the folder complete when a section is thin or placeholder-only. If nothing was open, say so and stop.
